# Everyday Strong Android

Everyday Strong 1.9.3 includes a new custom app icon, a dedicated Weight Loss workout focus, and a progressive 30-day weight-loss challenge with low-impact and mixed-impact sessions.

GitHub Actions builds an Android 16-compatible debug APK automatically after files are pushed to `main`.
