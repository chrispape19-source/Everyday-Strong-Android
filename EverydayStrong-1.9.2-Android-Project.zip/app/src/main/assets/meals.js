(function () {
  "use strict";

  window.EverydayStrongMeals = {
    categories: {
      breakfast: "Breakfast",
      meal: "Lunch + dinner",
      snack: "Snacks"
    },
    recipes: [
      {
        id: "greek-yogurt-power-bowl",
        title: "Greek yogurt power bowl",
        category: "breakfast",
        vegetarian: true,
        time: 5,
        protein: 32,
        calories: 400,
        servings: 1,
        blurb: "Creamy, crunchy, and ready before the coffee is.",
        tags: ["No cook", "Vegetarian", "5 ingredients"],
        ingredients: [
          "1 cup (250 mL) plain Greek yogurt",
          "1/2 cup fresh or frozen berries",
          "2 tbsp hemp hearts",
          "2 tbsp powdered peanut butter",
          "2 tbsp rolled oats or high-fibre cereal"
        ],
        steps: [
          "Spoon the Greek yogurt into a bowl.",
          "Top with the berries, hemp hearts, powdered peanut butter, and oats.",
          "Stir it together or keep the toppings layered for extra crunch."
        ],
        budgetTip: "Frozen berries are usually less expensive and work straight from the freezer after a quick thaw.",
        familyTip: "Set out the toppings and let everyone build their own bowl."
      },
      {
        id: "cottage-cheese-egg-scramble",
        title: "Cottage cheese egg scramble",
        category: "breakfast",
        vegetarian: true,
        time: 10,
        protein: 30,
        calories: 380,
        servings: 1,
        blurb: "Soft scrambled eggs with an easy protein boost.",
        tags: ["One pan", "Vegetarian", "Hot breakfast"],
        ingredients: [
          "2 large eggs",
          "1/2 cup (125 mL) cottage cheese",
          "1 packed cup baby spinach",
          "1 tsp oil or butter",
          "Pepper and a pinch of garlic powder",
          "1 slice whole grain toast"
        ],
        steps: [
          "Whisk the eggs, cottage cheese, pepper, and garlic powder in a bowl.",
          "Warm the oil in a non-stick pan over medium-low heat and wilt the spinach for 1 minute.",
          "Add the egg mixture. Stir gently until fully set, then serve with toast."
        ],
        budgetTip: "Thawed frozen spinach works too; squeeze out the extra water first.",
        familyTip: "Multiply the ingredients by the number of people and cook in two batches so the eggs stay soft.",
        safety: "Cook egg dishes to 74°C (165°F)."
      },
      {
        id: "overnight-yogurt-oats",
        title: "Overnight yogurt oats",
        category: "breakfast",
        vegetarian: true,
        time: 5,
        protein: 30,
        calories: 510,
        servings: 1,
        blurb: "Mix tonight, grab tomorrow, and skip the morning rush.",
        tags: ["No cook", "Meal prep", "Vegetarian"],
        ingredients: [
          "3/4 cup (175 mL) plain Greek yogurt",
          "1/2 cup (125 mL) milk or fortified soy beverage",
          "1/2 cup rolled oats",
          "2 tbsp chia seeds",
          "1/2 banana, sliced",
          "Cinnamon to taste"
        ],
        steps: [
          "Stir the yogurt, milk, oats, chia seeds, and cinnamon in a jar or lidded container.",
          "Cover and refrigerate overnight, or for at least 4 hours.",
          "Top with sliced banana. Add a splash of milk if you prefer thinner oats."
        ],
        budgetTip: "Buy large tubs of plain yogurt and oats instead of single-serve cups or packets.",
        familyTip: "Mix several jars at once; refrigerated oats are best used within 3 days."
      },
      {
        id: "chicken-burrito-bowls",
        title: "15-minute chicken burrito bowls",
        category: "meal",
        vegetarian: false,
        time: 15,
        protein: 47,
        calories: 590,
        servings: 4,
        blurb: "A colourful family bowl built from speedy shortcuts.",
        tags: ["Family favourite", "Meal prep", "15 minutes"],
        ingredients: [
          "3 cups chopped cooked chicken",
          "2 cups cooked brown rice, warmed",
          "1 can (540 mL) black beans, drained and rinsed",
          "1 cup frozen corn, thawed or warmed",
          "1 cup salsa",
          "1 cup shredded lettuce or cabbage",
          "1/2 cup shredded cheese",
          "1 lime, cut into wedges"
        ],
        steps: [
          "Warm the chicken, rice, beans, and corn until steaming hot.",
          "Divide the rice among four bowls, then add chicken, beans, corn, lettuce, salsa, and cheese.",
          "Finish with lime. Let everyone stir their bowl together at the table."
        ],
        budgetTip: "Use leftover roasted chicken and whichever frozen vegetables are already in the freezer.",
        familyTip: "For five servings, add another cup of rice and half a can of beans; keep the salsa on the side for kids.",
        safety: "Reheat cooked chicken and other leftovers to 74°C (165°F)."
      },
      {
        id: "tuna-crunch-wraps",
        title: "Tuna crunch wraps",
        category: "meal",
        vegetarian: false,
        time: 10,
        protein: 38,
        calories: 540,
        servings: 2,
        blurb: "A fresher, crunchier tuna sandwich that travels well.",
        tags: ["No cook", "Budget", "Lunchbox"],
        ingredients: [
          "2 cans (170 g each) light tuna, drained",
          "1/2 cup plain Greek yogurt",
          "1 tsp Dijon mustard",
          "1 celery stalk, finely chopped",
          "1/2 cup diced cucumber",
          "2 large whole grain tortillas",
          "1/2 cup shredded cheese",
          "Pepper and lemon juice to taste"
        ],
        steps: [
          "Mix the tuna, Greek yogurt, mustard, celery, cucumber, pepper, and a squeeze of lemon.",
          "Divide the tuna mixture and cheese between the tortillas.",
          "Fold in the sides, roll tightly, and cut each wrap in half."
        ],
        budgetTip: "Canned light tuna is usually economical; watch for multipack sales.",
        familyTip: "Turn the filling into sandwiches for smaller hands, or serve it with whole grain crackers."
      },
      {
        id: "turkey-taco-skillet",
        title: "Turkey taco skillet",
        category: "meal",
        vegetarian: false,
        time: 25,
        protein: 43,
        calories: 530,
        servings: 4,
        blurb: "One pan, plenty of vegetables, and almost no cleanup.",
        tags: ["One pan", "Family favourite", "Meal prep"],
        ingredients: [
          "680 g lean ground turkey",
          "1 tbsp oil",
          "1 bell pepper, chopped",
          "1 small onion, chopped",
          "2 tbsp reduced-sodium taco seasoning",
          "1 can (540 mL) black beans, drained and rinsed",
          "1 cup frozen corn",
          "1 cup salsa",
          "1/2 cup shredded cheese"
        ],
        steps: [
          "Heat the oil in a large skillet over medium-high. Cook the turkey, breaking it into small pieces.",
          "Add the pepper, onion, and taco seasoning. Cook for 5 minutes, stirring often.",
          "Stir in the beans, corn, and salsa. Simmer until hot, then sprinkle with cheese."
        ],
        budgetTip: "Replace half the turkey with a second can of beans to stretch the recipe further.",
        familyTip: "Serve with brown rice, tortillas, or chopped lettuce and let everyone choose their toppings.",
        safety: "Cook ground turkey to 74°C (165°F)."
      },
      {
        id: "sheet-pan-lemon-chicken",
        title: "Sheet-pan lemon chicken",
        category: "meal",
        vegetarian: false,
        time: 30,
        protein: 44,
        calories: 430,
        servings: 4,
        blurb: "Roasted chicken and vegetables with one tray to wash.",
        tags: ["One pan", "Family favourite", "Gluten free"],
        ingredients: [
          "680 g boneless skinless chicken breast, cut into strips",
          "4 cups mixed broccoli florets and sliced peppers",
          "450 g baby potatoes, halved",
          "2 tbsp oil",
          "1 lemon, zest and juice",
          "1 tsp garlic powder",
          "1 tsp dried oregano",
          "Pepper to taste"
        ],
        steps: [
          "Heat the oven to 220°C (425°F). Line a large sheet pan for easier cleanup.",
          "Toss the potatoes with half the oil and roast for 10 minutes.",
          "Add the chicken and vegetables. Toss with the remaining oil, lemon, garlic, oregano, and pepper.",
          "Roast for 15 to 18 minutes, until the chicken is fully cooked and the vegetables are tender."
        ],
        budgetTip: "Frozen broccoli and skinless chicken thighs are easy lower-cost swaps; allow a few extra cooking minutes.",
        familyTip: "For five, add another chicken breast and an extra cup of vegetables to the tray.",
        safety: "Cook chicken pieces to 74°C (165°F), measured in the thickest piece."
      },
      {
        id: "lentil-cottage-cheese-bowls",
        title: "Lentil cottage cheese bowls",
        category: "meal",
        vegetarian: true,
        time: 10,
        protein: 31,
        calories: 430,
        servings: 2,
        blurb: "A bright, filling bowl with inexpensive plant protein.",
        tags: ["No cook", "Vegetarian", "Budget"],
        ingredients: [
          "1 1/2 cups cooked or canned lentils, drained and rinsed",
          "1 cup cottage cheese",
          "1 cup chopped cucumber",
          "1 cup halved cherry tomatoes",
          "2 tbsp pumpkin seeds",
          "1 tbsp oil",
          "Juice of 1/2 lemon",
          "Pepper and dried herbs to taste"
        ],
        steps: [
          "Divide the lentils, cottage cheese, cucumber, and tomatoes between two bowls.",
          "Drizzle with oil and lemon juice, then add pepper and dried herbs.",
          "Sprinkle with pumpkin seeds just before serving."
        ],
        budgetTip: "Cook dried lentils in a large batch and freeze them in 1 1/2-cup portions.",
        familyTip: "Serve with whole grain pita and keep each ingredient separate for selective eaters."
      },
      {
        id: "quick-beef-broccoli",
        title: "Quick beef + broccoli",
        category: "meal",
        vegetarian: false,
        time: 25,
        protein: 42,
        calories: 620,
        servings: 4,
        blurb: "A weeknight stir-fry with a freezer-friendly shortcut.",
        tags: ["One pan", "Freezer staples", "Meal prep"],
        ingredients: [
          "600 g lean ground beef",
          "5 cups frozen broccoli florets",
          "1 cup shelled edamame",
          "3 tbsp reduced-sodium soy sauce",
          "1 tbsp honey or maple syrup",
          "1 tsp garlic powder",
          "1 tsp ground ginger",
          "2 cups cooked brown rice"
        ],
        steps: [
          "Brown the beef in a large skillet over medium-high heat, breaking it up as it cooks. Drain excess fat if needed.",
          "Add the broccoli and edamame with 2 tbsp water. Cover and cook for 5 to 7 minutes.",
          "Stir in the soy sauce, honey, garlic, and ginger. Cook for 2 minutes and serve over rice."
        ],
        budgetTip: "Use whatever frozen vegetable blend is on sale; ground turkey also works.",
        familyTip: "Keep some plain rice and broccoli aside before adding the sauce if anyone prefers milder food.",
        safety: "Cook ground beef to 71°C (160°F)."
      },
      {
        id: "salmon-edamame-rice-bowls",
        title: "Salmon edamame rice bowls",
        category: "meal",
        vegetarian: false,
        time: 25,
        protein: 39,
        calories: 550,
        servings: 4,
        blurb: "Simple roasted salmon with crisp, colourful toppings.",
        tags: ["Omega-3", "Family-style", "Meal prep"],
        ingredients: [
          "600 g salmon fillet, cut into 4 portions",
          "2 cups cooked brown rice",
          "1 1/2 cups shelled edamame, cooked",
          "1 cucumber, sliced",
          "2 carrots, grated",
          "2 tbsp reduced-sodium soy sauce",
          "1 tbsp oil",
          "Lemon or lime wedges"
        ],
        steps: [
          "Heat the oven to 220°C (425°F). Place the salmon on a lined pan, brush with oil, and add pepper.",
          "Roast for 10 to 14 minutes, until the thickest part reaches a safe temperature.",
          "Divide the rice, edamame, cucumber, and carrots among bowls. Add salmon and a little soy sauce.",
          "Finish with a squeeze of lemon or lime."
        ],
        budgetTip: "Frozen salmon portions are often less expensive and make portioning easy; thaw safely in the fridge.",
        familyTip: "Serve the components separately so each person can build a bowl they like.",
        safety: "Cook fish to 70°C (158°F)."
      },
      {
        id: "cottage-cheese-fruit-crunch",
        title: "Cottage cheese fruit crunch",
        category: "snack",
        vegetarian: true,
        time: 5,
        protein: 30,
        calories: 420,
        servings: 1,
        blurb: "Sweet, salty, creamy, and ready in one bowl.",
        tags: ["No cook", "Vegetarian", "5 minutes"],
        ingredients: [
          "1 cup cottage cheese",
          "1 small apple or pear, chopped",
          "2 tbsp pumpkin seeds",
          "Cinnamon to taste",
          "1 tsp honey or maple syrup, optional"
        ],
        steps: [
          "Spoon the cottage cheese into a bowl.",
          "Add the chopped fruit and pumpkin seeds.",
          "Finish with cinnamon and, if wanted, a small drizzle of honey."
        ],
        budgetTip: "Use whichever seasonal fruit costs least, or thaw frozen fruit.",
        familyTip: "Make mini portions for kids and let them add their own cinnamon."
      },
      {
        id: "peanut-butter-yogurt-dip",
        title: "Peanut butter yogurt dip",
        category: "snack",
        vegetarian: true,
        time: 5,
        protein: 29,
        calories: 430,
        servings: 1,
        blurb: "A thick, satisfying dip for fruit and crunchy vegetables.",
        tags: ["No cook", "Vegetarian", "5 minutes"],
        ingredients: [
          "1 cup plain Greek yogurt",
          "2 tbsp peanut butter",
          "1/2 tsp cinnamon",
          "1 apple, sliced",
          "Carrot or celery sticks, optional"
        ],
        steps: [
          "Stir the Greek yogurt, peanut butter, and cinnamon until smooth.",
          "Slice the apple and any vegetables you are using.",
          "Dip and eat right away, or cover and refrigerate for later."
        ],
        budgetTip: "Store-brand natural peanut butter and large yogurt tubs usually offer the best value.",
        familyTip: "Double or triple the dip for a shared after-school snack.",
        allergyNote: "Contains peanuts and dairy. Use seed butter and a suitable high-protein yogurt if needed."
      },
      {
        id: "rotisserie-chicken-crunch-wraps",
        title: "Rotisserie chicken crunch wraps",
        category: "meal",
        vegetarian: false,
        time: 10,
        protein: 39,
        calories: 590,
        servings: 4,
        blurb: "Turn one ready-cooked chicken into a fast family dinner.",
        tags: ["10 minutes", "Family favourite", "No cook"],
        ingredients: [
          "3 cups shredded rotisserie chicken, skin removed",
          "4 large whole grain tortillas",
          "1 cup plain Greek yogurt",
          "2 cups bagged coleslaw mix",
          "1 cup diced tomato",
          "1/2 cup shredded cheese",
          "1 tbsp lime juice",
          "Pepper and mild chili powder to taste"
        ],
        steps: [
          "Stir the yogurt, lime juice, pepper, and chili powder together for a quick sauce.",
          "Divide the chicken, coleslaw, tomato, cheese, and sauce among the tortillas.",
          "Fold in the sides, roll tightly, and cut in half."
        ],
        budgetTip: "Use leftover home-cooked chicken when available, and freeze extra shredded chicken for another meal.",
        familyTip: "For five, add a fifth tortilla and stretch the filling with rinsed black beans.",
        safety: "Keep cooked chicken refrigerated at 4°C (40°F) or colder. If reheating, bring leftovers to 74°C (165°F)."
      },
      {
        id: "one-pot-chicken-protein-pasta",
        title: "One-pot creamy chicken pasta",
        category: "meal",
        vegetarian: false,
        time: 30,
        protein: 47,
        calories: 560,
        servings: 4,
        blurb: "A creamy comfort-food dinner without a heavy sauce.",
        tags: ["One pot", "Family favourite", "High fibre"],
        ingredients: [
          "450 g boneless skinless chicken breast, diced",
          "300 g dry chickpea or lentil pasta",
          "3 cups reduced-sodium chicken broth",
          "2 cups frozen mixed vegetables",
          "1 cup cottage cheese",
          "1/2 cup grated Parmesan",
          "1 tsp garlic powder",
          "Pepper to taste"
        ],
        steps: [
          "In a large pot, cook the chicken over medium-high heat until browned on the outside.",
          "Add the pasta, broth, vegetables, garlic, and pepper. Simmer, stirring often, until the pasta is tender.",
          "Blend the cottage cheese until smooth, or mash it well with a fork.",
          "Remove the pot from the heat and stir in the cottage cheese and Parmesan until creamy."
        ],
        budgetTip: "Regular whole grain pasta is a less expensive option and still provides protein; the estimate will be a little lower.",
        familyTip: "Add another 100 g pasta and 1 cup broth for five generous servings.",
        safety: "Cook chicken pieces to 74°C (165°F). Refrigerate leftovers within 2 hours."
      },
      {
        id: "tofu-edamame-stir-fry",
        title: "Tofu edamame stir-fry",
        category: "meal",
        vegetarian: true,
        time: 25,
        protein: 35,
        calories: 610,
        servings: 4,
        blurb: "Crisp tofu and freezer vegetables in a speedy sauce.",
        tags: ["Vegetarian", "One pan", "Plant protein"],
        ingredients: [
          "700 g extra-firm tofu, drained and cubed",
          "2 cups shelled edamame",
          "5 cups frozen stir-fry vegetables",
          "2 tbsp oil",
          "3 tbsp reduced-sodium soy sauce",
          "1 tbsp peanut butter or seed butter",
          "1 tsp garlic powder",
          "2 cups cooked brown rice"
        ],
        steps: [
          "Pat the tofu dry. Heat 1 tbsp oil in a large skillet and cook the tofu until golden on several sides.",
          "Add the remaining oil, edamame, and frozen vegetables. Cook until hot and tender-crisp.",
          "Stir the soy sauce, peanut butter, garlic, and 2 tbsp water together, then pour into the skillet.",
          "Toss for 1 to 2 minutes and serve over brown rice."
        ],
        budgetTip: "Frozen edamame and vegetables prevent waste because you use only what you need.",
        familyTip: "Serve the sauce at the table if your family has different spice or flavour preferences.",
        allergyNote: "Contains soy and may contain peanuts. Use seed butter if needed."
      },
      {
        id: "white-bean-turkey-chili",
        title: "White bean turkey chili",
        category: "meal",
        vegetarian: false,
        time: 30,
        protein: 35,
        calories: 420,
        servings: 6,
        blurb: "A mild, batch-friendly chili for busy nights.",
        tags: ["One pot", "Freezer friendly", "Budget"],
        ingredients: [
          "680 g lean ground turkey",
          "1 tbsp oil",
          "1 onion, chopped",
          "2 cans (540 mL each) white beans, drained and rinsed",
          "2 cups frozen corn",
          "1 can (796 mL) no-salt-added diced tomatoes",
          "2 cups reduced-sodium chicken broth",
          "2 tsp mild chili powder",
          "1 tsp garlic powder"
        ],
        steps: [
          "Heat the oil in a large pot. Cook the turkey and onion over medium-high, breaking up the meat.",
          "Add the beans, corn, tomatoes, broth, chili powder, and garlic powder.",
          "Bring to a simmer and cook uncovered for 15 minutes, stirring occasionally.",
          "Taste and adjust the seasoning. Serve as is or with plain Greek yogurt."
        ],
        budgetTip: "Replace up to half the turkey with an extra can of beans for an even lower-cost pot.",
        familyTip: "Freeze cooled chili in meal-size containers for up to 3 months.",
        safety: "Cook ground turkey to 74°C (165°F). Refrigerate or freeze cooked chili within 2 hours."
      }
    ]
  };
}());
