(function () {
  "use strict";

  const STORAGE_KEY = "everyday-strong-native-v1";
  const mealLibrary = window.EverydayStrongMeals || { categories: {}, recipes: [] };
  const foodLibrary = window.EverydayStrongFoods || { source: "", note: "", groups: {}, foods: [] };
  const foodIndexByCode = new Map(foodLibrary.foods.map(function (food) { return [food[0], food]; }));

  const defaults = {
    name: "Chris",
    goal: "balanced",
    level: "beginner",
    equipment: "both",
    duration: 15,
    lowImpact: true,
    focus: "full",
    calorieGoal: 0
  };

  const goalLabels = {
    balanced: "All-around fitness",
    weight: "Weight loss",
    strength: "Build strength",
    stamina: "More stamina"
  };

  const levelLabels = {
    beginner: "Beginner",
    intermediate: "Intermediate",
    advanced: "Advanced"
  };

  const levelProfiles = {
    beginner: {
      weeklyTarget: 3,
      summary: "Build confidence, control, and consistency.",
      readiness: "Best when you are new, returning after time away, or still learning the movements.",
      coach: "Keep the first round easy. You should be able to say a short sentence while moving. Slow down or rest whenever you need it."
    },
    intermediate: {
      weeklyTarget: 4,
      summary: "More challenging variations, longer work, and shorter recovery.",
      readiness: "Choose this when beginner sessions feel controlled and you can finish 20 minutes with solid form.",
      coach: "Work at a purposeful pace, but keep every repetition clean. Use the easier option whenever your form starts to change."
    },
    advanced: {
      weeklyTarget: 4,
      summary: "Demanding compound movements, sustained work, and precise control.",
      readiness: "Choose this only after building a strong base and completing intermediate sessions comfortably.",
      coach: "Advanced means greater challenge, not rushed form. Keep one or two good repetitions in reserve and take extra recovery when needed."
    }
  };

  const equipmentLabels = {
    bodyweight: "Bodyweight",
    dumbbells: "Dumbbells",
    both: "Bodyweight + dumbbells"
  };

  const focusLabels = {
    full: "Full body",
    weightloss: "Weight loss",
    upper: "Upper body",
    lower: "Legs + glutes",
    core: "Core + posture",
    cardio: "Cardio + stamina",
    firefighter: "Firefighter conditioning",
    mobility: "Mobility + recovery"
  };

  const calorieMealLabels = {
    breakfast: "Breakfast",
    lunch: "Lunch",
    dinner: "Dinner",
    snack: "Snack"
  };

  const warmups = [
    move("easy-march", "Easy march", "Warm-up", "March in place with relaxed shoulders and an easy rhythm.", "Start slower than you think you need to.", ["full", "cardio", "lower"]),
    move("shoulder-rolls", "Shoulder rolls", "Warm-up", "Roll your shoulders back, then reach your arms gently overhead.", "Keep your neck loose and breathe normally.", ["full", "upper", "mobility"]),
    move("practice-hinges", "Practice hinges", "Warm-up", "Push your hips back with soft knees, then stand tall.", "Keep your back long and your weight through your heels.", ["full", "lower", "mobility"]),
    move("side-reaches", "Side reaches", "Warm-up", "Step side to side while reaching one arm gently overhead.", "Use a comfortable range—no forcing.", ["full", "core", "mobility"]),
    move("heel-digs", "Heel digs", "Warm-up", "Tap one heel forward at a time while gently swinging your arms.", "Stay tall and keep the movement easy.", ["full", "cardio", "lower"]),
    move("arm-circles", "Small arm circles", "Warm-up", "Reach your arms out and draw small circles in both directions.", "Keep your shoulders down and make the circles comfortable.", ["full", "upper", "mobility"]),
    move("ankle-rocks", "Ankle rocks", "Warm-up", "Hold a chair and gently rock from your heels toward your toes.", "Use the chair for balance and move slowly.", ["lower", "mobility"])
  ];

  const bodyweight = [
    move("chair-squat", "Chair squat", "Legs", "Sit back toward a sturdy chair, tap the seat, then stand tall.", "Press the floor away and keep your knees tracking over your toes.", ["lower"]),
    move("wall-pushup", "Wall push-up", "Chest + arms", "Lean toward a wall, bend your elbows, then press yourself away.", "Keep one straight line from head to heels.", ["upper", "core"]),
    move("glute-bridge", "Glute bridge", "Glutes + core", "Lie down with knees bent, squeeze your glutes, and lift your hips.", "Pause at the top without arching your lower back.", ["lower", "core"]),
    move("bird-dog", "Bird dog", "Core + back", "From hands and knees, reach the opposite arm and leg long.", "Imagine balancing a glass of water on your back.", ["core", "upper"]),
    move("counter-plank", "Counter plank", "Core", "Place your hands on a counter and hold a strong, straight line.", "Brace gently and keep breathing.", ["core", "upper"]),
    move("calf-raise", "Calf raise", "Lower legs", "Hold a chair, rise onto your toes, pause, and lower slowly.", "Move with control instead of bouncing.", ["lower"]),
    move("step-back-tap", "Step-back tap", "Legs + balance", "Step one foot back, tap the floor, return, then switch sides.", "Hold a chair if you want more stability.", ["lower", "cardio"]),
    move("dead-bug", "Heel-tap dead bug", "Core", "Lie on your back and slowly tap one heel away at a time.", "Keep your ribs down and your lower back comfortable.", ["core"]),
    move("wall-slide", "Wall slide", "Upper back + shoulders", "Stand against a wall and slowly slide your arms up, then down.", "Keep the range small if your shoulders feel tight.", ["upper", "mobility"]),
    move("supported-lunge", "Supported reverse lunge", "Legs + balance", "Hold a chair, step one foot back, bend both knees a little, then return.", "A short step and shallow bend are enough.", ["lower"]),
    move("side-leg-raise", "Standing side leg raise", "Hips + core", "Hold a chair and lift one leg gently to the side, then switch.", "Keep your toes facing forward and your body tall.", ["lower", "core"]),
    move("heel-slide", "Heel slide", "Core + hips", "Lie on your back and slowly slide one heel away, then bring it back.", "Keep your belly gently braced and move one leg at a time.", ["core", "mobility"]),
    move("cross-crunch", "Standing cross-body crunch", "Core + cardio", "Bring one knee toward the opposite elbow, lower, then switch sides.", "Rotate gently and stay tall between repetitions.", ["core", "cardio"]),
    move("side-wall-plank", "Side wall plank", "Side core + shoulders", "Place one forearm on a wall, turn slightly sideways, and hold your body firm.", "Press the wall away and keep breathing.", ["core", "upper"]),
    move("seated-knee-lift", "Seated knee lift", "Core + hips", "Sit tall near the front of a chair and lift one knee at a time.", "Avoid leaning back; make each lift smooth.", ["core", "cardio"]),
    move("good-morning", "Bodyweight good morning", "Glutes + back", "Place your hands across your chest, push your hips back, then stand tall.", "Keep your back long and your knees soft.", ["lower", "mobility"]),
    move("clamshell", "Clamshell", "Outer hips + core", "Lie on your side with knees bent and lift the top knee without rolling back.", "Keep your feet together and use a small range.", ["lower", "core"]),
    move("prone-w-raise", "W raise", "Upper back", "Lie face down or hinge forward, form a W with your arms, and squeeze your shoulder blades.", "Keep your neck long and lift only as far as comfortable.", ["upper", "mobility"]),
    move("counter-shoulder-tap", "Counter shoulder tap", "Core + shoulders", "Hold a counter plank and slowly tap the opposite shoulder with one hand.", "Widen your feet and keep your hips as still as you can.", ["upper", "core"]),
    move("seated-leg-extension", "Seated leg extension", "Thighs", "Sit tall, straighten one knee, lower with control, then switch.", "Pause briefly with the leg straight without locking the knee.", ["lower"])
  ];

  const dumbbells = [
    move("goblet-squat", "Goblet squat", "Legs", "Hold one dumbbell at your chest, sit back, then stand tall.", "Use a chair behind you until the movement feels solid.", ["lower"]),
    move("supported-row", "Supported row", "Back + arms", "Brace one hand on a chair and pull one dumbbell toward your hip.", "Keep your shoulder away from your ear.", ["upper"]),
    move("floor-press", "Dumbbell floor press", "Chest + arms", "Lie down, press the dumbbells over your chest, then lower slowly.", "Let your upper arms touch the floor gently.", ["upper"]),
    move("dumbbell-hinge", "Dumbbell hinge", "Glutes + back", "Hold the weights close, push your hips back, then stand tall.", "Stop when you feel your hamstrings working.", ["lower"]),
    move("suitcase-march", "Suitcase march", "Core + grip", "Hold one dumbbell at your side and march slowly in place.", "Stay tall—do not lean toward the weight.", ["core", "cardio"]),
    move("hammer-curl", "Hammer curl", "Arms", "With palms facing in, curl the weights and lower with control.", "Keep your elbows close to your sides.", ["upper"]),
    move("seated-press", "Seated shoulder press", "Shoulders + arms", "Sit tall and press the dumbbells overhead, then lower slowly.", "Use light weights and stop before your shoulders shrug.", ["upper"]),
    move("sumo-squat", "Dumbbell sumo squat", "Legs + glutes", "Hold one dumbbell, step your feet comfortably wide, sit down, then stand.", "Let your knees follow the direction of your toes.", ["lower"]),
    move("weighted-calf-raise", "Weighted calf raise", "Lower legs + grip", "Hold the dumbbells at your sides, rise onto your toes, then lower slowly.", "Use a wall or chair for balance if needed.", ["lower"]),
    move("triceps-kickback", "Triceps kickback", "Back of arms", "Hinge slightly, keep your elbows high, and straighten your arms behind you.", "Move only at the elbows and keep the weights light.", ["upper"]),
    move("reverse-fly", "Supported reverse fly", "Upper back", "Hinge with one hand supported and lift a light dumbbell out to the side.", "Lead with the elbow and stop below shoulder height.", ["upper"]),
    move("farmer-march", "Farmer march", "Core + grip", "Hold dumbbells at both sides and march slowly without leaning.", "Stand as tall as possible and take controlled steps.", ["core", "cardio"]),
    move("one-arm-floor-press", "One-arm floor press", "Chest + core", "Lie down and press one dumbbell over your chest, then switch sides.", "Brace your middle so your body stays steady.", ["upper", "core"]),
    move("lateral-raise", "Dumbbell lateral raise", "Shoulders", "With soft elbows, lift light dumbbells out to the sides, then lower.", "Stop below shoulder height and avoid swinging.", ["upper"]),
    move("front-rack-march", "Front-rack march", "Core + legs", "Hold one dumbbell at your chest and march slowly in place.", "Keep your ribs stacked over your hips.", ["core", "lower", "cardio"]),
    move("weighted-bridge", "Dumbbell glute bridge", "Glutes + core", "Rest one dumbbell securely across your hips, then lift and lower your hips.", "Hold the weight with both hands and keep the motion controlled.", ["lower", "core"])
  ];

  const intermediateBodyweight = [
    move("bodyweight-squat", "Bodyweight squat", "Legs + glutes", "Sit your hips down and back, reach a comfortable depth, then drive through your whole foot to stand.", "Keep your chest tall and let your knees track in line with your toes.", ["lower"]),
    move("counter-pushup", "Counter push-up", "Chest + arms", "Place your hands on a sturdy counter, lower your chest between your hands, then press away.", "Keep one straight line from your head through your heels.", ["upper", "core"]),
    move("reverse-lunge", "Reverse lunge", "Legs + balance", "Step one foot back, lower both knees with control, then push through the front foot to return.", "Keep most of your pressure through the front mid-foot and heel.", ["lower"]),
    move("forearm-plank", "Forearm plank", "Core + shoulders", "Place your forearms on the floor, extend your legs, and hold a straight, braced body line.", "Squeeze your glutes, keep breathing, and stop before your hips sag.", ["core", "upper"]),
    move("single-leg-bridge", "Single-leg glute bridge", "Glutes + core", "Lie with one knee bent, extend the other leg, and lift your hips by pressing through the planted foot.", "Keep your hips level and use a smaller lift if your hamstring cramps.", ["lower", "core"]),
    move("kneeling-pushup", "Kneeling push-up", "Chest + arms", "From your knees, lower your chest between your hands, then press the floor away.", "Make a straight line from your head to your knees without letting your lower back dip.", ["upper", "core"]),
    move("lateral-lunge", "Lateral lunge", "Legs + hips", "Step wide to one side, sit into that hip while the other leg stays long, then push back to centre.", "Keep the working knee tracking over the toes and both feet facing mostly forward.", ["lower"]),
    move("plank-shoulder-tap", "Plank shoulder tap", "Core + shoulders", "From a high plank, lift one hand to tap the opposite shoulder, replace it, then switch.", "Widen your feet and resist twisting through your hips.", ["core", "upper"])
  ];

  const intermediateDumbbells = [
    move("dumbbell-rdl", "Dumbbell Romanian deadlift", "Glutes + hamstrings", "Hold the weights close to your legs, push your hips back, then squeeze your glutes to stand.", "Stop when your hamstrings feel loaded and your back is still long.", ["lower"]),
    move("double-dumbbell-row", "Two-dumbbell bent-over row", "Back + arms", "Hinge forward with a long back, pull both weights toward your hips, then lower them slowly.", "Keep your ribs down and avoid shrugging or jerking the weights.", ["upper", "core"]),
    move("standing-dumbbell-press", "Standing dumbbell press", "Shoulders + arms", "Brace your middle and press both dumbbells overhead, then lower them with control.", "Keep your ribs stacked over your hips and stop before your shoulders shrug.", ["upper", "core"]),
    move("dumbbell-reverse-lunge", "Dumbbell reverse lunge", "Legs + balance", "Hold the weights at your sides, step one foot back, lower with control, then return to standing.", "Use a stable stance and keep the weights quiet beside you.", ["lower", "core"]),
    move("dumbbell-front-squat", "Dumbbell front squat", "Legs + core", "Hold the dumbbells at your shoulders, sit down between your feet, then stand tall.", "Brace before each repetition and keep your elbows slightly forward.", ["lower", "core"]),
    move("dumbbell-split-squat", "Dumbbell split squat", "Legs + glutes", "Set a staggered stance, lower both knees straight down, then press through the front foot to rise.", "Keep your feet on separate tracks instead of balancing on a tightrope.", ["lower", "core"]),
    move("dumbbell-pullover", "Dumbbell pullover", "Back + chest", "Lie down, hold one dumbbell above your chest, lower it behind your head within control, then pull it back over.", "Keep your ribs down and use a range your shoulders can control.", ["upper", "core"]),
    move("suitcase-deadlift", "Suitcase deadlift", "Glutes + grip", "Place the dumbbells outside your feet, hinge and bend your knees to reach them, then stand tall.", "Push the floor away and keep both weights close to your sides.", ["lower", "core"])
  ];

  const advancedBodyweight = [
    move("full-pushup", "Full push-up", "Chest + arms", "From a high plank, lower your chest between your hands, then press the floor away.", "Keep your elbows angled slightly back and move as one solid unit.", ["upper", "core"]),
    move("pike-pushup", "Pike push-up", "Shoulders + arms", "Lift your hips into an inverted V, bend your elbows to lower your head between your hands, then press up.", "Look toward your feet and keep the pressure even through both palms.", ["upper", "core"]),
    move("single-leg-chair-squat", "Single-leg chair squat", "Legs + balance", "Stand in front of a sturdy chair, reach one foot forward, sit down with control, then stand using the planted leg.", "Use the chair as a target and assist lightly with the other heel whenever needed.", ["lower", "core"]),
    move("side-forearm-plank", "Side forearm plank", "Side core + shoulders", "Stack your feet or stagger them, press through one forearm, and lift your hips into a straight line.", "Keep your shoulder directly above your elbow and your head in line with your spine.", ["core", "upper"]),
    move("bear-shoulder-tap", "Bear-plank shoulder tap", "Core + shoulders", "From hands and knees, hover your knees just off the floor and tap one opposite shoulder at a time.", "Press the floor away and keep your hips as still as possible.", ["core", "upper"]),
    move("tempo-split-squat", "Tempo split squat", "Legs + glutes", "Lower for three slow counts in a split stance, pause briefly, then stand with control.", "Keep steady pressure through the whole front foot throughout the slow descent.", ["lower", "core"]),
    move("plank-knee-drive", "Plank knee drive", "Core + hips", "From a high plank, draw one knee toward your chest, return it fully, then switch sides.", "Keep your shoulders above your hands and avoid bouncing your hips.", ["core", "upper", "cardio"]),
    move("squat-thrust", "Step-back squat thrust", "Full body + cardio", "Squat, place your hands down, step to a plank, step back in, then stand tall.", "Move one foot at a time and establish a strong plank before returning.", ["lower", "core", "cardio"])
  ];

  const advancedDumbbells = [
    move("dumbbell-thruster", "Dumbbell thruster", "Full body", "Hold the dumbbells at your shoulders, squat, then stand powerfully and press overhead.", "Finish the leg drive before locking in a controlled overhead position.", ["lower", "upper", "core", "cardio"]),
    move("single-leg-dumbbell-rdl", "Single-leg dumbbell RDL", "Glutes + balance", "Balance on one leg, hinge as the other leg reaches back, then drive through the planted foot to stand.", "Keep both hip bones facing the floor and use a wall for light support if needed.", ["lower", "core"]),
    move("renegade-row", "Renegade row", "Back + core", "From a wide high plank with hands on dumbbells, row one weight toward your hip, lower it, then switch.", "Use stable flat-sided weights and resist rotating through your trunk.", ["upper", "core"]),
    move("dumbbell-push-press", "Dumbbell push press", "Shoulders + legs", "Dip slightly through your knees, drive up, and use that leg power to press the dumbbells overhead.", "Keep the dip shallow and finish with the weights controlled over your shoulders.", ["upper", "lower", "core"]),
    move("front-rack-reverse-lunge", "Front-rack reverse lunge", "Legs + core", "Hold the dumbbells at your shoulders, step one foot back, lower both knees, then drive up.", "Stay tall and keep your front foot fully planted.", ["lower", "core"]),
    move("bridge-floor-press", "Glute bridge floor press", "Chest + glutes", "Hold a glute bridge while pressing the dumbbells above your chest and lowering your elbows to the floor.", "Keep your hips level and lower the weights only as far as you can control.", ["upper", "lower", "core"]),
    move("plank-dumbbell-drag", "Plank dumbbell drag", "Core + shoulders", "From a wide high plank, reach under with one hand and drag a dumbbell across, then switch sides.", "Use a light, stable dumbbell and keep your hips square to the floor.", ["upper", "core"]),
    move("offset-goblet-squat", "Offset dumbbell squat", "Legs + core", "Hold one dumbbell at one shoulder, squat with control, then stand without leaning toward the weight.", "Brace against the uneven load and switch sides halfway through.", ["lower", "core"])
  ];

  const firefighterBodyweight = [
    move("stair-power-march", "Stair-climb power march", "Cardio + legs", "Drive one knee toward hip height as the opposite arm pumps, then switch at a strong marching pace.", "Stay tall and place each foot quietly under your hips instead of leaning back.", ["firefighter", "cardio", "lower", "core"]),
    move("wall-drive-knees", "Wall-drive knee run", "Cardio + core", "Lean into a wall with straight arms and alternate driving your knees forward at a controlled, powerful rhythm.", "Keep a straight line through your trunk and land each foot beneath your hip.", ["firefighter", "cardio", "lower", "core"]),
    move("bear-crawl-step", "Bear-crawl step", "Shoulders + core", "Hover your knees just above the floor and take short opposite-hand-and-foot steps forward and back.", "Keep your back level, take small steps, and move slowly enough to stay coordinated.", ["firefighter", "cardio", "upper", "core"]),
    move("kneel-to-stand", "Alternating kneel-to-stand", "Legs + floor control", "From a tall kneel, step one foot forward, stand, then reverse the pattern and lead with the other side.", "Use a folded mat and keep your front foot flat before driving up.", ["firefighter", "lower", "core"])
  ];

  const firefighterDumbbells = [
    move("loaded-stair-march", "Loaded stair march", "Legs + grip", "Hold dumbbells at your sides and drive alternating knees upward as if climbing steady stairs.", "Choose a load that lets you stay tall without swinging or leaning.", ["firefighter", "cardio", "lower", "core"]),
    move("front-rack-stair-march", "Front-rack stair march", "Legs + trunk", "Hold the dumbbells at your shoulders and march with strong alternating knee drives.", "Keep your ribs stacked over your hips and reduce the load before your elbows drop.", ["firefighter", "cardio", "lower", "core"]),
    move("supported-power-row", "Supported power row", "Back + grip", "Brace one hand on a sturdy chair and pull one dumbbell toward your hip with purpose, lowering it under control.", "Keep your back long and generate speed only if the weight remains fully controlled.", ["firefighter", "upper", "core"]),
    move("offset-carry-march", "Offset equipment-carry march", "Grip + core", "Hold one dumbbell at your shoulder and the other at your side while marching, then switch positions halfway.", "Stay square and upright; do not let either weight pull you sideways.", ["firefighter", "cardio", "upper", "lower", "core"])
  ];

  const intermediateLowImpactCardio = [
    move("squat-knee-drive", "Squat + knee drive", "Cardio + legs", "Squat with control, stand, then drive one knee up before repeating on the other side.", "Finish each squat before lifting the knee and stay tall at the top.", ["cardio", "lower", "core"]),
    move("lateral-shuffle-step", "Lateral shuffle step", "Cardio + hips", "Take two quick steps to one side, touch lightly, then travel back the other way.", "Stay low enough to feel athletic while keeping every step quiet.", ["cardio", "lower"]),
    move("punch-knee-combo", "Punch + knee combo", "Cardio + core", "Throw two controlled punches, then drive one knee up; repeat with the other side.", "Turn gently through your ribs and keep your standing knee soft.", ["cardio", "upper", "core"]),
    move("fast-step-back", "Fast step-back", "Cardio + legs", "Alternate quick step-backs while your arms pump naturally at your sides.", "Keep your steps short, your chest up, and slow down before form gets loose.", ["cardio", "lower"])
  ];

  const intermediateHigherImpactCardio = [
    move("jog-in-place", "Jog in place", "Cardio", "Jog lightly in place with quick, relaxed steps and natural arm swings.", "Land under your hips and switch to a march whenever needed.", ["cardio"], "high"),
    move("seal-jacks", "Seal jacks", "Cardio + chest", "Jump your feet apart as your arms open wide, then jump in as your hands meet in front.", "Land softly and use alternating side steps for a lower-impact version.", ["cardio", "upper"], "high"),
    move("lateral-pogo", "Small lateral hops", "Cardio + calves", "Hop both feet a few inches side to side while staying tall and springy.", "Keep the hops small, land softly, and switch to side steps if needed.", ["cardio", "lower"], "high"),
    move("quick-feet-forward-back", "Quick feet forward + back", "Cardio", "Take two small quick steps forward and two back while staying light on your feet.", "Keep the travel short and maintain a clear floor around you.", ["cardio"], "high")
  ];

  const advancedLowImpactCardio = [
    move("power-skater-step", "Power skater step", "Cardio + hips", "Drive strongly side to side, reaching the trailing leg behind without leaving the floor.", "Push through the outside foot and keep the landing knee aligned.", ["cardio", "lower"]),
    move("speed-squat-reach", "Fast squat + reach", "Cardio + legs", "Cycle through controlled squats and tall overhead reaches at a challenging pace.", "Keep your heels grounded and reduce the depth before your knees cave inward.", ["cardio", "lower"]),
    move("power-march", "Power march", "Cardio + core", "Drive opposite arm and knee powerfully while marching at a fast, controlled rhythm.", "Stay tall and use forceful arms without leaning back.", ["cardio", "core"]),
    move("floor-mountain-climber", "Controlled mountain climber", "Cardio + core", "From a high plank, alternate driving your knees forward while keeping your upper body steady.", "Keep the steps controlled and slow down before your hips bounce.", ["cardio", "core", "upper"])
  ];

  const advancedHigherImpactCardio = [
    move("jump-squat", "Jump squat", "Cardio + legs", "Squat, jump vertically, land softly, and reset before the next repetition.", "Land through the middle of your feet with soft knees; switch to fast squats at any time.", ["cardio", "lower"], "high"),
    move("burpee", "Burpee", "Full-body cardio", "Squat, plant your hands, hop to a plank, hop back in, then stand or jump tall.", "Own the plank position and use the step-back squat thrust whenever form slips.", ["cardio", "lower", "core", "upper"], "high"),
    move("plank-jack", "Plank jack", "Cardio + core", "From a high plank, hop your feet wide and back together while your upper body stays steady.", "Keep your hands under your shoulders and use alternating toe steps for lower impact.", ["cardio", "core", "upper"], "high"),
    move("split-jump", "Split jump", "Cardio + legs", "From a split stance, jump and switch legs in the air, landing softly into the next repetition.", "Keep the jumps low and switch to reverse lunges if you cannot land quietly.", ["cardio", "lower"], "high")
  ];

  const lowImpactCardio = [
    move("quick-march", "Quick march", "Cardio", "March briskly and let your arms swing naturally.", "Use a pace where you can still say a short sentence.", ["cardio"]),
    move("step-jacks", "Step jacks", "Cardio", "Step one foot out while your arms rise, then switch sides.", "Keep it smooth and low impact—no jumping needed.", ["cardio"]),
    move("shadow-box", "Shadow boxing", "Cardio + arms", "Stand tall and throw easy alternating punches in front of you.", "Keep your knees soft and never lock your elbows.", ["cardio", "upper"]),
    move("side-step", "Side step + reach", "Cardio", "Step side to side and reach your arms forward at chest height.", "Make the steps smaller whenever you need to.", ["cardio"]),
    move("knee-drive", "Standing knee drive", "Cardio + core", "Bring one knee toward your hands, lower it, then switch sides.", "Stay tall and move at your own pace.", ["cardio", "core"]),
    move("heel-dig-pull", "Heel dig + pull", "Cardio + back", "Tap one heel forward while pulling your elbows back, then switch.", "Keep your chest lifted and land softly.", ["cardio", "upper"]),
    move("hamstring-curl", "Standing hamstring curl", "Cardio + legs", "Curl one heel toward your seat while your arms pull down, then switch.", "Keep your knees close and use a steady rhythm.", ["cardio", "lower"]),
    move("toe-tap-forward", "Forward toe taps", "Cardio + balance", "Tap one toe forward, return, and alternate sides while moving your arms.", "A light touch is enough—keep your weight over the standing leg.", ["cardio", "lower"]),
    move("low-skater", "Low-impact skater", "Cardio + hips", "Step diagonally behind you, return, then switch sides.", "Keep it a step, not a jump, and hold a chair if needed.", ["cardio", "lower"]),
    move("power-walk", "Power walk in place", "Cardio", "Walk in place with purposeful arm swings and slightly quicker feet.", "Choose a pace you can control for the whole interval.", ["cardio"]),
    move("front-kick", "Gentle front kick", "Cardio + legs", "Lift one knee, extend the lower leg gently, then switch sides.", "Kick low and never snap or lock the knee.", ["cardio", "lower"]),
    move("step-knee", "Step + knee lift", "Cardio + core", "Step to one side, lift the opposite knee, then repeat the other way.", "Slow the pattern down until it feels natural.", ["cardio", "core"])
  ];

  const higherImpactCardio = [
    move("jumping-jacks", "Jumping jacks", "Cardio", "Jump your feet apart as your arms rise, then return with control.", "Land softly and switch to step jacks at any time.", ["cardio"], "high"),
    move("high-knees", "High knees", "Cardio + core", "Run lightly in place while lifting your knees toward a comfortable height.", "Stay light on your feet and reduce the height before losing form.", ["cardio", "core"], "high"),
    move("skater-hops", "Skater hops", "Cardio + hips", "Hop side to side and let the trailing foot land lightly behind you.", "Use small hops and land with a soft knee.", ["cardio", "lower"], "high"),
    move("fast-feet", "Fast feet", "Cardio", "Take quick, light steps in place with your knees slightly bent.", "Keep your steps small and your chest up.", ["cardio"], "high"),
    move("squat-reach", "Squat + reach", "Cardio + legs", "Sit into a comfortable squat, stand, and reach overhead.", "Move smoothly; the reach can stay below shoulder height.", ["cardio", "lower"], "high"),
    move("counter-climber", "Fast counter climber", "Cardio + core", "Hold a counter plank and drive one knee forward at a time.", "Keep your hips steady and slow down whenever needed.", ["cardio", "core"], "high")
  ];

  const mobility = [
    move("cat-cow", "Cat-cow", "Spine mobility", "From hands and knees, gently round your back, then lengthen it.", "Move with your breath and stay within a pain-free range.", ["mobility", "core"]),
    move("wall-angels", "Wall angels", "Shoulders + upper back", "Stand near a wall and slide your arms up and down like making a snow angel.", "Keep the motion small if your shoulders feel tight.", ["mobility", "upper"]),
    move("open-book", "Open-book rotation", "Upper back", "Lie on your side with knees bent and slowly open your top arm behind you.", "Let your eyes follow your hand without forcing the twist.", ["mobility", "core"]),
    move("hip-flexor-rock", "Supported hip-flexor rock", "Hips", "Take a split stance while holding a chair and gently shift your hips forward and back.", "Keep the movement small and your front foot flat.", ["mobility", "lower"]),
    move("chair-hip-opener", "Chair hip opener", "Hips + glutes", "Sit tall, rest one ankle over the opposite shin, and hinge forward slightly.", "Stop at a gentle stretch and switch sides halfway.", ["mobility", "lower"]),
    move("seated-rotation", "Seated torso rotation", "Upper back + core", "Sit tall with arms crossed and rotate gently from side to side.", "Keep your hips facing forward and move without bouncing.", ["mobility", "core"]),
    move("hamstring-reach", "Supported hamstring reach", "Back of legs", "Place one heel forward, sit your hips back, then switch sides.", "Keep your back long and your toes relaxed.", ["mobility", "lower"]),
    move("thoracic-reach", "Thread-the-needle reach", "Upper back + shoulders", "From hands and knees, reach one arm underneath you, return, then switch.", "Rotate from your upper back and keep your hips steady.", ["mobility", "upper", "core"]),
    move("standing-side-bend", "Standing side bend", "Sides + shoulders", "Reach one arm overhead and lean gently to the opposite side, then switch.", "Stay long through your body instead of folding forward.", ["mobility", "core"]),
    move("shoulder-blade-squeeze", "Shoulder-blade squeeze", "Posture", "Stand tall, draw your shoulder blades gently together, pause, and release.", "Keep your shoulders down and avoid arching your back.", ["mobility", "upper"]),
    move("ankle-knee-drive", "Ankle knee drive", "Ankles + calves", "Hold a chair and guide one knee forward over the toes while the heel stays down.", "Use a small, smooth range and switch sides halfway.", ["mobility", "lower"]),
    move("child-pose-reach", "Supported child’s-pose reach", "Back + shoulders", "From hands and knees, sit your hips back gently while reaching your hands forward.", "Place your hands on a chair if the floor position is uncomfortable.", ["mobility", "core", "upper"])
  ];

  const cooldowns = [
    move("reset-breath", "Breathe + reset", "Cool-down", "Walk slowly in place, then take four calm, unforced breaths.", "Let your heart rate settle gradually.", ["full", "cardio", "core"]),
    move("calf-stretch", "Standing calf stretch", "Cool-down", "Step one foot back, keep the heel down, then switch sides.", "Aim for gentle tension, never pain.", ["lower", "cardio"]),
    move("chest-opener", "Gentle chest opener", "Cool-down", "Clasp your hands behind you or hold a towel and gently open your chest.", "Keep your shoulders down and avoid forcing the stretch.", ["upper", "mobility"]),
    move("figure-four", "Seated figure-four stretch", "Cool-down", "Sit tall, rest one ankle over the opposite shin, then switch sides.", "A gentle stretch is enough; do not press the knee.", ["lower", "mobility"]),
    move("overhead-side-stretch", "Overhead side stretch", "Cool-down", "Reach one arm overhead and lean gently to the other side, then switch.", "Keep both feet grounded and breathe steadily.", ["core", "mobility"]),
    move("back-reset", "Back + shoulder reset", "Cool-down", "Place your hands on a chair, step back, and gently lengthen your back.", "Keep your knees soft and return upright slowly.", ["upper", "core", "mobility"])
  ];

  const weekPlans = {
    beginner: [
      { day: "Mon", title: "Full-body strength", type: "workout", focus: "full" },
      { day: "Tue", title: "Easy walk", type: "walk" },
      { day: "Wed", title: "Core + posture", type: "workout", focus: "core" },
      { day: "Thu", title: "Easy walk", type: "walk" },
      { day: "Fri", title: "Legs + glutes", type: "workout", focus: "lower" },
      { day: "Sat", title: "Family movement", type: "walk" },
      { day: "Sun", title: "Rest + reset", type: "rest" }
    ],
    intermediate: [
      { day: "Mon", title: "Total-body strength", type: "workout", focus: "full" },
      { day: "Tue", title: "Brisk walk", type: "walk" },
      { day: "Wed", title: "Upper body + core", type: "workout", focus: "upper" },
      { day: "Thu", title: "Mobility reset", type: "workout", focus: "mobility" },
      { day: "Fri", title: "Recovery walk", type: "walk" },
      { day: "Sat", title: "Firefighter conditioning", type: "workout", focus: "firefighter" },
      { day: "Sun", title: "Rest", type: "rest" }
    ],
    advanced: [
      { day: "Mon", title: "Advanced total body", type: "workout", focus: "full" },
      { day: "Tue", title: "Upper-body strength", type: "workout", focus: "upper" },
      { day: "Wed", title: "Recovery walk", type: "walk" },
      { day: "Thu", title: "Lower-body strength", type: "workout", focus: "lower" },
      { day: "Fri", title: "Fireground conditioning", type: "workout", focus: "firefighter" },
      { day: "Sat", title: "Mobility + easy movement", type: "walk" },
      { day: "Sun", title: "Full rest", type: "rest" }
    ]
  };

  const weightLossChallenge = Array.from({ length: 30 }, function (_, index) {
    const day = index + 1;
    const rest = [7, 14, 21, 28].indexOf(day) !== -1;
    const phase = day <= 7 ? 1 : day <= 14 ? 2 : day <= 21 ? 3 : 4;
    const minutes = phase === 1 ? 10 : phase === 2 ? 15 : phase === 3 ? 20 : 30;
    const mixed = !rest && phase > 1 && day % 3 === 0;
    return { day: day, rest: rest, minutes: rest ? 0 : minutes, lowImpact: !mixed,
      title: rest ? "Recovery + easy walk" : mixed ? "Mixed-impact burn" : "Low-impact burn" };
  });

  const state = {
    tab: "today",
    settings: Object.assign({}, defaults),
    history: [],
    mealFilter: "all",
    mealFavorites: [],
    calorieEntries: [],
    challengeDone: [],
    activeChallengeDay: null,
    calorieDate: localDateKey(),
    foodSearch: "",
    foodGroup: "all",
    selectedFoodCode: null,
    seed: 8,
    workout: null,
    session: null,
    timer: null,
    toastTimer: null,
    resetArmed: false
  };

  const screen = document.getElementById("screen");
  const sessionEl = document.getElementById("session");
  const guideEl = document.getElementById("exercise-guide");
  const recipeEl = document.getElementById("recipe-detail");
  const foodIndexEl = document.getElementById("food-index");
  const toastEl = document.getElementById("toast");

  function move(id, name, area, instruction, cue, tags, impact) {
    return {
      id: id,
      name: name,
      area: area,
      instruction: instruction,
      cue: cue,
      tags: tags || [],
      impact: impact || "low"
    };
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, function (character) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character];
    });
  }

  function hashText(value) {
    let hash = 0;
    for (let index = 0; index < value.length; index += 1) {
      hash = ((hash * 31) + value.charCodeAt(index)) >>> 0;
    }
    return hash;
  }

  function seededRandom(seed) {
    let value = (seed >>> 0) || 1;
    return function () {
      value = ((value * 1664525) + 1013904223) >>> 0;
      return value / 4294967296;
    };
  }

  function uniqueMoves(pool) {
    const seen = new Set();
    return pool.filter(function (item) {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });
  }

  function pickMoves(pool, count, seed) {
    const shuffled = uniqueMoves(pool).slice();
    const random = seededRandom((seed >>> 0) ^ hashText(shuffled.map(function (item) { return item.id; }).join("|")));
    for (let index = shuffled.length - 1; index > 0; index -= 1) {
      const swapIndex = Math.floor(random() * (index + 1));
      const temporary = shuffled[index];
      shuffled[index] = shuffled[swapIndex];
      shuffled[swapIndex] = temporary;
    }
    return shuffled.slice(0, Math.max(0, count));
  }

  function appendMoves(target, pool, count, seed) {
    const used = new Set(target.map(function (item) { return item.id; }));
    const available = pool.filter(function (item) { return !used.has(item.id); });
    pickMoves(available, count, seed).forEach(function (item) { target.push(item); });
    return target;
  }

  function withTag(pool, tag) {
    return pool.filter(function (item) { return item.tags.indexOf(tag) !== -1; });
  }

  function movementById(id) {
    const allMovements = uniqueMoves(warmups.concat(
      bodyweight, dumbbells, intermediateBodyweight, intermediateDumbbells, advancedBodyweight, advancedDumbbells,
      firefighterBodyweight, firefighterDumbbells,
      lowImpactCardio, higherImpactCardio, intermediateLowImpactCardio, intermediateHigherImpactCardio,
      advancedLowImpactCardio, advancedHigherImpactCardio, mobility, cooldowns
    ));
    return allMovements.find(function (item) { return item.id === id; }) || null;
  }

  function movementStyle(item) {
    const floorMoves = [
      "glute-bridge", "bird-dog", "dead-bug", "heel-slide", "clamshell", "prone-w-raise",
      "floor-press", "one-arm-floor-press", "weighted-bridge", "cat-cow", "open-book",
      "thoracic-reach", "child-pose-reach", "forearm-plank", "single-leg-bridge", "kneeling-pushup",
      "plank-shoulder-tap", "dumbbell-pullover", "full-pushup", "pike-pushup", "side-forearm-plank",
      "bear-shoulder-tap", "plank-knee-drive", "squat-thrust", "renegade-row", "bridge-floor-press",
      "plank-dumbbell-drag", "floor-mountain-climber", "burpee", "plank-jack",
      "bear-crawl-step", "kneel-to-stand"
    ];
    if (floorMoves.indexOf(item.id) !== -1) return "floor";
    if (item.tags.indexOf("cardio") !== -1 || item.area.indexOf("Cardio") !== -1) return "march";
    if (item.tags.indexOf("mobility") !== -1) return "reach";
    if (item.tags.indexOf("lower") !== -1) return "squat";
    if (item.tags.indexOf("upper") !== -1) return "upper";
    return "brace";
  }

  function guideProfile(item) {
    const style = movementStyle(item);
    const weighted = dumbbells.concat(intermediateDumbbells, advancedDumbbells, firefighterDumbbells).some(function (candidate) { return candidate.id === item.id; });
    let setup = "Stand tall in a clear space with your feet comfortable and your shoulders relaxed.";
    let easier = "Slow the movement down, shorten the range, or take a standing rest whenever needed.";
    let watch = "Avoid rushing. Keep every repetition smooth and controlled.";

    if (style === "floor") {
      setup = "Use a clear floor area and a mat or folded towel. Get into position slowly before the timer starts.";
      easier = "Make the movement smaller. If getting to the floor is uncomfortable, choose a standing or chair-supported option.";
      watch = "Keep breathing and avoid forcing your back, neck, hips, or shoulders into an uncomfortable position.";
    } else if (item.tags.indexOf("cardio") !== -1) {
      setup = "Clear enough space to move safely, stand tall, and begin with an easy rhythm.";
      easier = "Slow to a comfortable march, make the steps smaller, or pause until your breathing settles.";
      watch = "Do not chase speed before control. Land softly and keep your breathing steady.";
    } else if (item.tags.indexOf("mobility") !== -1) {
      setup = "Set a relaxed position, soften your knees, and let your shoulders drop away from your ears.";
      easier = "Use a smaller, pain-free range and move more slowly with your breathing.";
      watch = "Never bounce or force a stretch. Gentle tension is enough; sharp pain is not.";
    } else if (item.tags.indexOf("lower") !== -1) {
      setup = "Stand near a sturdy chair or wall, place your feet comfortably, and brace your middle gently.";
      easier = "Hold the chair or wall and use a shallower bend or smaller step.";
      watch = "Keep your knees following the direction of your toes and avoid dropping quickly into the movement.";
    } else if (item.tags.indexOf("upper") !== -1) {
      setup = "Stand or sit tall, brace gently, and keep your shoulders relaxed before moving your arms.";
      easier = "Reduce the range, use the wall or counter version, or move one arm at a time.";
      watch = "Avoid shrugging your shoulders, swinging your arms, or arching your lower back.";
    } else if (item.tags.indexOf("core") !== -1) {
      setup = "Set a stable position and brace your middle as if preparing for a gentle cough.";
      easier = "Move one arm or leg at a time, shorten the range, and take extra rest.";
      watch = "Do not hold your breath or let speed replace control.";
    }

    if (weighted) {
      easier = "Use lighter dumbbells or practise the same motion without weight until it feels controlled.";
      watch += " Keep the weights close and never use momentum to finish a repetition.";
    }
    if (item.impact === "high") {
      easier = "Switch to the stepping version instead of jumping, and slow to a pace you can control.";
    }

    const easierOptions = {
      "forearm-plank": "Lower your knees while keeping a straight line from your head to your knees, or use the counter-plank version.",
      "single-leg-bridge": "Keep both feet planted and use the regular glute bridge.",
      "kneeling-pushup": "Use a sturdy counter or wall and keep the same straight-body pushing pattern.",
      "plank-shoulder-tap": "Place your hands on a counter or lower your knees and widen your stance.",
      "full-pushup": "Lower your knees or move your hands to a sturdy counter while keeping the same body line.",
      "pike-pushup": "Place your hands on a counter and use a smaller elbow bend, or choose a standing dumbbell press.",
      "single-leg-chair-squat": "Let the free heel assist, use a higher chair, or switch to a regular chair squat.",
      "side-forearm-plank": "Bend the bottom knee for support or use the side-wall-plank version.",
      "bear-shoulder-tap": "Keep your knees on the floor or use a high plank against a counter.",
      "renegade-row": "Place your knees down, brace one hand on a chair, or use the two-dumbbell bent-over row.",
      "plank-dumbbell-drag": "Perform the drag from your knees or replace it with a counter shoulder tap.",
      "single-leg-dumbbell-rdl": "Keep the back toes lightly on the floor or use a two-leg dumbbell Romanian deadlift.",
      "dumbbell-thruster": "Use lighter weights and perform a goblet squat followed by a separate controlled press.",
      "burpee": "Step back one foot at a time, remove the jump, or use the step-back squat thrust.",
      "plank-jack": "Step one foot out at a time instead of hopping both feet.",
      "split-jump": "Use alternating reverse lunges without leaving the floor.",
      "wall-drive-knees": "Slow to a deliberate alternating wall march or stand upright and use the stair-climb power march.",
      "bear-crawl-step": "Keep your knees down, move one hand at a time, or use the counter shoulder tap.",
      "kneel-to-stand": "Use a sturdy chair for support, begin from a half-kneel, or perform alternating reverse lunges.",
      "loaded-stair-march": "Use lighter dumbbells or perform the unweighted stair-climb power march.",
      "front-rack-stair-march": "Use one light dumbbell at your chest or switch to the loaded stair march with weights at your sides.",
      "supported-power-row": "Use a lighter dumbbell and slow the pull so every repetition remains controlled.",
      "offset-carry-march": "Use one light dumbbell at your side, or perform an unweighted power march."
    };
    if (easierOptions[item.id]) easier = easierOptions[item.id];

    return { style: style, setup: setup, easier: easier, watch: watch };
  }

  function movementDemo(item) {
    const reducedMotion = Boolean(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
    if (window.EverydayStrongMotion && window.EverydayStrongMotion.render) {
      return window.EverydayStrongMotion.render(item, reducedMotion);
    }
    return '<div class="movement-demo"><strong>Animation unavailable</strong><p>Follow the written steps below for this movement.</p></div>';
  }

  function openGuide(id) {
    const item = movementById(id);
    if (!item) return;
    if (state.session && state.session.running) {
      state.session.running = false;
      renderSession();
    }
    const profile = guideProfile(item);
    guideEl.innerHTML = '<header class="guide-head"><button type="button" class="guide-close" data-action="close-guide" aria-label="Close exercise guide">×</button><div><p class="kicker">EXERCISE GUIDE</p><h2>' +
      escapeHtml(item.name) + '</h2><span>' + escapeHtml(item.area) + '</span></div></header><div class="guide-scroll">' + movementDemo(item) +
      '<p class="demo-note">Exercise-specific joint movement • Use the written steps as your form checklist.</p><section class="guide-steps"><p class="kicker">HOW TO DO IT</p><ol>' +
      '<li><span>1</span><div><strong>Set up</strong><p>' + escapeHtml(profile.setup) + '</p></div></li>' +
      '<li><span>2</span><div><strong>Move</strong><p>' + escapeHtml(item.instruction) + '</p></div></li>' +
      '<li><span>3</span><div><strong>Control it</strong><p>' + escapeHtml(item.cue) + '</p></div></li></ol></section>' +
      '<div class="guide-advice"><section><span>EASIER OPTION</span><p>' + escapeHtml(profile.easier) + '</p></section><section><span>WATCH FOR</span><p>' + escapeHtml(profile.watch) + '</p></section></div>' +
      '<section class="guide-safety"><strong>Listen to your body</strong><p>Quality matters more than speed or repetitions. Stop for pain, dizziness, chest discomfort, or unusual shortness of breath.</p></section>' +
      '<button type="button" class="primary guide-done" data-action="close-guide">Got it</button></div>';
    guideEl.classList.remove("hidden");
    document.body.classList.add("guide-open");
    const closeButton = guideEl.querySelector(".guide-close");
    if (closeButton) closeButton.focus();
  }

  function closeGuide() {
    guideEl.classList.add("hidden");
    guideEl.innerHTML = "";
    document.body.classList.remove("guide-open");
  }

  function toggleDemo(button) {
    const svg = guideEl.querySelector(".motion-svg");
    if (!svg || typeof svg.pauseAnimations !== "function" || typeof svg.unpauseAnimations !== "function") {
      button.disabled = true;
      button.textContent = "Demo playing";
      return;
    }
    const paused = button.getAttribute("data-paused") === "true";
    if (paused) {
      svg.unpauseAnimations();
      button.setAttribute("data-paused", "false");
      button.textContent = "Pause demo";
    } else {
      svg.pauseAnimations();
      button.setAttribute("data-paused", "true");
      button.textContent = "Resume demo";
    }
  }

  function buildWorkout() {
    const level = levelProfiles[state.settings.level] ? state.settings.level : "beginner";
    const timing = {
      beginner: {
        10: { rounds: 2, count: 4, work: 35, rest: 15, warm: 30 },
        15: { rounds: 3, count: 5, work: 35, rest: 15, warm: 35 },
        20: { rounds: 3, count: 6, work: 45, rest: 15, warm: 40 },
        30: { rounds: 4, count: 7, work: 45, rest: 15, warm: 45 }
      },
      intermediate: {
        10: { rounds: 2, count: 4, work: 40, rest: 10, warm: 30 },
        15: { rounds: 3, count: 5, work: 40, rest: 10, warm: 35 },
        20: { rounds: 3, count: 6, work: 45, rest: 10, warm: 40 },
        30: { rounds: 4, count: 7, work: 50, rest: 10, warm: 45 }
      },
      advanced: {
        10: { rounds: 2, count: 4, work: 45, rest: 10, warm: 30 },
        15: { rounds: 3, count: 5, work: 45, rest: 10, warm: 35 },
        20: { rounds: 3, count: 6, work: 50, rest: 10, warm: 40 },
        30: { rounds: 4, count: 7, work: 50, rest: 10, warm: 45 }
      }
    }[level][state.settings.duration];

    const focus = focusLabels[state.settings.focus] ? state.settings.focus : "full";
    const levelBodyweight = level === "advanced" ? advancedBodyweight.concat(intermediateBodyweight.filter(function (item) {
      return ["bodyweight-squat", "reverse-lunge", "forearm-plank", "lateral-lunge", "plank-shoulder-tap"].indexOf(item.id) !== -1;
    })) : level === "intermediate" ? intermediateBodyweight.concat(bodyweight.filter(function (item) {
      return ["bird-dog", "dead-bug", "cross-crunch", "good-morning", "prone-w-raise"].indexOf(item.id) !== -1;
    })) : bodyweight;
    const levelDumbbells = level === "advanced" ? advancedDumbbells.concat(intermediateDumbbells.filter(function (item) {
      return ["dumbbell-rdl", "double-dumbbell-row", "dumbbell-front-squat", "dumbbell-pullover"].indexOf(item.id) !== -1;
    })) : level === "intermediate" ? intermediateDumbbells.concat(dumbbells.filter(function (item) {
      return ["goblet-squat", "supported-row", "floor-press", "suitcase-march", "one-arm-floor-press"].indexOf(item.id) !== -1;
    })) : dumbbells;
    const bodyweightSupport = levelBodyweight.filter(function (item) {
      return item.tags.indexOf("core") !== -1;
    });
    let strengthPool;
    if (state.settings.equipment === "bodyweight") strengthPool = levelBodyweight;
    else if (state.settings.equipment === "dumbbells") strengthPool = levelDumbbells.concat(bodyweightSupport);
    else strengthPool = levelDumbbells.concat(levelBodyweight);

    let cardioPool = level === "advanced" ? advancedLowImpactCardio.concat(intermediateLowImpactCardio) :
      level === "intermediate" ? intermediateLowImpactCardio.concat(lowImpactCardio.filter(function (item) {
        return ["shadow-box", "knee-drive", "low-skater", "step-knee", "power-walk"].indexOf(item.id) !== -1;
      })) : lowImpactCardio;
    if (!state.settings.lowImpact) {
      cardioPool = cardioPool.concat(higherImpactCardio);
      if (level === "intermediate" || level === "advanced") cardioPool = cardioPool.concat(intermediateHigherImpactCardio);
      if (level === "advanced") cardioPool = cardioPool.concat(advancedHigherImpactCardio);
    }
    let firefighterPool = firefighterBodyweight.slice();
    if (state.settings.equipment !== "bodyweight") firefighterPool = firefighterDumbbells.concat(firefighterPool);
    const firefighterCarryPool = firefighterPool.filter(function (item) {
      return ["stair-power-march", "loaded-stair-march", "front-rack-stair-march", "offset-carry-march"].indexOf(item.id) !== -1;
    });
    const firefighterConditioningPool = firefighterPool.filter(function (item) {
      return item.tags.indexOf("cardio") !== -1;
    }).concat(cardioPool);
    const firefighterStrengthPool = firefighterPool.concat(strengthPool);
    const upperPool = withTag(strengthPool, "upper");
    const lowerPool = withTag(strengthPool, "lower");
    const corePool = withTag(strengthPool, "core");
    const energeticGoal = state.settings.goal === "weight" || state.settings.goal === "stamina";
    const chosen = [];

    if (focus === "full") {
      let cardioCount = Math.max(1, Math.floor(timing.count / 3));
      if (energeticGoal) cardioCount = Math.min(3, Math.ceil(timing.count / 2));
      if (state.settings.goal === "strength") cardioCount = timing.count >= 6 ? 1 : 0;
      appendMoves(chosen, strengthPool, timing.count - cardioCount, state.seed + 11);
      appendMoves(chosen, cardioPool, cardioCount, state.seed + 13);
      appendMoves(chosen, strengthPool.concat(cardioPool), timing.count - chosen.length, state.seed + 15);
    } else if (focus === "upper") {
      const cardioCount = energeticGoal ? Math.min(2, timing.count - 2) : 1;
      const coreCount = timing.count >= 6 ? 1 : 0;
      appendMoves(chosen, upperPool, timing.count - cardioCount - coreCount, state.seed + 17);
      appendMoves(chosen, corePool, coreCount, state.seed + 19);
      appendMoves(chosen, cardioPool, cardioCount, state.seed + 21);
      appendMoves(chosen, upperPool.concat(corePool, cardioPool), timing.count - chosen.length, state.seed + 23);
    } else if (focus === "lower") {
      const cardioCount = energeticGoal ? Math.min(2, timing.count - 2) : 1;
      const coreCount = timing.count >= 6 ? 1 : 0;
      appendMoves(chosen, lowerPool, timing.count - cardioCount - coreCount, state.seed + 25);
      appendMoves(chosen, corePool, coreCount, state.seed + 27);
      appendMoves(chosen, cardioPool, cardioCount, state.seed + 29);
      appendMoves(chosen, lowerPool.concat(corePool, cardioPool), timing.count - chosen.length, state.seed + 31);
    } else if (focus === "core") {
      const cardioCount = energeticGoal ? 1 : 0;
      const mobilityCount = timing.count >= 5 ? 1 : 0;
      appendMoves(chosen, corePool, timing.count - cardioCount - mobilityCount, state.seed + 33);
      appendMoves(chosen, mobility, mobilityCount, state.seed + 35);
      appendMoves(chosen, cardioPool, cardioCount, state.seed + 37);
      appendMoves(chosen, corePool.concat(mobility, cardioPool), timing.count - chosen.length, state.seed + 39);
    } else if (focus === "cardio") {
      const strengthCount = state.settings.goal === "strength" ? 2 : 1;
      appendMoves(chosen, cardioPool, timing.count - strengthCount, state.seed + 41);
      appendMoves(chosen, strengthPool, strengthCount, state.seed + 43);
      appendMoves(chosen, cardioPool.concat(strengthPool), timing.count - chosen.length, state.seed + 45);
    } else if (focus === "weightloss") {
      const cardioCount = Math.max(2, Math.ceil(timing.count / 2));
      appendMoves(chosen, cardioPool, cardioCount, state.seed + 71);
      appendMoves(chosen, lowerPool.concat(upperPool, corePool), timing.count - chosen.length, state.seed + 73);
      appendMoves(chosen, cardioPool.concat(strengthPool), timing.count - chosen.length, state.seed + 75);
    } else if (focus === "firefighter") {
      const conditioningCount = level === "beginner" ? Math.max(1, Math.floor(timing.count / 3)) : Math.max(2, Math.ceil(timing.count / 2));
      appendMoves(chosen, firefighterCarryPool, 1, state.seed + 91);
      appendMoves(chosen, firefighterConditioningPool, Math.max(0, conditioningCount - 1), state.seed + 93);
      appendMoves(chosen, firefighterStrengthPool, timing.count - chosen.length, state.seed + 95);
      appendMoves(chosen, firefighterPool.concat(cardioPool, strengthPool), timing.count - chosen.length, state.seed + 97);
    } else {
      const coreCount = timing.count >= 6 ? 1 : 0;
      appendMoves(chosen, mobility, timing.count - coreCount, state.seed + 47);
      appendMoves(chosen, corePool, coreCount, state.seed + 49);
      appendMoves(chosen, mobility.concat(corePool), timing.count - chosen.length, state.seed + 51);
    }

    const ordered = pickMoves(chosen, chosen.length, state.seed + 53);

    const main = ordered.map(function (item) {
      return Object.assign({}, item, { seconds: timing.work, kind: "work" });
    });
    const matchingWarmups = warmups.filter(function (item) {
      return item.tags.indexOf(focus) !== -1 || item.tags.indexOf("full") !== -1;
    });
    const matchingCooldowns = cooldowns.filter(function (item) {
      return item.tags.indexOf(focus) !== -1 || item.tags.indexOf("full") !== -1;
    });
    const warm = pickMoves(matchingWarmups.length >= 2 ? matchingWarmups : warmups, 2, state.seed + 3).map(function (item) {
      return Object.assign({}, item, { seconds: timing.warm, kind: "warmup" });
    });
    const cool = pickMoves(matchingCooldowns.length ? matchingCooldowns : cooldowns, 1, state.seed + 31).map(function (item) {
      return Object.assign({}, item, { seconds: 50, kind: "cooldown" });
    });

    const timeline = warm.slice();
    for (let round = 1; round <= timing.rounds; round += 1) {
      main.forEach(function (item, index) {
        timeline.push(Object.assign({}, item, { id: item.id + "-" + round, baseId: item.id, round: round }));
        if (index < main.length - 1 || round < timing.rounds) {
          timeline.push({
            id: "rest-" + round + "-" + index,
            name: "Catch your breath",
            area: "Round " + round + " of " + timing.rounds,
            instruction: "Stand tall, loosen your shoulders, and breathe steadily.",
            cue: focus === "mobility" ? "Stay relaxed and use a comfortable range." : focus === "firefighter" ? "Use the recovery. Resume only when you can control your breathing and technique." : focus === "weightloss" ? "Let your breathing settle. Consistency matters more than speed." : level === "advanced" ? "Use the recovery. Strong form matters more than squeezing out extra speed." : "Ready is better than rushed. Take extra time if you need it.",
            seconds: timing.rest,
            kind: "rest",
            round: round
          });
        }
      });
    }
    timeline.push.apply(timeline, cool);

    const titleSets = {
      beginner: {
        full: ["Full-Body Foundation", "Everyday Strong Circuit", "Total-Body Builder"],
        upper: ["Upper-Body Builder", "Push + Pull Basics", "Arms, Chest + Back"],
        lower: ["Legs + Glutes Builder", "Lower-Body Foundation", "Strong Steps"],
        core: ["Core + Posture", "Everyday Stability", "Strong Middle Session"],
        cardio: ["Low-Impact Cardio", "Stamina Step-Up", "Move-More Circuit"],
        weightloss: ["Weight-Loss Starter", "Low-Impact Calorie Burn", "Strength + Cardio Mix"],
        mobility: ["Mobility Reset", "Move-Easier Session", "Recovery Flow"],
        firefighter: ["Firefighter Foundation", "Stair + Carry Basics", "Ready-for-Duty Starter"]
      },
      intermediate: {
        full: ["Progressive Total Body", "Strength + Stamina Circuit", "Next-Level Full Body"],
        upper: ["Upper-Body Progression", "Push, Pull + Brace", "Strong Shoulders + Back"],
        lower: ["Leg Strength Progression", "Lunge + Hinge Builder", "Lower-Body Drive"],
        core: ["Core Control Circuit", "Plank + Stability Builder", "Strong Trunk Session"],
        cardio: ["Intermediate Conditioning", "Purposeful-Pace Circuit", "Stamina Builder Plus"],
        weightloss: ["Weight-Loss Momentum", "Strength + Cardio Burn", "Total-Body Calorie Burner"],
        mobility: ["Mobility + Control", "Active Recovery Flow", "Range + Stability Reset"],
        firefighter: ["Fireground Engine", "Stairs, Carries + Core", "Shift-Ready Conditioning"]
      },
      advanced: {
        full: ["Advanced Strength Circuit", "Total-Body Performance", "Compound Power Session"],
        upper: ["Advanced Push + Pull", "Upper-Body Performance", "Shoulder + Core Challenge"],
        lower: ["Advanced Legs + Glutes", "Unilateral Strength Circuit", "Lower-Body Performance"],
        core: ["Advanced Core Control", "Anti-Rotation Challenge", "Plank Strength Circuit"],
        cardio: ["Advanced Conditioning", "High-Output Circuit", "Power + Stamina Session"],
        weightloss: ["Advanced Weight-Loss Circuit", "High-Output Calorie Burn", "Strength + Conditioning"],
        mobility: ["Advanced Recovery Flow", "Mobility Under Control", "Athletic Reset"],
        firefighter: ["Fireground High Output", "Rescue Strength + Stamina", "Duty-Ready Challenge"]
      }
    };
    const titles = titleSets[level][focus];

    return {
      title: titles[state.seed % titles.length],
      eyebrow: levelLabels[level] + (focus === "firefighter" ? " • firefighter conditioning • " : focus === "weightloss" ? " • weight-loss workout • " : " • ") + (state.settings.lowImpact ? "low impact" : "mixed impact"),
      level: level,
      focus: focus,
      rounds: timing.rounds,
      minutes: state.settings.duration,
      main: main,
      timeline: timeline
    };
  }

  function localDateKey(date) {
    const current = date || new Date();
    const month = String(current.getMonth() + 1).padStart(2, "0");
    const day = String(current.getDate()).padStart(2, "0");
    return current.getFullYear() + "-" + month + "-" + day;
  }

  function dateFromKey(key) {
    const parts = key.split("-").map(Number);
    return new Date(parts[0], parts[1] - 1, parts[2]);
  }

  function dayDistance(from, to) {
    const fromUtc = Date.UTC(from.getFullYear(), from.getMonth(), from.getDate());
    const toUtc = Date.UTC(to.getFullYear(), to.getMonth(), to.getDate());
    return Math.round((toUtc - fromUtc) / 86400000);
  }

  function streakCount() {
    const unique = Array.from(new Set(state.history.map(function (item) { return item.date; })))
      .map(dateFromKey)
      .sort(function (a, b) { return b.getTime() - a.getTime(); });
    if (!unique.length || dayDistance(unique[0], new Date()) > 1) return 0;
    let streak = 1;
    for (let index = 1; index < unique.length; index += 1) {
      if (dayDistance(unique[index], unique[index - 1]) === 1) streak += 1;
      else break;
    }
    return streak;
  }

  function weekStart() {
    const now = new Date();
    const offset = now.getDay() === 0 ? -6 : 1 - now.getDay();
    const monday = new Date(now);
    monday.setDate(now.getDate() + offset);
    monday.setHours(0, 0, 0, 0);
    return monday;
  }

  function thisWeekWorkouts() {
    const start = weekStart();
    return state.history.filter(function (item) {
      return item.type === "workout" && dateFromKey(item.date) >= start;
    }).length;
  }

  function formatDate(key) {
    return dateFromKey(key).toLocaleDateString("en-CA", { month: "short", day: "numeric" });
  }

  function formatTimer(seconds) {
    return Math.floor(seconds / 60) + ":" + String(seconds % 60).padStart(2, "0");
  }

  function load() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (saved) {
        state.settings = Object.assign({}, defaults, saved.settings || {});
        if (!focusLabels[state.settings.focus]) state.settings.focus = "full";
        if (!levelProfiles[state.settings.level]) state.settings.level = "beginner";
        state.settings.calorieGoal = Math.max(0, Math.min(10000, Number(state.settings.calorieGoal) || 0));
        state.history = Array.isArray(saved.history) ? saved.history : [];
        state.challengeDone = Array.isArray(saved.challengeDone) ? saved.challengeDone.filter(function (day) {
          return Number.isInteger(day) && day >= 1 && day <= 30;
        }) : [];
        state.mealFavorites = Array.isArray(saved.mealFavorites) ? saved.mealFavorites.filter(function (id) {
          return mealLibrary.recipes.some(function (recipe) { return recipe.id === id; });
        }) : [];
        state.calorieEntries = Array.isArray(saved.calorieEntries) ? saved.calorieEntries.filter(function (entry) {
          return entry && typeof entry.id === "string" && /^\d{4}-\d{2}-\d{2}$/.test(entry.date) &&
            typeof entry.label === "string" && Number(entry.calories) > 0 && Number(entry.calories) <= 10000;
        }).map(function (entry) {
          return {
            id: entry.id,
            date: entry.date,
            label: entry.label.slice(0, 60),
            calories: Math.round(Number(entry.calories)),
            meal: ["breakfast", "lunch", "dinner", "snack"].indexOf(entry.meal) !== -1 ? entry.meal : "snack",
            recipeId: typeof entry.recipeId === "string" ? entry.recipeId : "",
            foodCode: Number(entry.foodCode) || 0
          };
        }) : [];
        state.seed = typeof saved.seed === "number" ? saved.seed : 8;
      }
    } catch (error) {
      state.settings = Object.assign({}, defaults);
      state.history = [];
      state.mealFavorites = [];
      state.calorieEntries = [];
      state.challengeDone = [];
      state.seed = 8;
    }
    state.workout = buildWorkout();
  }

  function save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      settings: state.settings,
      history: state.history,
      mealFavorites: state.mealFavorites,
      calorieEntries: state.calorieEntries,
      challengeDone: state.challengeDone,
      seed: state.seed
    }));
  }

  function render() {
    state.workout = buildWorkout();
    screen.innerHTML = state.tab === "today" ? todayView() :
      state.tab === "plan" ? planView() :
      state.tab === "meals" ? mealsView() :
      state.tab === "progress" ? progressView() : settingsView();
    document.querySelectorAll("[data-tab]").forEach(function (button) {
      button.classList.toggle("active", button.getAttribute("data-tab") === state.tab);
    });
    screen.scrollTop = 0;
    window.scrollTo(0, 0);
  }

  function sectionHead(kicker, heading, copy) {
    return '<section class="section-head"><p class="kicker">' + kicker + '</p><h1>' + heading + '</h1><p>' + copy + '</p></section>';
  }

  function todayView() {
    const weekly = thisWeekWorkouts();
    const name = escapeHtml(state.settings.name || "Chris");
    const level = levelProfiles[state.settings.level] ? state.settings.level : "beginner";
    const levelProfile = levelProfiles[level];
    const levelHtml = Object.keys(levelLabels).map(function (key) {
      return '<button type="button" data-setting="level" data-value="' + key + '" class="' + (level === key ? 'selected' : '') + '"><strong>' +
        levelLabels[key] + '</strong><span>' + escapeHtml(levelProfiles[key].summary) + '</span></button>';
    }).join("");
    const focusHtml = Object.keys(focusLabels).map(function (key) {
      return '<button type="button" data-setting="focus" data-value="' + key + '" class="' + (key === "firefighter" ? 'firefighter-focus ' : key === "weightloss" ? 'weightloss-focus ' : '') + (state.settings.focus === key ? 'selected' : '') + '">' + escapeHtml(focusLabels[key]) + '</button>';
    }).join("");
    const firefighterSelected = state.workout.focus === "firefighter";
    const firefighterCoach = level === "beginner" ? "Use this as preparation for harder fire-service conditioning. Keep a controlled pace and master the stair, carry, crawl, and floor-transfer patterns first." :
      level === "intermediate" ? "This is high-intensity work. Push the work intervals, but finish every carry, crawl, pull, and floor transition with enough control to repeat it safely." :
      "Train at high output without turning the circuit into a test. Choose loads you can control, use every recovery interval, and stop before heat, fatigue, or poor technique takes over.";
    const firefighterNote = firefighterSelected ? '<section class="firefighter-note"><span class="firefighter-mark">FF</span><div><p class="kicker">FIRE-SERVICE FITNESS</p><h2>Train for the demands—not in gear.</h2><p>Use normal workout clothing in a clear, cool space. Do not restrict breathing or wear turnout gear or SCBA for unsupervised conditioning. Follow your department’s medical and fitness policies.</p></div></section>' : '';
    const movesHtml = state.workout.main.map(function (item, index) {
      return '<article class="move" data-move-id="' + escapeHtml(item.id) + '" data-impact="' + escapeHtml(item.impact) + '"><span class="move-num">' + String(index + 1).padStart(2, "0") + '</span><div class="move-copy"><h3>' +
        escapeHtml(item.name) + '</h3><p>' + escapeHtml(item.area) + '</p><button type="button" class="howto-link" data-action="show-guide" data-move-id="' + escapeHtml(item.id) + '" aria-label="How to do ' + escapeHtml(item.name) + '"><span>?</span> How to</button></div><span class="move-time">' + item.seconds + 's</span></article>';
    }).join("");

    return '<section class="hero"><div><p class="kicker">TODAY\'S SESSION</p><h1>Ready when you are, ' + name + '.</h1>' +
      '<p class="hero-copy">One focused workout. No gym, no subscription, no pressure to be perfect.</p></div>' +
      '<div class="week-ring" style="--fill:' + Math.min(100, weekly / levelProfile.weeklyTarget * 100) + '%" aria-label="' + weekly + ' of ' + levelProfile.weeklyTarget + ' workouts complete"><span><strong>' + weekly + '</strong>/' + levelProfile.weeklyTarget + '</span></div></section>' +
      '<section class="level-picker"><div><p class="kicker">CHOOSE YOUR LEVEL</p><h2>How hard should today feel?</h2><p>' + escapeHtml(levelProfile.readiness) + '</p></div><div class="level-grid">' + levelHtml + '</div></section>' +
      '<section class="focus-picker"><div><p class="kicker">PICK YOUR WORKOUT</p><h2>What do you want to train?</h2></div><div class="focus-grid">' + focusHtml + '</div></section>' +
      '<section class="workout-card"><div class="workout-head"><div><p class="eyebrow">' + state.workout.eyebrow + '</p><h2>' + escapeHtml(state.workout.title) + '</h2></div>' +
      '<div class="time-stamp"><strong>' + state.workout.minutes + '</strong><span>MIN</span></div></div>' +
      '<div class="meta"><span>' + focusLabels[state.workout.focus] + '</span><span>' + state.workout.rounds + ' rounds</span><span>' + equipmentLabels[state.settings.equipment] + '</span><span>' + goalLabels[state.settings.goal] + '</span></div>' +
      '<div class="moves">' + movesHtml + '</div><div class="card-actions"><button class="primary" type="button" data-action="start">Start guided workout <span>→</span></button>' +
      '<button class="text-button" type="button" data-action="fresh">Give me a different workout</button></div></section>' +
      firefighterNote + '<section class="coach-note"><span class="coach-badge">COACH<br>NOTE</span><p><strong>' + (firefighterSelected ? 'Firefighter guidance.' : levelLabels[level] + ' guidance.') + '</strong> ' + escapeHtml(firefighterSelected ? firefighterCoach : levelProfile.coach) + '</p></section>';
  }

  function planView() {
    const level = levelProfiles[state.settings.level] ? state.settings.level : "beginner";
    const plan = weekPlans[level];
    const planCopy = {
      beginner: { heading: "A plan built for real life.", intro: "Three short strength sessions, easy movement between them, and a proper reset day.", title: "Consistency first. More minutes later.", body: "Your first target is simply to complete three workouts. Walks can be short; every active minute still counts." },
      intermediate: { heading: "Build on your foundation.", intro: "Four purposeful sessions balance strength, mobility, and recovery across the week.", title: "Progress one thing at a time.", body: "Add difficulty only while your technique stays steady. You can shorten a session or switch back to beginner for any movement." },
      advanced: { heading: "Train hard and recover well.", intro: "Four demanding sessions leave space between harder muscle groups and include essential recovery.", title: "Challenge needs control.", body: "Advanced sessions should feel demanding without becoming sloppy. Keep recovery days easy and step down a level whenever fatigue changes your form." }
    }[level];
    const dayIndex = new Date().getDay() === 0 ? 6 : new Date().getDay() - 1;
    const todayKey = localDateKey();
    const rows = plan.map(function (item, index) {
      const isToday = index === dayIndex;
      const done = isToday && state.history.some(function (historyItem) {
        return historyItem.date === todayKey && historyItem.type === item.type;
      });
      let action = '<span class="rest-tag">' + item.type.toUpperCase() + '</span>';
      if (item.type === "workout") action = '<button class="mini' + (done ? ' done' : '') + '" type="button" data-action="open-workout" data-focus="' + item.focus + '">' + (done ? 'DONE' : 'OPEN') + '</button>';
      if (item.type === "walk" && isToday) action = '<button class="mini' + (done ? ' done' : '') + '" type="button" data-action="log-walk" data-title="' + escapeHtml(item.title) + '"' + (done ? ' disabled' : '') + '>' + (done ? 'DONE' : 'LOG') + '</button>';
      const detail = item.type === "workout" ? levelLabels[level] + ' ' + focusLabels[item.focus].toLowerCase() + ' • ' + state.settings.duration + ' min' : item.type === "walk" ? '10–25 min • comfortable pace' : 'Rest is part of the plan';
      return '<article class="plan-day' + (isToday ? ' today' : '') + '"><div class="plan-date"><strong>' + item.day + '</strong>' + (isToday ? '<small>TODAY</small>' : '') + '</div>' +
        '<div><h2>' + item.title + '</h2><p>' + detail + '</p></div>' + action + '</article>';
    }).join("");

    const challengeRows = weightLossChallenge.map(function (item) {
      const done = state.challengeDone.indexOf(item.day) !== -1;
      const mode = item.rest ? "Recovery day" : item.minutes + " min • " + (item.lowImpact ? "low impact" : "mixed impact");
      return '<article class="challenge-day' + (done ? ' done' : '') + '"><span class="challenge-number">' + item.day + '</span><div><strong>' + item.title + '</strong><small>' + mode + '</small></div>' +
        (item.rest ? '<button type="button" class="mini" data-action="challenge-rest" data-day="' + item.day + '">' + (done ? 'UNDO' : 'DONE') + '</button>' :
          '<button type="button" class="mini' + (done ? ' done' : '') + '" data-action="start-challenge" data-day="' + item.day + '">' + (done ? 'AGAIN' : 'START') + '</button>') + '</article>';
    }).join("");
    const challengeProgress = Math.round((state.challengeDone.length / 30) * 100);
    const challenge = '<section class="challenge-card"><div class="challenge-head"><div><p class="kicker">30-DAY WEIGHT-LOSS CHALLENGE</p><h2>Build from 10 to 30 minutes.</h2><p>Low-impact sessions, mixed-impact options, strength, cardio, and planned recovery days.</p></div><strong>' + state.challengeDone.length + '/30</strong></div>' +
      '<div class="challenge-progress"><span style="width:' + challengeProgress + '%"></span></div><div class="challenge-list">' + challengeRows + '</div></section>';

    return sectionHead(levelLabels[level].toUpperCase() + " WEEK", planCopy.heading, planCopy.intro) +
      challenge + '<div class="plan-list">' + rows + '</div><section class="build-card"><div><p class="kicker">BUILD GRADUALLY</p><h2>' + planCopy.title + '</h2></div>' +
      '<p>' + planCopy.body + '</p></section>';
  }

  function recipeById(id) {
    return mealLibrary.recipes.find(function (recipe) { return recipe.id === id; }) || null;
  }

  function isMealFavorite(id) {
    return state.mealFavorites.indexOf(id) !== -1;
  }

  function visibleRecipes() {
    if (state.mealFilter === "favorites") {
      return mealLibrary.recipes.filter(function (recipe) { return isMealFavorite(recipe.id); });
    }
    if (state.mealFilter === "vegetarian") {
      return mealLibrary.recipes.filter(function (recipe) { return recipe.vegetarian; });
    }
    if (mealLibrary.categories[state.mealFilter]) {
      return mealLibrary.recipes.filter(function (recipe) { return recipe.category === state.mealFilter; });
    }
    return mealLibrary.recipes.slice();
  }

  function mealFilterButton(key, label) {
    const count = key === "favorites" ? state.mealFavorites.length : null;
    return '<button type="button" data-action="meal-filter" data-filter="' + key + '" class="' + (state.mealFilter === key ? 'selected' : '') + '">' +
      escapeHtml(label) + (count !== null ? '<span>' + count + '</span>' : '') + '</button>';
  }

  function calorieEntriesForDate(key) {
    return state.calorieEntries.filter(function (entry) { return entry.date === key; });
  }

  function calorieDateHeading() {
    const todayKey = localDateKey();
    if (state.calorieDate === todayKey) return "Today";
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (state.calorieDate === localDateKey(yesterday)) return "Yesterday";
    return dateFromKey(state.calorieDate).toLocaleDateString("en-CA", { weekday: "long", month: "short", day: "numeric" });
  }

  function calorieCounterView() {
    const entries = calorieEntriesForDate(state.calorieDate);
    const total = entries.reduce(function (sum, entry) { return sum + entry.calories; }, 0);
    const goal = state.settings.calorieGoal;
    const percent = goal ? Math.min(100, Math.round(total / goal * 100)) : 0;
    const over = Boolean(goal && total > goal);
    const balance = goal ? (over ? (total - goal) + " Cal over" : (goal - total) + " Cal left") : "Tracking only";
    const todayKey = localDateKey();
    const entryHtml = entries.length ? entries.map(function (entry) {
      const mealLabel = calorieMealLabels[entry.meal] || "Food";
      return '<article class="calorie-entry" data-calorie-id="' + escapeHtml(entry.id) + '"><span class="calorie-meal-mark ' + entry.meal + '">' + mealLabel.slice(0, 1) + '</span><div><h3>' +
        escapeHtml(entry.label) + '</h3><p>' + escapeHtml(mealLabel) + (entry.recipeId ? ' • Recipe' : entry.foodCode ? ' • Food index' : '') + '</p></div><strong>' + entry.calories + '<small>Cal</small></strong>' +
        '<button type="button" data-action="remove-calories" data-calorie-id="' + escapeHtml(entry.id) + '" aria-label="Remove ' + escapeHtml(entry.label) + '">×</button></article>';
    }).join("") : '<div class="calorie-empty"><strong>Nothing logged yet.</strong><p>Add a meal below or log one of the recipes.</p></div>';
    const mealOptions = Object.keys(calorieMealLabels).map(function (key) {
      return '<option value="' + key + '">' + calorieMealLabels[key] + '</option>';
    }).join("");

    return '<section class="calorie-counter"><header class="calorie-head"><div><p class="kicker">CALORIE COUNTER</p><h2>' + calorieDateHeading() + '</h2></div><div class="calorie-date-controls">' +
      '<button type="button" data-action="shift-calorie-date" data-shift="-1" aria-label="Previous day">←</button><button type="button" data-action="shift-calorie-date" data-shift="1" aria-label="Next day"' +
      (state.calorieDate === todayKey ? ' disabled' : '') + '>→</button></div></header><div class="calorie-summary"><div class="calorie-ring ' + (over ? 'over' : '') + '" style="--calorie-progress:' + percent + '%" aria-label="' + total +
      (goal ? ' of ' + goal : '') + ' calories"><div><strong>' + total + '</strong><span>CAL</span></div></div><div class="calorie-summary-copy"><span>' + (goal ? goal + ' Cal daily goal' : 'No daily goal set') + '</span><strong>' + balance + '</strong><p>' +
      (goal ? percent + '% of your selected goal' : 'You can count calories without choosing a target.') + '</p><button type="button" data-action="calorie-settings">' + (goal ? 'Change goal' : 'Set optional goal') + '</button></div></div>' +
      '<div class="calorie-log"><div class="calorie-log-head"><h3>Food log</h3><span>' + entries.length + ' item' + (entries.length === 1 ? '' : 's') + '</span></div>' + entryHtml + '</div>' +
      '<div class="food-index-launch"><div><p class="kicker">OFFLINE FOOD INDEX</p><h3>Find calories in ' + foodLibrary.foods.length.toLocaleString("en-CA") + ' foods.</h3><p>Search Health Canada’s Canadian Nutrient File and tap a food to choose your serving.</p></div>' +
      '<button type="button" data-action="open-food-index">Browse foods <span>→</span></button></div>' +
      '<div class="calorie-add"><p class="kicker">CAN’T FIND IT? QUICK ADD</p><div class="calorie-add-grid"><input id="calorie-label" maxlength="60" autocomplete="off" placeholder="Food or meal name" aria-label="Food or meal name">' +
      '<div class="calorie-amount"><input id="calorie-amount" type="number" min="1" max="5000" step="1" inputmode="numeric" placeholder="Calories" aria-label="Calories"><span>Cal</span></div>' +
      '<select id="calorie-meal" aria-label="Meal type">' + mealOptions + '</select><button type="button" data-action="add-calories">Add to ' + escapeHtml(calorieDateHeading().toLowerCase()) + '</button></div></div>' +
      '<p class="calorie-disclaimer">Use package serving sizes when available. Counts are estimates, and your goal is a personal tracking setting—not medical advice.</p></section>';
  }

  function recipeCard(recipe, index) {
    const favorite = isMealFavorite(recipe.id);
    const category = mealLibrary.categories[recipe.category] || "Recipe";
    const tags = recipe.tags.slice(0, 2).map(function (tag) {
      return '<span>' + escapeHtml(tag) + '</span>';
    }).join("");
    return '<article class="recipe-card" data-recipe-id="' + escapeHtml(recipe.id) + '"><div class="recipe-art ' + recipe.category + '"><div class="recipe-number">' +
      String(index + 1).padStart(2, "0") + '</div><div class="recipe-art-copy"><small>' + escapeHtml(category) + '</small><strong>' + recipe.protein + 'g</strong><span>protein</span></div></div>' +
      '<div class="recipe-card-body"><div class="recipe-tags">' + tags + '</div><h2>' + escapeHtml(recipe.title) + '</h2><p>' + escapeHtml(recipe.blurb) + '</p>' +
      '<div class="recipe-stats"><span><strong>' + recipe.time + '</strong> min</span><span><strong>' + recipe.servings + '</strong> serving' + (recipe.servings === 1 ? '' : 's') + '</span><span><strong>' + recipe.protein + 'g</strong> protein</span><span><strong>' + recipe.calories + '</strong> Cal</span></div>' +
      '<div class="recipe-card-actions"><button type="button" class="recipe-open" data-action="open-recipe" data-recipe-id="' + escapeHtml(recipe.id) + '">View recipe <span>→</span></button>' +
      '<button type="button" class="favorite-button ' + (favorite ? 'saved' : '') + '" data-action="toggle-meal-favorite" data-recipe-id="' + escapeHtml(recipe.id) + '" aria-label="' +
      (favorite ? 'Remove ' : 'Save ') + escapeHtml(recipe.title) + '" aria-pressed="' + favorite + '">' + (favorite ? '♥' : '♡') + '</button></div></div></article>';
  }

  function mealsView() {
    const recipes = visibleRecipes();
    const filters = mealFilterButton("all", "All") + mealFilterButton("breakfast", "Breakfast") +
      mealFilterButton("meal", "Lunch + dinner") + mealFilterButton("snack", "Snacks") +
      mealFilterButton("vegetarian", "Vegetarian") + mealFilterButton("favorites", "Favourites");
    let recipeHtml = recipes.map(recipeCard).join("");
    if (!recipes.length) {
      recipeHtml = '<div class="meal-empty"><span>♡</span><h2>No favourites yet.</h2><p>Tap the heart on any recipe to keep it handy.</p>' +
        '<button type="button" class="primary compact" data-action="meal-filter" data-filter="all">Browse all recipes</button></div>';
    }

    return sectionHead("HEALTHY MEALS", "Simple food that helps you get stronger.", "Count your calories, log meals, and find easy high-protein recipes—all offline.") + calorieCounterView() +
      '<section class="protein-promise"><div class="protein-stamp"><strong>25g+</strong><span>PROTEIN</span></div><div><h2>Protein-first, not protein-only.</h2><p>Every recipe has at least 25 g estimated protein per serving and takes 30 minutes or less. Add plenty of vegetables or fruit and choose whole grains when you can.</p></div></section>' +
      '<div class="meal-filter" role="group" aria-label="Filter recipes">' + filters + '</div><div class="recipe-count"><strong>' + recipes.length + '</strong> recipe' + (recipes.length === 1 ? '' : 's') + '<span>Nutrition is approximate per serving</span></div>' +
      '<div class="recipe-grid">' + recipeHtml + '</div><section class="meal-safety"><span class="safety-mark">!</span><div><h2>Useful estimates—not a prescription</h2><p>Calories and protein vary by brand and portion. Check ingredient labels for allergies. If you have a medical condition or prescribed diet, ask your clinician or dietitian what is right for you.</p></div></section>';
  }

  function openRecipe(id) {
    const recipe = recipeById(id);
    if (!recipe) return;
    const favorite = isMealFavorite(recipe.id);
    const category = mealLibrary.categories[recipe.category] || "Recipe";
    const ingredients = recipe.ingredients.map(function (ingredient, index) {
      const inputId = "ingredient-" + recipe.id + "-" + index;
      return '<li><input id="' + inputId + '" type="checkbox"><label for="' + inputId + '"><span></span>' + escapeHtml(ingredient) + '</label></li>';
    }).join("");
    const steps = recipe.steps.map(function (step, index) {
      return '<li><span>' + (index + 1) + '</span><p>' + escapeHtml(step) + '</p></li>';
    }).join("");
    const tags = recipe.tags.map(function (tag) { return '<span>' + escapeHtml(tag) + '</span>'; }).join("");
    const safety = recipe.safety || "Keep cold ingredients at 4°C (40°F) or colder and refrigerate perishable food within 2 hours.";
    const allergy = recipe.allergyNote ? '<div class="recipe-callout allergy"><strong>ALLERGY NOTE</strong><p>' + escapeHtml(recipe.allergyNote) + '</p></div>' : '';

    recipeEl.innerHTML = '<header class="recipe-head"><button type="button" class="recipe-close" data-action="close-recipe" aria-label="Close recipe">×</button><div><p class="kicker">' +
      escapeHtml(category) + '</p><h2>' + escapeHtml(recipe.title) + '</h2></div><button type="button" class="recipe-head-favorite ' + (favorite ? 'saved' : '') + '" data-action="toggle-meal-favorite" data-recipe-id="' +
      escapeHtml(recipe.id) + '" aria-label="' + (favorite ? 'Remove from favourites' : 'Add to favourites') + '" aria-pressed="' + favorite + '">' + (favorite ? '♥' : '♡') + '</button></header>' +
      '<div class="recipe-scroll"><section class="recipe-hero ' + recipe.category + '"><div class="recipe-hero-labels">' + tags + '</div><p>' + escapeHtml(recipe.blurb) + '</p><div class="recipe-hero-stats"><div><strong>' +
      recipe.protein + 'g</strong><span>estimated protein</span></div><div><strong>' + recipe.calories + '</strong><span>estimated Cal</span></div><div><strong>' + recipe.time + '</strong><span>minutes</span></div><div><strong>' + recipe.servings + '</strong><span>serving' + (recipe.servings === 1 ? '' : 's') + '</span></div></div></section>' +
      '<p class="protein-note">Calories and protein are estimates per serving and vary by ingredient brand and portion.</p><section class="recipe-section ingredients"><div class="recipe-section-head"><p class="kicker">WHAT YOU NEED</p><h2>Ingredients</h2><span>Tap to check off</span></div><ul>' + ingredients + '</ul></section>' +
      '<section class="recipe-section method"><div class="recipe-section-head"><p class="kicker">STEP BY STEP</p><h2>Make it</h2></div><ol>' + steps + '</ol></section>' +
      '<div class="recipe-callout budget"><strong>BUDGET SWAP</strong><p>' + escapeHtml(recipe.budgetTip) + '</p></div><div class="recipe-callout family"><strong>FAMILY TIP</strong><p>' + escapeHtml(recipe.familyTip) + '</p></div>' + allergy +
      '<div class="recipe-callout food-safe"><strong>COOK + STORE SAFELY</strong><p>' + escapeHtml(safety) + ' Use a digital food thermometer when a cooking temperature is listed.</p></div>' +
      '<div class="recipe-final-actions"><button type="button" class="primary log-recipe-button" data-action="log-recipe-calories" data-recipe-id="' + escapeHtml(recipe.id) + '">Add 1 serving <span>' + recipe.calories + ' Cal</span></button>' +
      '<button type="button" class="recipe-done" data-action="close-recipe">Done</button></div></div>';
    recipeEl.classList.remove("hidden");
    document.body.classList.add("recipe-open");
    recipeEl.scrollTop = 0;
    const closeButton = recipeEl.querySelector(".recipe-close");
    if (closeButton) closeButton.focus();
  }

  function closeRecipe() {
    recipeEl.classList.add("hidden");
    recipeEl.innerHTML = "";
    document.body.classList.remove("recipe-open");
  }

  function toggleMealFavorite(id) {
    const recipe = recipeById(id);
    if (!recipe) return;
    const existingIndex = state.mealFavorites.indexOf(id);
    const adding = existingIndex === -1;
    if (adding) state.mealFavorites.push(id);
    else state.mealFavorites.splice(existingIndex, 1);
    save();
    if (!recipeEl.classList.contains("hidden")) openRecipe(id);
    else render();
    toast(adding ? "Recipe saved to favourites." : "Recipe removed from favourites.");
  }

  function addCalorieEntry(label, calories, meal, recipeId, foodCode) {
    const roundedCalories = Math.round(Number(calories));
    const cleanLabel = String(label || "").trim().slice(0, 60);
    if (!cleanLabel || !Number.isFinite(roundedCalories) || roundedCalories < 1 || roundedCalories > 5000) return false;
    state.calorieEntries.unshift({
      id: String(Date.now()) + "-" + String(state.calorieEntries.length + 1),
      date: state.calorieDate,
      label: cleanLabel,
      calories: roundedCalories,
      meal: calorieMealLabels[meal] ? meal : "snack",
      recipeId: recipeId || "",
      foodCode: Number(foodCode) || 0
    });
    save();
    return true;
  }

  function addManualCalories() {
    const labelInput = document.getElementById("calorie-label");
    const amountInput = document.getElementById("calorie-amount");
    const mealInput = document.getElementById("calorie-meal");
    if (!labelInput || !amountInput || !addCalorieEntry(labelInput.value, amountInput.value, mealInput ? mealInput.value : "snack", "")) {
      toast("Enter a food name and a calorie amount from 1 to 5,000.");
      return;
    }
    render();
    toast("Calories added to " + calorieDateHeading().toLowerCase() + ".");
  }

  function logRecipeCalories(id) {
    const recipe = recipeById(id);
    if (!recipe) return;
    const meal = recipe.category === "breakfast" ? "breakfast" : recipe.category === "snack" ? "snack" : "dinner";
    if (!addCalorieEntry(recipe.title, recipe.calories, meal, recipe.id)) return;
    closeRecipe();
    render();
    toast(recipe.calories + " Cal added for one serving.");
  }

  function removeCalorieEntry(id) {
    const index = state.calorieEntries.findIndex(function (entry) { return entry.id === id; });
    if (index === -1) return;
    state.calorieEntries.splice(index, 1);
    save();
    render();
    toast("Calorie entry removed.");
  }

  function shiftCalorieDate(amount) {
    const next = dateFromKey(state.calorieDate);
    next.setDate(next.getDate() + amount);
    const nextKey = localDateKey(next);
    if (nextKey > localDateKey()) return;
    state.calorieDate = nextKey;
    render();
  }

  function foodGroupName(code) {
    return foodLibrary.groups[String(code)] || foodLibrary.groups[code] || "Other foods";
  }

  function foodCalories(food, servingIndex, quantity) {
    const serving = food && food[5] ? food[5][servingIndex] : null;
    if (!serving) return 0;
    return Math.max(0, Math.round(food[3] * Number(serving[1]) / 100 * Number(quantity)));
  }

  function filteredFoods() {
    const query = state.foodSearch.trim().toLowerCase();
    const terms = query ? query.split(/\s+/).filter(Boolean) : [];
    const group = state.foodGroup;
    const matches = foodLibrary.foods.filter(function (food) {
      if (group !== "all" && String(food[2]) !== group) return false;
      if (!terms.length) return true;
      const searchText = (food[1] + " " + (food[4] || "")).toLowerCase();
      return terms.every(function (term) { return searchText.indexOf(term) !== -1; });
    });
    if (query) {
      matches.sort(function (first, second) {
        const firstName = first[1].toLowerCase();
        const secondName = second[1].toLowerCase();
        const firstRank = firstName === query ? 0 : firstName.indexOf(query) === 0 ? 1 : 2;
        const secondRank = secondName === query ? 0 : secondName.indexOf(query) === 0 ? 1 : 2;
        return firstRank - secondRank || firstName.localeCompare(secondName);
      });
    }
    return matches;
  }

  function foodResultMarkup(food) {
    const serving = food[5][0];
    const calories = foodCalories(food, 0, 1);
    const groupName = foodGroupName(food[2]);
    return '<button type="button" class="food-result" data-action="open-food-detail" data-food-code="' + food[0] + '"><span class="food-result-mark">' + escapeHtml(groupName.slice(0, 1)) + '</span><div><h3>' +
      escapeHtml(food[1]) + '</h3><p>' + escapeHtml(groupName) + '</p></div><span class="food-result-calories"><strong>' + calories + '</strong><small>Cal</small><em>' + escapeHtml(serving[0]) + '</em></span></button>';
  }

  function renderFoodIndexResults() {
    const resultsEl = foodIndexEl.querySelector(".food-results");
    const countEl = foodIndexEl.querySelector(".food-result-count");
    if (!resultsEl || !countEl) return;
    const matches = filteredFoods();
    const visible = matches.slice(0, 80);
    countEl.innerHTML = '<strong>' + matches.length.toLocaleString("en-CA") + '</strong> result' + (matches.length === 1 ? '' : 's') +
      (matches.length > visible.length ? '<span>Showing first ' + visible.length + '—search to narrow</span>' : '');
    resultsEl.innerHTML = visible.length ? visible.map(foodResultMarkup).join("") : '<div class="food-no-results"><strong>No matching food found.</strong><p>Try fewer words, choose All categories, or use custom quick add.</p><button type="button" data-action="food-index-quick-add">Use quick add</button></div>';
  }

  function openFoodIndex() {
    closeRecipe();
    state.selectedFoodCode = null;
    const groupOptions = Object.keys(foodLibrary.groups).sort(function (a, b) { return Number(a) - Number(b); }).map(function (code) {
      return '<option value="' + code + '"' + (state.foodGroup === String(code) ? ' selected' : '') + '>' + escapeHtml(foodGroupName(code)) + '</option>';
    }).join("");
    foodIndexEl.innerHTML = '<header class="food-index-head"><button type="button" class="food-index-close" data-action="close-food-index" aria-label="Close food index">×</button><div><p class="kicker">CALORIE LOOKUP</p><h2>Food index</h2></div></header>' +
      '<div class="food-index-scroll"><section class="food-search-panel"><label for="food-search">Search ' + foodLibrary.foods.length.toLocaleString("en-CA") + ' foods</label><div class="food-search-box"><span>⌕</span><input id="food-search" type="search" autocomplete="off" placeholder="Try apple, chicken, rice…" value="' + escapeHtml(state.foodSearch) + '"></div>' +
      '<label for="food-group">Category</label><select id="food-group"><option value="all">All categories</option>' + groupOptions + '</select></section><div class="food-result-count" aria-live="polite"></div><div class="food-results"></div>' +
      '<button type="button" class="food-custom-button" data-action="food-index-quick-add"><span>＋</span><div><strong>Food or brand not listed?</strong><small>Add its label calories manually</small></div></button>' +
      '<section class="food-data-source"><strong>DATA SOURCE</strong><p>' + escapeHtml(foodLibrary.source) + '. ' + escapeHtml(foodLibrary.note) + '</p></section></div>';
    foodIndexEl.classList.remove("hidden");
    document.body.classList.add("food-index-open");
    renderFoodIndexResults();
    const searchInput = document.getElementById("food-search");
    if (searchInput) searchInput.focus();
  }

  function openFoodDetail(code) {
    const food = foodIndexByCode.get(Number(code));
    if (!food) return;
    state.selectedFoodCode = food[0];
    const servingOptions = food[5].map(function (serving, index) {
      return '<option value="' + index + '">' + escapeHtml(serving[0]) + ' • ' + serving[1] + ' g</option>';
    }).join("");
    const hour = new Date().getHours();
    const suggestedMeal = hour < 10 ? "breakfast" : hour < 15 ? "lunch" : hour < 20 ? "dinner" : "snack";
    const mealOptions = Object.keys(calorieMealLabels).map(function (key) {
      return '<option value="' + key + '"' + (key === suggestedMeal ? ' selected' : '') + '>' + calorieMealLabels[key] + '</option>';
    }).join("");
    const firstCalories = foodCalories(food, 0, 1);
    foodIndexEl.innerHTML = '<header class="food-index-head detail"><button type="button" class="food-index-back" data-action="back-to-food-index" aria-label="Back to food search">←</button><div><p class="kicker">' + escapeHtml(foodGroupName(food[2])) + '</p><h2>Food details</h2></div><button type="button" class="food-index-close" data-action="close-food-index" aria-label="Close food index">×</button></header>' +
      '<div class="food-index-scroll"><section class="food-detail"><p class="food-detail-group">' + escapeHtml(foodGroupName(food[2])) + '</p><h1>' + escapeHtml(food[1]) + '</h1><div class="food-detail-total"><strong id="food-calorie-total">' + firstCalories + '</strong><span>CALORIES</span><small id="food-calorie-description">1 × ' + escapeHtml(food[5][0][0]) + '</small></div>' +
      '<div class="food-per-100"><strong>' + food[3] + ' Cal</strong><span>per 100 g</span></div></section><section class="food-portion-card"><label for="food-serving">Serving size</label><select id="food-serving">' + servingOptions + '</select>' +
      '<label for="food-quantity">Number of servings</label><div class="food-quantity-control"><button type="button" data-action="adjust-food-quantity" data-shift="-0.25" aria-label="Decrease servings">−</button><input id="food-quantity" type="number" min="0.25" max="20" step="0.25" inputmode="decimal" value="1"><button type="button" data-action="adjust-food-quantity" data-shift="0.25" aria-label="Increase servings">＋</button></div>' +
      '<label for="food-meal">Add under</label><select id="food-meal">' + mealOptions + '</select><button type="button" id="add-index-food" class="primary food-add-button" data-action="log-index-food" data-calories="' + firstCalories + '">Add ' + firstCalories + ' Cal to food log</button></section>' +
      '<section class="food-data-source detail-source"><strong>ABOUT THIS VALUE</strong><p>Calculated from the average energy per 100 g in the ' + escapeHtml(foodLibrary.source) + '. For packaged foods, use the product label when it differs.</p></section></div>';
    foodIndexEl.scrollTop = 0;
    const servingSelect = document.getElementById("food-serving");
    if (servingSelect) servingSelect.focus();
  }

  function updateFoodCalculation() {
    const food = foodIndexByCode.get(Number(state.selectedFoodCode));
    const servingInput = document.getElementById("food-serving");
    const quantityInput = document.getElementById("food-quantity");
    const totalEl = document.getElementById("food-calorie-total");
    const descriptionEl = document.getElementById("food-calorie-description");
    const addButton = document.getElementById("add-index-food");
    if (!food || !servingInput || !quantityInput || !totalEl || !descriptionEl || !addButton) return;
    const servingIndex = Number(servingInput.value) || 0;
    const quantity = Number(quantityInput.value);
    const valid = Number.isFinite(quantity) && quantity >= 0.25 && quantity <= 20;
    const calories = valid ? foodCalories(food, servingIndex, quantity) : 0;
    totalEl.textContent = String(calories);
    descriptionEl.textContent = valid ? quantity + " × " + food[5][servingIndex][0] : "Enter 0.25 to 20 servings";
    addButton.dataset.calories = String(calories);
    addButton.disabled = !valid || calories < 1;
    addButton.textContent = valid ? "Add " + calories + " Cal to food log" : "Enter a valid serving amount";
  }

  function adjustFoodQuantity(amount) {
    const input = document.getElementById("food-quantity");
    if (!input) return;
    const current = Number(input.value) || 1;
    input.value = String(Math.max(0.25, Math.min(20, Math.round((current + amount) * 4) / 4)));
    updateFoodCalculation();
  }

  function logIndexFood() {
    const food = foodIndexByCode.get(Number(state.selectedFoodCode));
    const addButton = document.getElementById("add-index-food");
    const mealInput = document.getElementById("food-meal");
    const calories = Number(addButton && addButton.dataset.calories);
    if (!food || !addButton || addButton.disabled || !calories) return;
    if (!addCalorieEntry(food[1], calories, mealInput ? mealInput.value : "snack", "", food[0])) return;
    closeFoodIndex();
    render();
    toast(calories + " Cal added from the food index.");
  }

  function closeFoodIndex() {
    foodIndexEl.classList.add("hidden");
    foodIndexEl.innerHTML = "";
    document.body.classList.remove("food-index-open");
    state.selectedFoodCode = null;
  }

  function showFoodQuickAdd() {
    closeFoodIndex();
    const labelInput = document.getElementById("calorie-label");
    if (labelInput) labelInput.focus();
  }

  function recentDays() {
    return Array.from({ length: 7 }, function (_, index) {
      const date = new Date();
      date.setDate(date.getDate() - (6 - index));
      const key = localDateKey(date);
      const minutes = state.history.filter(function (item) { return item.date === key; })
        .reduce(function (sum, item) { return sum + item.minutes; }, 0);
      return { key: key, label: date.toLocaleDateString("en-CA", { weekday: "short" }).slice(0, 1), minutes: minutes };
    });
  }

  function progressView() {
    const total = state.history.reduce(function (sum, item) { return sum + item.minutes; }, 0);
    const days = recentDays();
    const weekTotal = days.reduce(function (sum, item) { return sum + item.minutes; }, 0);
    const bars = days.map(function (day) {
      const height = day.minutes ? Math.max(14, Math.min(100, day.minutes / 40 * 100)) : 4;
      return '<div class="bar-column"><small>' + (day.minutes || '') + '</small><div class="bar-track"><span style="height:' + height + '%"></span></div><small>' + day.label + '</small></div>';
    }).join("");
    let historyHtml = '<div class="empty"><span class="empty-mark">01</span><h3>Your first workout starts the story.</h3><p>Complete a guided session and it will appear here.</p><button class="primary compact" type="button" data-go="today">Go to today\'s workout</button></div>';
    if (state.history.length) {
      historyHtml = '<div class="history">' + state.history.slice(0, 8).map(function (item) {
        return '<article class="history-row"><span class="history-type ' + item.type + '">' + (item.type === "workout" ? "W" : "M") + '</span><div><h3>' +
          escapeHtml(item.title) + '</h3><p>' + formatDate(item.date) + (item.type === "workout" && levelLabels[item.level] ? ' • ' + levelLabels[item.level] : '') + '</p></div><strong>' + item.minutes + ' min</strong></article>';
      }).join("") + '</div>';
    }

    return sectionHead("YOUR PROGRESS", "Proof that you’re showing up.", "No weigh-ins required. This page tracks the habit you are building.") +
      '<div class="stat-grid"><article class="stat-card"><strong>' + state.history.length + '</strong><span>activities completed</span></article>' +
      '<article class="stat-card"><strong>' + total + '</strong><span>active minutes</span></article><article class="stat-card"><strong>' + streakCount() + '</strong><span>day current streak</span></article></div>' +
      '<section class="panel"><div class="panel-head"><div><p class="kicker">LAST 7 DAYS</p><h2>Your active minutes</h2></div><strong>' + weekTotal + ' min</strong></div><div class="bar-chart">' + bars + '</div></section>' +
      '<section class="panel"><div class="panel-head"><div><p class="kicker">RECENT</p><h2>Activity history</h2></div></div>' + historyHtml + '</section>';
  }

  function optionButton(setting, value, label, selected) {
    return '<button type="button" data-setting="' + setting + '" data-value="' + value + '" class="' + (selected ? 'selected' : '') + '"><span class="radio"></span>' + label + '</button>';
  }

  function settingsView() {
    const levels = Object.keys(levelLabels).map(function (key) {
      return '<button type="button" data-setting="level" data-value="' + key + '" class="' + (state.settings.level === key ? 'selected' : '') + '"><span class="radio"></span><span><strong>' + levelLabels[key] + '</strong><small>' + escapeHtml(levelProfiles[key].summary) + '</small></span></button>';
    }).join("");
    const goals = Object.keys(goalLabels).map(function (key) {
      return optionButton("goal", key, goalLabels[key], state.settings.goal === key);
    }).join("");
    const durations = [10, 15, 20, 30].map(function (value) {
      return '<button type="button" data-setting="duration" data-value="' + value + '" class="' + (state.settings.duration === value ? 'selected' : '') + '"><strong>' + value + '</strong><small>min</small></button>';
    }).join("");
    const equipment = Object.keys(equipmentLabels).map(function (key) {
      return optionButton("equipment", key, equipmentLabels[key], state.settings.equipment === key);
    }).join("");

    return sectionHead("YOUR SETUP", "Make every workout fit you.", "Change anything here and your next workout adjusts immediately.") +
      '<section class="settings-card"><label class="field-label" for="name">What should the app call you?</label><input class="name-input" id="name" maxlength="20" value="' + escapeHtml(state.settings.name) + '">' +
      '<fieldset><legend>Training level</legend><div class="option-grid three level-settings">' + levels + '</div><p class="setting-help">Changing levels updates the exercise variations, work time, recovery, workout names, and weekly plan.</p></fieldset>' +
      '<fieldset><legend>Your main goal</legend><div class="option-grid two">' + goals + '</div></fieldset>' +
      '<fieldset><legend>Time per workout</legend><div class="option-grid four">' + durations + '</div></fieldset>' +
      '<fieldset><legend>Equipment</legend><div class="option-grid two">' + equipment + '</div></fieldset>' +
      '<fieldset class="calorie-goal-field"><legend>Daily calorie goal (optional)</legend><div class="calorie-goal-input"><input id="calorie-goal" type="number" min="0" max="10000" step="50" inputmode="numeric" value="' + state.settings.calorieGoal + '" aria-describedby="calorie-goal-help"><span>Cal</span></div>' +
      '<p id="calorie-goal-help" class="setting-help">Use 0 to count without a goal. Calorie needs vary from person to person; this number is only your tracking setting.</p></fieldset>' +
      '<div class="toggle-row"><div><strong>Low-impact mode</strong><p>Keeps workouts joint-friendlier with no jumping.</p></div><button type="button" role="switch" aria-checked="' + state.settings.lowImpact + '" class="switch ' + (state.settings.lowImpact ? 'on' : '') + '" data-action="toggle-impact"><span></span></button></div></section>' +
      '<section class="safety"><span class="safety-mark">!</span><div><h2>Train safely</h2><p>Start slowly. Stop if you feel pain, dizziness, chest discomfort, or unusual shortness of breath. Speak with a healthcare professional if you are unsure what is safe for you.</p></div></section>' +
      '<button type="button" class="reset ' + (state.resetArmed ? 'armed' : '') + '" data-action="reset">' + (state.resetArmed ? 'Tap again to confirm' : 'Clear workout history') + '</button>' +
      '<p class="app-info">Everyday Strong 1.9.2 • Weight-loss workouts, a 30-day challenge, three workout levels, firefighter conditioning, meals, and calorie tracking stay offline.</p>';
  }

  function setTab(tab) {
    closeRecipe();
    closeFoodIndex();
    state.tab = tab;
    render();
  }

  function toast(message) {
    clearTimeout(state.toastTimer);
    toastEl.textContent = message;
    toastEl.classList.remove("hidden");
    state.toastTimer = setTimeout(function () { toastEl.classList.add("hidden"); }, 2500);
  }

  function vibrate(pattern) {
    try { if (navigator.vibrate) navigator.vibrate(pattern); } catch (error) { /* no-op */ }
  }

  function startSession() {
    state.session = { workout: buildWorkout(), index: 0, seconds: 0, running: true, finished: false };
    state.session.seconds = state.session.workout.timeline[0].seconds;
    sessionEl.classList.remove("hidden");
    renderSession();
    startTimer();
  }

  function startTimer() {
    clearInterval(state.timer);
    state.timer = setInterval(function () {
      if (!state.session || !state.session.running || state.session.finished) return;
      if (state.session.seconds > 1) state.session.seconds -= 1;
      else if (state.session.index < state.session.workout.timeline.length - 1) {
        state.session.index += 1;
        state.session.seconds = state.session.workout.timeline[state.session.index].seconds;
        vibrate(20);
      } else {
        state.session.seconds = 0;
        state.session.running = false;
        state.session.finished = true;
        vibrate([40, 80, 40]);
      }
      renderSession();
    }, 1000);
  }

  function renderSession() {
    if (!state.session) return;
    const current = state.session.workout.timeline[state.session.index];
    if (state.session.finished) {
      sessionEl.innerHTML = '<header class="session-head"><button type="button" class="session-close" data-action="close-session" aria-label="Close workout">×</button><div><p>' +
        escapeHtml(state.session.workout.title) + '</p><span>Workout complete</span></div><strong>' + state.session.workout.minutes + ' MIN</strong></header>' +
        '<div class="finished"><span class="finish-mark">✓</span><p class="kicker">SESSION COMPLETE</p><h2>You did the work.</h2><p>' + state.session.workout.minutes +
        ' active minutes are ready to add to your progress.</p><button type="button" class="primary" data-action="save-workout">Save workout</button></div>';
      return;
    }

    const stepPercent = ((current.seconds - state.session.seconds) / current.seconds) * 100;
    const totalPercent = ((state.session.index + stepPercent / 100) / state.session.workout.timeline.length) * 100;
    const phase = current.kind === "warmup" ? "WARM-UP" : current.kind === "work" ? "ROUND " + current.round + " OF " + state.session.workout.rounds : current.kind === "rest" ? "RECOVERY" : "COOL-DOWN";
    const guideButton = current.kind === "rest" ? "" : '<button type="button" class="session-guide-button" data-action="show-guide" data-move-id="' + escapeHtml(current.baseId || current.id) + '"><span>?</span> See step-by-step guide</button>';
    sessionEl.innerHTML = '<header class="session-head"><button type="button" class="session-close" data-action="close-session" aria-label="Close workout">×</button><div><p>' +
      escapeHtml(state.session.workout.title) + '</p><span>Step ' + (state.session.index + 1) + ' of ' + state.session.workout.timeline.length + '</span></div><strong>' + state.session.workout.minutes + ' MIN</strong></header>' +
      '<div class="session-progress"><span style="width:' + totalPercent + '%"></span></div><div class="session-body ' + (current.kind === "rest" ? 'resting' : '') + '"><p class="session-phase">' + phase + '</p><h2>' +
      escapeHtml(current.name) + '</h2><p class="session-instruction">' + escapeHtml(current.instruction) + '</p>' + guideButton + '<div class="timer-wrap"><div class="timer-ring" style="--step:' + stepPercent + '%"><div><strong>' +
      formatTimer(state.session.seconds) + '</strong><span>' + (state.session.running ? 'KEEP MOVING' : 'PAUSED') + '</span></div></div></div><div class="form-tip"><span>TIP</span><p>' + escapeHtml(current.cue) +
      '</p></div><div class="session-controls"><button type="button" class="step-button" data-action="previous"' + (state.session.index === 0 ? ' disabled' : '') + '>←</button><button type="button" class="pause-button" data-action="pause">' +
      (state.session.running ? 'Pause' : 'Resume') + '</button><button type="button" class="step-button" data-action="next">→</button></div></div>';
  }

  function stepSession(direction) {
    if (!state.session) return;
    const next = state.session.index + direction;
    if (next < 0) return;
    if (next >= state.session.workout.timeline.length) {
      state.session.running = false;
      state.session.finished = true;
    } else {
      state.session.index = next;
      state.session.seconds = state.session.workout.timeline[next].seconds;
    }
    vibrate(15);
    renderSession();
  }

  function closeSession() {
    clearInterval(state.timer);
    closeGuide();
    state.session = null;
    sessionEl.classList.add("hidden");
    sessionEl.innerHTML = "";
  }

  function saveWorkout() {
    if (!state.session) return;
    state.history.unshift({
      id: String(Date.now()),
      date: localDateKey(),
      title: state.session.workout.title,
      minutes: state.session.workout.minutes,
      type: "workout",
      level: state.session.workout.level
    });
    if (state.activeChallengeDay && state.challengeDone.indexOf(state.activeChallengeDay) === -1) {
      state.challengeDone.push(state.activeChallengeDay);
    }
    state.activeChallengeDay = null;
    save();
    closeSession();
    render();
    toast("Workout saved. Nice work, " + (state.settings.name || "Chris") + ".");
  }

  function logWalk(title) {
    state.history.unshift({ id: String(Date.now()), date: localDateKey(), title: title, minutes: 15, type: "walk" });
    save();
    render();
    toast("Activity added to your week.");
  }

  function startChallenge(day) {
    const item = weightLossChallenge.find(function (candidate) { return candidate.day === day; });
    if (!item || item.rest) return;
    state.settings.focus = "weightloss";
    state.settings.goal = "weight";
    state.settings.duration = item.minutes;
    state.settings.lowImpact = item.lowImpact;
    state.activeChallengeDay = item.day;
    state.seed += item.day;
    save();
    setTab("today");
    toast("Day " + item.day + " workout is ready.");
  }

  function toggleChallengeRest(day) {
    const item = weightLossChallenge.find(function (candidate) { return candidate.day === day; });
    if (!item || !item.rest) return;
    const index = state.challengeDone.indexOf(day);
    if (index === -1) state.challengeDone.push(day);
    else state.challengeDone.splice(index, 1);
    save();
    render();
  }

  document.addEventListener("click", function (event) {
    const button = event.target.closest("button");
    if (!button) return;

    const tab = button.getAttribute("data-tab") || button.getAttribute("data-go");
    if (tab) { setTab(tab); return; }

    const setting = button.getAttribute("data-setting");
    if (setting) {
      let value = button.getAttribute("data-value");
      if (setting === "duration") value = Number(value);
      state.settings[setting] = value;
      state.seed += 1;
      save();
      render();
      return;
    }

    const action = button.getAttribute("data-action");
    if (!action) return;
    if (action === "show-guide") openGuide(button.getAttribute("data-move-id"));
    else if (action === "close-guide") closeGuide();
    else if (action === "open-recipe") openRecipe(button.getAttribute("data-recipe-id"));
    else if (action === "close-recipe") closeRecipe();
    else if (action === "toggle-meal-favorite") toggleMealFavorite(button.getAttribute("data-recipe-id"));
    else if (action === "log-recipe-calories") logRecipeCalories(button.getAttribute("data-recipe-id"));
    else if (action === "add-calories") addManualCalories();
    else if (action === "remove-calories") removeCalorieEntry(button.getAttribute("data-calorie-id"));
    else if (action === "shift-calorie-date") shiftCalorieDate(Number(button.getAttribute("data-shift")) || 0);
    else if (action === "open-food-index") openFoodIndex();
    else if (action === "close-food-index") closeFoodIndex();
    else if (action === "open-food-detail") openFoodDetail(button.getAttribute("data-food-code"));
    else if (action === "back-to-food-index") openFoodIndex();
    else if (action === "food-index-quick-add") showFoodQuickAdd();
    else if (action === "adjust-food-quantity") adjustFoodQuantity(Number(button.getAttribute("data-shift")) || 0);
    else if (action === "log-index-food") logIndexFood();
    else if (action === "calorie-settings") {
      setTab("settings");
      const goalInput = document.getElementById("calorie-goal");
      if (goalInput) goalInput.focus();
    }
    else if (action === "meal-filter") {
      state.mealFilter = button.getAttribute("data-filter") || "all";
      render();
    }
    else if (action === "toggle-demo") toggleDemo(button);
    else if (action === "fresh") {
      state.seed += 17;
      save();
      render();
      toast("Fresh " + focusLabels[state.settings.focus].toLowerCase() + " workout ready.");
    } else if (action === "start") startSession();
    else if (action === "open-workout") {
      const plannedFocus = button.getAttribute("data-focus");
      if (focusLabels[plannedFocus]) {
        state.settings.focus = plannedFocus;
        state.seed += 1;
        save();
      }
      setTab("today");
    }
    else if (action === "log-walk") logWalk(button.getAttribute("data-title") || "Easy walk");
    else if (action === "start-challenge") startChallenge(Number(button.getAttribute("data-day")));
    else if (action === "challenge-rest") toggleChallengeRest(Number(button.getAttribute("data-day")));
    else if (action === "toggle-impact") {
      state.settings.lowImpact = !state.settings.lowImpact;
      state.seed += 1;
      save();
      render();
    } else if (action === "close-session") closeSession();
    else if (action === "pause" && state.session) {
      state.session.running = !state.session.running;
      renderSession();
    } else if (action === "previous") stepSession(-1);
    else if (action === "next") stepSession(1);
    else if (action === "save-workout") saveWorkout();
    else if (action === "reset") {
      if (!state.resetArmed) {
        state.resetArmed = true;
        render();
      } else {
        state.history = [];
        state.resetArmed = false;
        save();
        render();
        toast("Workout history cleared.");
      }
    }
  });

  document.addEventListener("input", function (event) {
    if (event.target && event.target.id === "name") {
      state.settings.name = event.target.value.slice(0, 20);
      save();
    } else if (event.target && event.target.id === "calorie-goal") {
      state.settings.calorieGoal = Math.max(0, Math.min(10000, Number(event.target.value) || 0));
      save();
    } else if (event.target && event.target.id === "food-search") {
      state.foodSearch = event.target.value.slice(0, 80);
      renderFoodIndexResults();
    } else if (event.target && event.target.id === "food-quantity") {
      updateFoodCalculation();
    }
  });

  document.addEventListener("change", function (event) {
    if (event.target && event.target.id === "food-group") {
      state.foodGroup = event.target.value || "all";
      renderFoodIndexResults();
    } else if (event.target && event.target.id === "food-serving") {
      updateFoodCalculation();
    }
  });

  document.addEventListener("visibilitychange", function () {
    if (document.hidden && state.session && state.session.running) {
      state.session.running = false;
      renderSession();
    }
  });

  load();
  render();
}());
