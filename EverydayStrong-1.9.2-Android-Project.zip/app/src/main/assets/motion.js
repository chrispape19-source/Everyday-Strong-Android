(function (global) {
  "use strict";

  const joints = ["head", "shoulder", "hip", "elbowA", "handA", "elbowB", "handB", "kneeA", "ankleA", "kneeB", "ankleB"];

  function copyPoint(point) {
    return [point[0], point[1]];
  }

  function pose(base, changes) {
    const result = {};
    joints.forEach(function (joint) { result[joint] = copyPoint(base[joint]); });
    Object.keys(changes || {}).forEach(function (joint) { result[joint] = copyPoint(changes[joint]); });
    return result;
  }

  const stand = {
    head: [120, 26], shoulder: [120, 52], hip: [120, 96],
    elbowA: [99, 72], handA: [104, 99], elbowB: [141, 72], handB: [136, 99],
    kneeA: [105, 127], ankleA: [101, 160], kneeB: [135, 127], ankleB: [139, 160]
  };

  const narrowStand = pose(stand, {
    kneeA: [113, 127], ankleA: [111, 160], kneeB: [127, 127], ankleB: [129, 160]
  });

  const seated = {
    head: [120, 39], shoulder: [120, 65], hip: [120, 108],
    elbowA: [99, 82], handA: [104, 106], elbowB: [141, 82], handB: [136, 106],
    kneeA: [95, 112], ankleA: [95, 159], kneeB: [145, 112], ankleB: [145, 159]
  };

  const supine = {
    head: [194, 137], shoulder: [168, 137], hip: [122, 140],
    elbowA: [164, 112], handA: [164, 82], elbowB: [153, 112], handB: [153, 82],
    kneeA: [91, 108], ankleA: [60, 140], kneeB: [101, 110], ankleB: [72, 140]
  };

  const quadruped = {
    head: [181, 91], shoulder: [156, 98], hip: [111, 111],
    elbowA: [160, 122], handA: [160, 157], elbowB: [147, 123], handB: [145, 157],
    kneeA: [111, 143], ankleA: [94, 159], kneeB: [96, 143], ankleB: [79, 159]
  };

  const sideLying = {
    head: [191, 126], shoulder: [165, 138], hip: [119, 145],
    elbowA: [170, 153], handA: [145, 156], elbowB: [157, 151], handB: [137, 156],
    kneeA: [88, 138], ankleA: [59, 150], kneeB: [91, 148], ankleB: [61, 151]
  };

  const prone = {
    head: [190, 131], shoulder: [161, 139], hip: [116, 146],
    elbowA: [168, 151], handA: [145, 157], elbowB: [153, 151], handB: [134, 157],
    kneeA: [80, 149], ankleA: [44, 154], kneeB: [82, 154], ankleB: [47, 158]
  };

  const templates = {};

  function add(name, label, view, props, frames, duration) {
    templates[name] = { name: name, label: label, view: view, props: props || [], frames: frames, duration: duration || 3.2 };
  }

  add("breath", "Raise the arms while breathing in; lower them while breathing out", "Front view", [], [
    stand,
    pose(stand, { elbowA: [92, 44], handA: [103, 18], elbowB: [148, 44], handB: [137, 18] })
  ], 4.2);

  add("march", "Opposite arm and knee move together", "Front view", [], [
    pose(stand, { elbowA: [102, 67], handA: [111, 47], elbowB: [142, 78], handB: [132, 100], kneeA: [105, 101], ankleA: [106, 128] }),
    pose(stand, { elbowA: [98, 78], handA: [108, 100], elbowB: [138, 67], handB: [129, 47], kneeB: [135, 101], ankleB: [134, 128] })
  ], 2.5);

  add("fastFeet", "Use short, quick steps while staying tall", "Front view", [], [
    pose(narrowStand, { kneeA: [111, 119], ankleA: [108, 150], kneeB: [127, 131], ankleB: [132, 160] }),
    pose(narrowStand, { kneeA: [113, 131], ankleA: [108, 160], kneeB: [129, 119], ankleB: [132, 150] })
  ], 1.5);

  add("heelDig", "Reach one heel forward, return, then change sides", "Front view", [], [
    pose(stand, { kneeA: [103, 126], ankleA: [78, 158], elbowA: [97, 69], handA: [81, 54], elbowB: [142, 75], handB: [151, 96] }),
    pose(stand, { kneeB: [137, 126], ankleB: [162, 158], elbowB: [143, 69], handB: [159, 54], elbowA: [98, 75], handA: [89, 96] })
  ], 2.8);

  add("heelDigPull", "Tap the heel forward as both elbows pull behind you", "Front view", [], [
    pose(stand, { ankleA: [78, 158], elbowA: [83, 62], handA: [105, 70], elbowB: [157, 62], handB: [135, 70] }),
    pose(stand, { ankleB: [162, 158], elbowA: [91, 58], handA: [66, 55], elbowB: [149, 58], handB: [174, 55] })
  ], 2.8);

  add("sideStep", "Step wide, bring the feet together, and change direction", "Front view", [], [
    narrowStand,
    pose(stand, { hip: [105, 96], shoulder: [105, 52], head: [105, 26], kneeA: [83, 128], ankleA: [72, 160], kneeB: [126, 127], ankleB: [130, 160] })
  ], 2.7);

  add("stepJack", "Step one foot out as both arms rise", "Front view", [], [
    narrowStand,
    pose(stand, { elbowA: [88, 51], handA: [70, 21], elbowB: [152, 51], handB: [170, 21], kneeA: [92, 128], ankleA: [76, 160], kneeB: [148, 128], ankleB: [164, 160] })
  ], 3.0);

  add("jumpingJack", "Jump the feet apart as the arms travel overhead", "Front view", [], [
    narrowStand,
    pose(stand, { head: [120, 20], shoulder: [120, 46], hip: [120, 90], elbowA: [88, 45], handA: [70, 14], elbowB: [152, 45], handB: [170, 14], kneeA: [92, 122], ankleA: [73, 155], kneeB: [148, 122], ankleB: [167, 155] })
  ], 2.0);

  add("shoulderRoll", "Lift, roll back, and lower the shoulders smoothly", "Front view", [], [
    stand,
    pose(stand, { shoulder: [120, 46], elbowA: [96, 65], handA: [103, 94], elbowB: [144, 65], handB: [137, 94] }),
    pose(stand, { shoulder: [120, 54], elbowA: [94, 73], handA: [105, 99], elbowB: [146, 73], handB: [135, 99] })
  ], 3.8);

  add("armCircle", "Keep the arms long and trace a controlled circle", "Front view", [], [
    pose(stand, { elbowA: [88, 52], handA: [58, 52], elbowB: [152, 52], handB: [182, 52] }),
    pose(stand, { elbowA: [103, 30], handA: [112, 8], elbowB: [137, 30], handB: [128, 8] }),
    pose(stand, { elbowA: [92, 76], handA: [78, 96], elbowB: [148, 76], handB: [162, 96] })
  ], 4.2);

  add("sideBend", "Reach up and lengthen one side without twisting", "Front view", [], [
    pose(stand, { elbowA: [108, 31], handA: [113, 7], elbowB: [146, 74], handB: [139, 100] }),
    pose(stand, { head: [136, 28], shoulder: [132, 53], hip: [120, 96], elbowA: [137, 29], handA: [150, 9], elbowB: [150, 76], handB: [144, 101] })
  ], 3.7);

  add("hinge", "Push the hips back while the back stays long", "Side view", [], [
    stand,
    pose(stand, { head: [160, 58], shoulder: [145, 72], hip: [112, 100], elbowA: [135, 85], handA: [119, 103], elbowB: [151, 86], handB: [134, 105], kneeA: [104, 130], ankleA: [101, 160], kneeB: [130, 130], ankleB: [139, 160] })
  ], 3.5);

  add("weightedHinge", "Keep the weights close as the hips travel back", "Side view", ["dumbbells"], [
    pose(stand, { handA: [109, 94], handB: [131, 94] }),
    pose(stand, { head: [160, 58], shoulder: [145, 72], hip: [112, 100], elbowA: [133, 84], handA: [125, 111], elbowB: [149, 85], handB: [141, 112], kneeA: [104, 130], ankleA: [101, 160], kneeB: [130, 130], ankleB: [139, 160] })
  ], 3.5);

  add("squat", "Sit the hips down and back, then press the floor away", "Front view", [], [
    stand,
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [95, 82], handA: [111, 95], elbowB: [145, 82], handB: [129, 95], kneeA: [91, 135], ankleA: [99, 160], kneeB: [149, 135], ankleB: [141, 160] })
  ], 3.4);

  add("chairSquat", "Reach the hips toward the chair, touch lightly, then stand", "Side view", ["chair-left"], [
    pose(stand, { hip: [130, 96], shoulder: [130, 52], head: [130, 26], kneeA: [116, 127], ankleA: [112, 160], kneeB: [143, 127], ankleB: [148, 160] }),
    pose(stand, { head: [150, 52], shoulder: [142, 75], hip: [111, 111], elbowA: [132, 84], handA: [115, 96], elbowB: [149, 86], handB: [134, 101], kneeA: [102, 132], ankleA: [112, 160], kneeB: [142, 134], ankleB: [148, 160] })
  ], 3.5);

  add("gobletSquat", "Keep the dumbbell at the chest while sitting down between the feet", "Front view", ["one-dumbbell"], [
    pose(stand, { elbowA: [103, 69], handA: [116, 67], elbowB: [137, 69], handB: [124, 67] }),
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [101, 77], handA: [116, 76], elbowB: [139, 77], handB: [124, 76], kneeA: [91, 135], ankleA: [99, 160], kneeB: [149, 135], ankleB: [141, 160] })
  ], 3.5);

  add("sumoSquat", "Use a wider stance and let the knees follow the toes", "Front view", ["one-dumbbell"], [
    pose(stand, { kneeA: [95, 127], ankleA: [79, 160], kneeB: [145, 127], ankleB: [161, 160], handA: [116, 91], handB: [124, 91] }),
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [107, 82], handA: [116, 109], elbowB: [133, 82], handB: [124, 109], kneeA: [86, 135], ankleA: [79, 160], kneeB: [154, 135], ankleB: [161, 160] })
  ], 3.5);

  add("squatReach", "Sit into the squat, stand, and finish with a tall reach", "Front view", [], [
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [95, 82], handA: [111, 95], elbowB: [145, 82], handB: [129, 95], kneeA: [91, 135], ankleA: [99, 160], kneeB: [149, 135], ankleB: [141, 160] }),
    pose(stand, { elbowA: [103, 30], handA: [112, 8], elbowB: [137, 30], handB: [128, 8] })
  ], 3.0);

  add("lunge", "Step back and lower straight down through both knees", "Side view", [], [
    stand,
    pose(stand, { head: [124, 39], shoulder: [122, 64], hip: [116, 108], elbowA: [103, 80], handA: [108, 105], elbowB: [141, 80], handB: [136, 105], kneeA: [151, 130], ankleA: [166, 160], kneeB: [86, 139], ankleB: [61, 158] })
  ], 3.6);

  add("calfRaise", "Rise through the balls of the feet and lower slowly", "Front view", [], [
    stand,
    pose(stand, { head: [120, 18], shoulder: [120, 44], hip: [120, 88], elbowA: [99, 64], handA: [104, 91], elbowB: [141, 64], handB: [136, 91], kneeA: [105, 119], ankleA: [101, 153], kneeB: [135, 119], ankleB: [139, 153] })
  ], 3.0);

  add("weightedCalfRaise", "Hold the weights steady while rising onto the toes", "Front view", ["dumbbells"], [
    stand,
    pose(stand, { head: [120, 18], shoulder: [120, 44], hip: [120, 88], elbowA: [99, 64], handA: [104, 91], elbowB: [141, 64], handB: [136, 91], kneeA: [105, 119], ankleA: [101, 153], kneeB: [135, 119], ankleB: [139, 153] })
  ], 3.0);

  add("ankleRock", "Rock forward through the ankles while keeping control", "Side view", ["chair-left"], [
    stand,
    pose(stand, { head: [128, 24], shoulder: [128, 50], hip: [126, 95], elbowA: [105, 68], handA: [83, 82], elbowB: [146, 70], handB: [139, 97], kneeA: [112, 126], ankleA: [104, 160], kneeB: [141, 126], ankleB: [138, 160] })
  ], 3.0);

  add("sideLegRaise", "Keep the trunk tall as one leg moves out to the side", "Front view", ["chair-left"], [
    stand,
    pose(stand, { kneeA: [85, 124], ankleA: [58, 143], elbowA: [97, 70], handA: [74, 85] })
  ], 3.2);

  add("crossCrunch", "Bring the opposite elbow and knee toward each other", "Front view", [], [
    pose(stand, { elbowA: [96, 45], handA: [108, 28], elbowB: [144, 45], handB: [132, 28] }),
    pose(stand, { head: [116, 29], shoulder: [113, 55], elbowA: [105, 70], handA: [126, 78], elbowB: [139, 43], handB: [151, 27], kneeB: [128, 100], ankleB: [133, 128] })
  ], 3.0);

  add("wallPush", "Keep a straight body line as the elbows bend toward the wall", "Side view", ["wall"], [
    pose(stand, { head: [164, 49], shoulder: [148, 67], hip: [113, 100], elbowA: [176, 75], handA: [205, 78], elbowB: [172, 84], handB: [205, 87], kneeA: [91, 129], ankleA: [78, 160], kneeB: [119, 130], ankleB: [108, 160] }),
    pose(stand, { head: [184, 55], shoulder: [166, 72], hip: [123, 103], elbowA: [181, 90], handA: [205, 78], elbowB: [183, 99], handB: [205, 87], kneeA: [96, 131], ankleA: [78, 160], kneeB: [125, 132], ankleB: [108, 160] })
  ], 3.2);

  add("counterPlank", "Hold one long line from the head through the heels", "Side view", ["counter"], [
    pose(stand, { head: [181, 67], shoulder: [158, 82], hip: [112, 112], elbowA: [176, 83], handA: [197, 83], elbowB: [173, 89], handB: [197, 88], kneeA: [82, 135], ankleA: [52, 160], kneeB: [93, 139], ankleB: [64, 160] }),
    pose(stand, { head: [180, 65], shoulder: [157, 80], hip: [111, 110], elbowA: [176, 82], handA: [197, 83], elbowB: [173, 88], handB: [197, 88], kneeA: [82, 134], ankleA: [52, 160], kneeB: [93, 138], ankleB: [64, 160] })
  ], 4.0);

  add("counterTap", "Shift slowly and tap the opposite shoulder without twisting", "Side view", ["counter"], [
    pose(stand, { head: [181, 67], shoulder: [158, 82], hip: [112, 112], elbowA: [176, 83], handA: [197, 83], elbowB: [173, 89], handB: [197, 88], kneeA: [82, 135], ankleA: [52, 160], kneeB: [93, 139], ankleB: [64, 160] }),
    pose(stand, { head: [181, 67], shoulder: [158, 82], hip: [112, 112], elbowA: [164, 69], handA: [151, 78], elbowB: [173, 89], handB: [197, 88], kneeA: [82, 135], ankleA: [52, 160], kneeB: [93, 139], ankleB: [64, 160] })
  ], 3.4);

  add("counterClimber", "Keep the upper body steady as one knee drives forward", "Side view", ["counter"], [
    pose(stand, { head: [181, 67], shoulder: [158, 82], hip: [112, 112], elbowA: [176, 83], handA: [197, 83], elbowB: [173, 89], handB: [197, 88], kneeA: [82, 135], ankleA: [52, 160], kneeB: [93, 139], ankleB: [64, 160] }),
    pose(stand, { head: [181, 67], shoulder: [158, 82], hip: [112, 112], elbowA: [176, 83], handA: [197, 83], elbowB: [173, 89], handB: [197, 88], kneeA: [137, 114], ankleA: [113, 136], kneeB: [93, 139], ankleB: [64, 160] })
  ], 2.2);

  add("sideWallPlank", "Press the forearm into the wall and keep the body in one line", "Side view", ["wall"], [
    pose(stand, { head: [154, 35], shoulder: [146, 59], hip: [122, 99], elbowA: [174, 63], handA: [196, 72], elbowB: [138, 79], handB: [128, 101], kneeA: [104, 129], ankleA: [86, 160], kneeB: [129, 129], ankleB: [116, 160] }),
    pose(stand, { head: [156, 33], shoulder: [148, 57], hip: [124, 97], elbowA: [174, 63], handA: [196, 72], elbowB: [140, 77], handB: [130, 99], kneeA: [106, 127], ankleA: [86, 160], kneeB: [131, 127], ankleB: [116, 160] })
  ], 4.0);

  add("row", "Pull the dumbbell toward the hip while the back stays long", "Side view", ["chair-left", "one-dumbbell"], [
    pose(stand, { head: [162, 59], shoulder: [146, 74], hip: [112, 101], elbowA: [150, 92], handA: [145, 118], elbowB: [120, 85], handB: [82, 91], kneeA: [105, 132], ankleA: [101, 160], kneeB: [137, 128], ankleB: [146, 160] }),
    pose(stand, { head: [162, 59], shoulder: [146, 74], hip: [112, 101], elbowA: [126, 86], handA: [119, 103], elbowB: [120, 85], handB: [82, 91], kneeA: [105, 132], ankleA: [101, 160], kneeB: [137, 128], ankleB: [146, 160] })
  ], 3.2);

  add("curl", "Keep the elbows close as the weights travel toward the shoulders", "Front view", ["dumbbells"], [
    stand,
    pose(stand, { elbowA: [100, 74], handA: [108, 52], elbowB: [140, 74], handB: [132, 52] })
  ], 3.0);

  add("overheadPress", "Press overhead without leaning back", "Front view", ["dumbbells", "chair"], [
    pose(seated, { elbowA: [98, 73], handA: [104, 53], elbowB: [142, 73], handB: [136, 53] }),
    pose(seated, { elbowA: [105, 38], handA: [110, 15], elbowB: [135, 38], handB: [130, 15] })
  ], 3.2);

  add("lateralRaise", "Lift the arms out to the sides and stop below shoulder height", "Front view", ["dumbbells"], [
    stand,
    pose(stand, { elbowA: [87, 57], handA: [57, 57], elbowB: [153, 57], handB: [183, 57] })
  ], 3.2);

  add("triceps", "Keep the upper arms still while straightening the elbows", "Side view", ["dumbbells"], [
    pose(stand, { head: [159, 59], shoulder: [144, 73], hip: [112, 100], elbowA: [127, 77], handA: [133, 98], elbowB: [143, 84], handB: [147, 105], kneeA: [104, 130], ankleA: [101, 160], kneeB: [130, 130], ankleB: [139, 160] }),
    pose(stand, { head: [159, 59], shoulder: [144, 73], hip: [112, 100], elbowA: [127, 77], handA: [101, 85], elbowB: [143, 84], handB: [117, 94], kneeA: [104, 130], ankleA: [101, 160], kneeB: [130, 130], ankleB: [139, 160] })
  ], 3.0);

  add("reverseFly", "Open the arms wide by squeezing the shoulder blades", "Side view", ["dumbbells"], [
    pose(stand, { head: [160, 58], shoulder: [145, 72], hip: [112, 100], elbowA: [139, 91], handA: [133, 112], elbowB: [151, 91], handB: [145, 112], kneeA: [104, 130], ankleA: [101, 160], kneeB: [130, 130], ankleB: [139, 160] }),
    pose(stand, { head: [160, 58], shoulder: [145, 72], hip: [112, 100], elbowA: [119, 65], handA: [91, 62], elbowB: [171, 65], handB: [199, 62], kneeA: [104, 130], ankleA: [101, 160], kneeB: [130, 130], ankleB: [139, 160] })
  ], 3.3);

  add("loadedMarch", "Stay tall while marching with the weights held steady", "Front view", ["dumbbells"], [
    pose(stand, { kneeA: [105, 101], ankleA: [106, 128] }),
    pose(stand, { kneeB: [135, 101], ankleB: [134, 128] })
  ], 2.6);

  add("suitcaseMarch", "Resist leaning toward the weight as each knee lifts", "Front view", ["one-dumbbell"], [
    pose(stand, { kneeA: [105, 101], ankleA: [106, 128] }),
    pose(stand, { kneeB: [135, 101], ankleB: [134, 128] })
  ], 2.6);

  add("frontRackMarch", "Hold the dumbbell at the chest and keep the ribs stacked", "Front view", ["front-dumbbell"], [
    pose(stand, { elbowA: [103, 69], handA: [116, 67], elbowB: [137, 69], handB: [124, 67], kneeA: [105, 101], ankleA: [106, 128] }),
    pose(stand, { elbowA: [103, 69], handA: [116, 67], elbowB: [137, 69], handB: [124, 67], kneeB: [135, 101], ankleB: [134, 128] })
  ], 2.6);

  add("shadowBox", "Rotate gently and extend one punch at a time", "Front view", [], [
    pose(stand, { elbowA: [105, 60], handA: [115, 47], elbowB: [135, 60], handB: [125, 47] }),
    pose(stand, { shoulder: [126, 52], elbowA: [150, 55], handA: [181, 56], elbowB: [133, 63], handB: [123, 49] }),
    pose(stand, { shoulder: [114, 52], elbowB: [90, 55], handB: [59, 56], elbowA: [107, 63], handA: [117, 49] })
  ], 2.6);

  add("kneeDrive", "Drive one knee up while the hands pull down", "Front view", [], [
    pose(stand, { elbowA: [103, 30], handA: [112, 11], elbowB: [137, 30], handB: [128, 11] }),
    pose(stand, { elbowA: [104, 65], handA: [115, 82], elbowB: [136, 65], handB: [125, 82], kneeA: [109, 98], ankleA: [107, 127] })
  ], 2.7);

  add("hamCurl", "Bring one heel toward the seat without moving the knee forward", "Side view", [], [
    stand,
    pose(stand, { kneeA: [107, 127], ankleA: [129, 111], elbowA: [102, 66], handA: [114, 47], elbowB: [139, 78], handB: [129, 99] })
  ], 2.8);

  add("toeTap", "Reach the toe forward lightly and return to centre", "Front view", [], [
    stand,
    pose(stand, { kneeA: [106, 128], ankleA: [76, 157], elbowA: [102, 68], handA: [90, 50], elbowB: [139, 76], handB: [147, 98] })
  ], 2.7);

  add("skater", "Travel side to side while the trailing leg reaches behind", "Front view", [], [
    pose(stand, { head: [95, 31], shoulder: [98, 56], hip: [105, 99], elbowA: [75, 68], handA: [57, 82], elbowB: [121, 72], handB: [137, 92], kneeA: [84, 128], ankleA: [69, 159], kneeB: [123, 128], ankleB: [143, 153] }),
    pose(stand, { head: [145, 31], shoulder: [142, 56], hip: [135, 99], elbowA: [119, 72], handA: [103, 92], elbowB: [165, 68], handB: [183, 82], kneeA: [117, 128], ankleA: [97, 153], kneeB: [156, 128], ankleB: [171, 159] })
  ], 2.6);

  add("frontKick", "Lift the knee first, then extend the lower leg gently", "Side view", [], [
    stand,
    pose(stand, { kneeA: [133, 101], ankleA: [126, 128], elbowA: [102, 66], handA: [114, 48], elbowB: [139, 78], handB: [129, 99] }),
    pose(stand, { kneeA: [133, 101], ankleA: [170, 108], elbowA: [102, 66], handA: [114, 48], elbowB: [139, 78], handB: [129, 99] })
  ], 3.1);

  add("stepKnee", "Step to the side, then lift the opposite knee", "Front view", [], [
    pose(stand, { hip: [100, 96], shoulder: [100, 52], head: [100, 26], kneeA: [81, 127], ankleA: [67, 160], kneeB: [119, 127], ankleB: [128, 160] }),
    pose(stand, { hip: [113, 96], shoulder: [113, 52], head: [113, 26], kneeB: [126, 99], ankleB: [127, 127], elbowA: [94, 66], handA: [105, 48], elbowB: [132, 76], handB: [123, 98] })
  ], 3.0);

  add("seatedKnee", "Sit tall and lift one knee without leaning back", "Front view", ["chair"], [
    seated,
    pose(seated, { kneeA: [95, 91], ankleA: [96, 124] })
  ], 3.0);

  add("seatedLegExtension", "Straighten one knee, pause, then lower with control", "Front view", ["chair"], [
    seated,
    pose(seated, { kneeA: [94, 112], ankleA: [64, 113] })
  ], 3.2);

  add("seatedRotation", "Rotate through the upper back while the hips stay forward", "Front view", ["chair"], [
    pose(seated, { elbowA: [98, 75], handA: [112, 82], elbowB: [142, 75], handB: [128, 82] }),
    pose(seated, { head: [138, 39], shoulder: [134, 65], elbowA: [111, 75], handA: [124, 82], elbowB: [153, 73], handB: [140, 81] })
  ], 3.8);

  add("figureFour", "Rest the ankle across the opposite thigh and hinge gently", "Front view", ["chair"], [
    seated,
    pose(seated, { head: [126, 49], shoulder: [126, 74], hip: [120, 108], kneeA: [91, 94], ankleA: [133, 105], kneeB: [145, 112], ankleB: [145, 159] })
  ], 4.0);

  add("hamstringReach", "Extend one heel and hinge forward with a long back", "Side view", ["chair-left"], [
    stand,
    pose(stand, { head: [156, 62], shoulder: [143, 78], hip: [112, 105], elbowA: [133, 91], handA: [117, 108], elbowB: [148, 91], handB: [132, 109], kneeA: [98, 128], ankleA: [70, 158], kneeB: [132, 131], ankleB: [139, 160] })
  ], 3.8);

  add("bridge", "Press through the feet and lift the hips without arching", "Side view", ["mat"], [
    supine,
    pose(supine, { hip: [122, 102], shoulder: [168, 137], head: [194, 137], elbowA: [160, 146], handA: [137, 151], elbowB: [151, 149], handB: [129, 154] })
  ], 3.6);

  add("weightedBridge", "Hold the dumbbell securely while lifting the hips", "Side view", ["mat", "hip-dumbbell"], [
    supine,
    pose(supine, { hip: [122, 102], shoulder: [168, 137], head: [194, 137], elbowA: [150, 121], handA: [129, 111], elbowB: [143, 126], handB: [119, 113] })
  ], 3.6);

  add("birdDog", "Reach the opposite arm and leg while keeping the trunk steady", "Side view", ["mat"], [
    quadruped,
    pose(quadruped, { elbowA: [179, 91], handA: [210, 88], kneeB: [82, 109], ankleB: [43, 105] })
  ], 3.8);

  add("deadBug", "Lower the opposite arm and heel without lifting the lower back", "Side view", ["mat"], [
    pose(supine, { elbowA: [160, 105], handA: [160, 73], elbowB: [150, 106], handB: [150, 74], kneeA: [122, 102], ankleA: [104, 77], kneeB: [111, 108], ankleB: [93, 83] }),
    pose(supine, { elbowA: [185, 119], handA: [211, 139], elbowB: [150, 106], handB: [150, 74], kneeA: [95, 132], ankleA: [57, 145], kneeB: [111, 108], ankleB: [93, 83] })
  ], 3.8);

  add("heelSlide", "Slide one heel away while the pelvis stays still", "Side view", ["mat"], [
    supine,
    pose(supine, { kneeA: [84, 132], ankleA: [42, 145] })
  ], 3.6);

  add("floorPress", "Lower the elbows to the floor, then press the weights up", "Front-side view", ["mat", "dumbbells"], [
    pose(supine, { elbowA: [160, 145], handA: [160, 108], elbowB: [147, 146], handB: [147, 109] }),
    pose(supine, { elbowA: [164, 107], handA: [164, 70], elbowB: [151, 108], handB: [151, 71] })
  ], 3.3);

  add("oneArmFloorPress", "Press one weight while the trunk resists rotating", "Front-side view", ["mat", "one-dumbbell"], [
    pose(supine, { elbowA: [160, 145], handA: [160, 108], elbowB: [154, 148], handB: [135, 151] }),
    pose(supine, { elbowA: [164, 107], handA: [164, 70], elbowB: [154, 148], handB: [135, 151] })
  ], 3.3);

  add("clamshell", "Keep the feet together while the top knee opens", "Side view", ["mat"], [
    sideLying,
    pose(sideLying, { kneeA: [93, 111], ankleA: [59, 150] })
  ], 3.4);

  add("proneW", "Lift the elbows into a W by squeezing the upper back", "Top-side view", ["mat"], [
    prone,
    pose(prone, { elbowA: [159, 119], handA: [179, 108], elbowB: [143, 119], handB: [161, 108] })
  ], 3.5);

  add("catCow", "Round and lengthen the spine slowly with the breath", "Side view", ["mat"], [
    quadruped,
    pose(quadruped, { head: [175, 111], shoulder: [153, 102], hip: [111, 101] })
  ], 4.0);

  add("openBook", "Open the top arm and rotate through the upper back", "Top-side view", ["mat"], [
    sideLying,
    pose(sideLying, { elbowA: [159, 103], handA: [146, 75], head: [179, 116] })
  ], 4.2);

  add("threadNeedle", "Reach one arm underneath, then rotate it open", "Side view", ["mat"], [
    quadruped,
    pose(quadruped, { elbowA: [137, 116], handA: [103, 126], head: [171, 105] }),
    pose(quadruped, { elbowA: [165, 79], handA: [176, 50], head: [174, 82] })
  ], 4.4);

  add("childPose", "Send the hips back while the arms reach long", "Side view", ["mat"], [
    quadruped,
    pose(quadruped, { head: [169, 122], shoulder: [147, 130], hip: [103, 132], elbowA: [176, 137], handA: [207, 142], elbowB: [163, 141], handB: [194, 146], kneeA: [92, 145], ankleA: [72, 157], kneeB: [86, 149], ankleB: [66, 159] })
  ], 4.2);

  add("wallSlide", "Keep the back near the wall as the arms slide upward", "Front view", ["wall-back"], [
    pose(stand, { elbowA: [95, 67], handA: [96, 43], elbowB: [145, 67], handB: [144, 43] }),
    pose(stand, { elbowA: [104, 35], handA: [111, 11], elbowB: [136, 35], handB: [129, 11] })
  ], 3.8);

  add("chestOpen", "Draw the arms back gently and open across the chest", "Front view", [], [
    pose(stand, { elbowA: [104, 72], handA: [111, 94], elbowB: [136, 72], handB: [129, 94] }),
    pose(stand, { elbowA: [88, 64], handA: [66, 72], elbowB: [152, 64], handB: [174, 72] })
  ], 3.8);

  add("hipFlexor", "Shift forward through a split stance without arching the back", "Side view", ["chair-left"], [
    pose(stand, { kneeA: [142, 128], ankleA: [158, 160], kneeB: [101, 129], ankleB: [73, 158], elbowA: [98, 70], handA: [73, 85] }),
    pose(stand, { head: [126, 28], shoulder: [126, 54], hip: [125, 99], kneeA: [145, 129], ankleA: [158, 160], kneeB: [99, 132], ankleB: [73, 158], elbowA: [100, 70], handA: [73, 85] })
  ], 4.0);

  add("ankleDrive", "Guide the knee forward while the heel stays grounded", "Side view", ["chair-left"], [
    pose(stand, { kneeA: [132, 128], ankleA: [119, 160], kneeB: [103, 128], ankleB: [94, 160], elbowA: [99, 70], handA: [74, 84] }),
    pose(stand, { head: [128, 28], shoulder: [128, 54], hip: [126, 98], kneeA: [148, 128], ankleA: [119, 160], kneeB: [105, 129], ankleB: [94, 160], elbowA: [102, 70], handA: [74, 84] })
  ], 3.8);

  add("counterStretch", "Hinge back from the support and lengthen the spine", "Side view", ["counter"], [
    stand,
    pose(stand, { head: [177, 80], shoulder: [154, 88], hip: [111, 103], elbowA: [176, 83], handA: [199, 83], elbowB: [174, 90], handB: [199, 89], kneeA: [103, 132], ankleA: [101, 160], kneeB: [132, 132], ankleB: [139, 160] })
  ], 4.0);

  add("inclinePush", "Lower the chest toward the counter while the whole body stays aligned", "Side view", ["counter"], [
    pose(stand, { head: [181, 67], shoulder: [158, 82], hip: [112, 112], elbowA: [176, 83], handA: [197, 83], elbowB: [173, 89], handB: [197, 88], kneeA: [82, 135], ankleA: [52, 160], kneeB: [93, 139], ankleB: [64, 160] }),
    pose(stand, { head: [194, 72], shoulder: [173, 87], hip: [123, 116], elbowA: [181, 99], handA: [197, 83], elbowB: [184, 103], handB: [197, 88], kneeA: [89, 138], ankleA: [52, 160], kneeB: [101, 142], ankleB: [64, 160] })
  ], 3.2);

  add("floorPlank", "Brace the trunk and hold a straight line from head to heels", "Side view", ["mat"], [
    pose(prone, { head: [190, 109], shoulder: [165, 120], hip: [119, 128], elbowA: [163, 140], handA: [188, 145], elbowB: [151, 142], handB: [177, 149], kneeA: [86, 136], ankleA: [48, 151], kneeB: [88, 141], ankleB: [51, 157] }),
    pose(prone, { head: [189, 107], shoulder: [164, 118], hip: [118, 126], elbowA: [163, 140], handA: [188, 145], elbowB: [151, 142], handB: [177, 149], kneeA: [85, 134], ankleA: [48, 151], kneeB: [87, 139], ankleB: [51, 157] })
  ], 4.5);

  add("singleLegBridge", "Keep the hips level while one leg stays extended", "Side view", ["mat"], [
    pose(supine, { kneeA: [91, 108], ankleA: [60, 140], kneeB: [86, 141], ankleB: [45, 148] }),
    pose(supine, { hip: [122, 102], kneeA: [91, 108], ankleA: [60, 140], kneeB: [90, 104], ankleB: [54, 113], elbowA: [160, 146], handA: [137, 151], elbowB: [151, 149], handB: [129, 154] })
  ], 3.7);

  add("kneelingPush", "Lower and press with a straight line from the head to the knees", "Side view", ["mat"], [
    pose(quadruped, { head: [189, 93], shoulder: [162, 105], hip: [119, 126], elbowA: [171, 128], handA: [179, 156], elbowB: [158, 130], handB: [166, 158], kneeA: [84, 145], ankleA: [62, 158], kneeB: [91, 149], ankleB: [70, 161] }),
    pose(quadruped, { head: [190, 124], shoulder: [164, 132], hip: [119, 142], elbowA: [174, 144], handA: [179, 156], elbowB: [164, 148], handB: [166, 158], kneeA: [84, 145], ankleA: [62, 158], kneeB: [91, 149], ankleB: [70, 161] })
  ], 3.3);

  add("lateralLunge", "Sit into one hip while the opposite leg stays long", "Front view", [], [
    stand,
    pose(stand, { head: [91, 47], shoulder: [94, 72], hip: [101, 113], elbowA: [72, 78], handA: [84, 96], elbowB: [119, 80], handB: [108, 98], kneeA: [71, 135], ankleA: [74, 160], kneeB: [143, 129], ankleB: [173, 158] })
  ], 3.7);

  add("floorTap", "Tap the opposite shoulder without letting the hips rotate", "Side view", ["mat"], [
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] }),
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [151, 105], handA: [163, 116], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] })
  ], 3.4);

  add("doubleRow", "Pull both dumbbells toward the hips without changing the hinge", "Side view", ["dumbbells"], [
    pose(stand, { head: [160, 58], shoulder: [145, 72], hip: [112, 100], elbowA: [139, 91], handA: [133, 116], elbowB: [151, 91], handB: [145, 116], kneeA: [104, 130], ankleA: [101, 160], kneeB: [130, 130], ankleB: [139, 160] }),
    pose(stand, { head: [160, 58], shoulder: [145, 72], hip: [112, 100], elbowA: [121, 81], handA: [119, 101], elbowB: [139, 82], handB: [137, 102], kneeA: [104, 130], ankleA: [101, 160], kneeB: [130, 130], ankleB: [139, 160] })
  ], 3.2);

  add("standingPress", "Press both dumbbells overhead while the ribs stay stacked", "Front view", ["dumbbells"], [
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [142, 67], handB: [135, 48] }),
    pose(stand, { elbowA: [105, 34], handA: [110, 12], elbowB: [135, 34], handB: [130, 12] })
  ], 3.2);

  add("weightedLunge", "Lower straight down while the dumbbells stay quiet beside the body", "Side view", ["dumbbells"], [
    stand,
    pose(stand, { head: [124, 39], shoulder: [122, 64], hip: [116, 108], elbowA: [103, 80], handA: [108, 105], elbowB: [141, 80], handB: [136, 105], kneeA: [151, 130], ankleA: [166, 160], kneeB: [86, 139], ankleB: [61, 158] })
  ], 3.8);

  add("frontRackSquat", "Keep the dumbbells at the shoulders while sitting between the feet", "Front view", ["dumbbells"], [
    pose(stand, { elbowA: [98, 66], handA: [106, 48], elbowB: [142, 66], handB: [134, 48] }),
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [96, 78], handA: [106, 61], elbowB: [144, 78], handB: [134, 61], kneeA: [91, 135], ankleA: [99, 160], kneeB: [149, 135], ankleB: [141, 160] })
  ], 3.6);

  add("pullover", "Lower the dumbbell behind the head while the ribs stay down", "Side view", ["mat", "one-dumbbell"], [
    pose(supine, { elbowA: [164, 106], handA: [164, 74], elbowB: [151, 108], handB: [151, 77] }),
    pose(supine, { elbowA: [187, 121], handA: [209, 139], elbowB: [178, 124], handB: [201, 143] })
  ], 3.8);

  add("squatKnee", "Stand from the squat, then finish with a controlled knee drive", "Front view", [], [
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [95, 82], handA: [111, 95], elbowB: [145, 82], handB: [129, 95], kneeA: [91, 135], ankleA: [99, 160], kneeB: [149, 135], ankleB: [141, 160] }),
    stand,
    pose(stand, { elbowA: [104, 65], handA: [115, 82], elbowB: [136, 65], handB: [125, 82], kneeA: [109, 98], ankleA: [107, 127] })
  ], 3.5);

  add("punchKnee", "Complete two controlled punches, then drive one knee upward", "Front view", [], [
    pose(stand, { elbowA: [105, 60], handA: [115, 47], elbowB: [135, 60], handB: [125, 47] }),
    pose(stand, { shoulder: [126, 52], elbowA: [150, 55], handA: [181, 56], elbowB: [133, 63], handB: [123, 49] }),
    pose(stand, { elbowA: [104, 65], handA: [115, 82], elbowB: [136, 65], handB: [125, 82], kneeA: [109, 98], ankleA: [107, 127] })
  ], 3.0);

  add("sealJack", "Open the arms and feet, then close them together with a soft landing", "Front view", [], [
    pose(narrowStand, { elbowA: [100, 58], handA: [114, 58], elbowB: [140, 58], handB: [126, 58] }),
    pose(stand, { head: [120, 20], shoulder: [120, 46], hip: [120, 90], elbowA: [88, 52], handA: [58, 52], elbowB: [152, 52], handB: [182, 52], kneeA: [92, 122], ankleA: [73, 155], kneeB: [148, 122], ankleB: [167, 155] })
  ], 2.1);

  add("pogo", "Hop a short distance side to side and land through soft knees", "Front view", [], [
    pose(narrowStand, { head: [109, 22], shoulder: [109, 48], hip: [109, 92], kneeA: [101, 122], ankleA: [99, 154], kneeB: [117, 122], ankleB: [119, 154] }),
    pose(narrowStand, { head: [131, 22], shoulder: [131, 48], hip: [131, 92], kneeA: [123, 122], ankleA: [121, 154], kneeB: [139, 122], ankleB: [141, 154] })
  ], 1.5);

  add("floorPush", "Lower the chest between the hands and press the body up as one unit", "Side view", ["mat"], [
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] }),
    pose(prone, { head: [191, 131], shoulder: [164, 139], hip: [116, 146], elbowA: [175, 148], handA: [176, 158], elbowB: [165, 150], handB: [163, 159], kneeA: [82, 151], ankleA: [44, 156], kneeB: [84, 155], ankleB: [47, 159] })
  ], 3.3);

  add("pikePush", "Bend the elbows and lower the head between the hands from an inverted V", "Side view", ["mat"], [
    pose(quadruped, { head: [180, 104], shoulder: [157, 111], hip: [111, 75], elbowA: [166, 132], handA: [174, 158], elbowB: [155, 135], handB: [162, 159], kneeA: [83, 114], ankleA: [49, 157], kneeB: [91, 119], ankleB: [58, 160] }),
    pose(quadruped, { head: [183, 136], shoulder: [160, 132], hip: [111, 75], elbowA: [174, 145], handA: [174, 158], elbowB: [166, 148], handB: [162, 159], kneeA: [83, 114], ankleA: [49, 157], kneeB: [91, 119], ankleB: [58, 160] })
  ], 3.5);

  add("singleLegChair", "Reach one foot forward and sit to the chair under control", "Side view", ["chair-left"], [
    pose(stand, { hip: [130, 96], shoulder: [130, 52], head: [130, 26], kneeA: [116, 127], ankleA: [112, 160], kneeB: [143, 112], ankleB: [169, 120] }),
    pose(stand, { head: [150, 52], shoulder: [142, 75], hip: [111, 111], elbowA: [132, 84], handA: [115, 96], elbowB: [149, 86], handB: [134, 101], kneeA: [102, 132], ankleA: [112, 160], kneeB: [139, 113], ankleB: [170, 118] })
  ], 4.0);

  add("sidePlank", "Press the forearm down and lift the hips into one long line", "Side view", ["mat"], [
    pose(sideLying, { head: [190, 119], shoulder: [165, 132], hip: [119, 144], elbowA: [166, 151], handA: [190, 156], elbowB: [151, 149], handB: [132, 155], kneeA: [85, 146], ankleA: [48, 155], kneeB: [87, 152], ankleB: [51, 160] }),
    pose(sideLying, { head: [190, 88], shoulder: [165, 103], hip: [119, 126], elbowA: [166, 138], handA: [190, 156], elbowB: [151, 118], handB: [132, 130], kneeA: [85, 140], ankleA: [48, 155], kneeB: [87, 146], ankleB: [51, 160] })
  ], 4.2);

  add("bearTap", "Hover the knees and tap one shoulder without shifting the hips", "Side view", ["mat"], [
    pose(quadruped, { head: [181, 91], shoulder: [156, 98], hip: [111, 104], elbowA: [160, 122], handA: [160, 157], elbowB: [147, 123], handB: [145, 157], kneeA: [111, 132], ankleA: [94, 153], kneeB: [96, 132], ankleB: [79, 153] }),
    pose(quadruped, { head: [181, 91], shoulder: [156, 98], hip: [111, 104], elbowA: [145, 91], handA: [155, 101], elbowB: [147, 123], handB: [145, 157], kneeA: [111, 132], ankleA: [94, 153], kneeB: [96, 132], ankleB: [79, 153] })
  ], 3.4);

  add("tempoLunge", "Lower for three counts, pause, and rise without losing alignment", "Side view", [], [
    stand,
    pose(stand, { head: [124, 39], shoulder: [122, 64], hip: [116, 108], elbowA: [103, 80], handA: [108, 105], elbowB: [141, 80], handB: [136, 105], kneeA: [151, 130], ankleA: [166, 160], kneeB: [86, 139], ankleB: [61, 158] })
  ], 5.2);

  add("floorClimber", "Alternate knee drives while the shoulders remain over the hands", "Side view", ["mat"], [
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] }),
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [126, 133], ankleA: [98, 151], kneeB: [85, 142], ankleB: [47, 159] }),
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [129, 137], ankleB: [101, 154] })
  ], 2.2);

  add("squatThrust", "Move from standing through a compact squat into a strong plank", "Side view", ["mat"], [
    stand,
    pose(stand, { head: [168, 93], shoulder: [148, 108], hip: [112, 126], elbowA: [161, 129], handA: [174, 158], elbowB: [150, 133], handB: [162, 159], kneeA: [91, 139], ankleA: [82, 160], kneeB: [125, 139], ankleB: [139, 160] }),
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] })
  ], 3.0);

  add("thruster", "Stand from the squat and carry that drive into an overhead press", "Front view", ["dumbbells"], [
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [96, 78], handA: [106, 61], elbowB: [144, 78], handB: [134, 61], kneeA: [91, 135], ankleA: [99, 160], kneeB: [149, 135], ankleB: [141, 160] }),
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [142, 67], handB: [135, 48] }),
    pose(stand, { elbowA: [105, 34], handA: [110, 12], elbowB: [135, 34], handB: [130, 12] })
  ], 3.8);

  add("singleLegRdl", "Hinge on one leg as the free leg reaches long behind", "Side view", ["dumbbells"], [
    stand,
    pose(stand, { head: [166, 62], shoulder: [149, 75], hip: [112, 100], elbowA: [138, 89], handA: [132, 115], elbowB: [151, 91], handB: [145, 117], kneeA: [105, 130], ankleA: [101, 160], kneeB: [75, 100], ankleB: [39, 93] })
  ], 4.0);

  add("plankRow", "Row one dumbbell while the trunk resists rotating", "Side view", ["mat", "dumbbells"], [
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] }),
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [146, 115], handA: [124, 125], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] })
  ], 3.5);

  add("pushPress", "Use a shallow leg dip, then finish with the dumbbells overhead", "Front view", ["dumbbells"], [
    pose(stand, { head: [120, 34], shoulder: [120, 60], hip: [120, 105], elbowA: [98, 73], handA: [105, 54], elbowB: [142, 73], handB: [135, 54], kneeA: [101, 132], ankleA: [99, 160], kneeB: [139, 132], ankleB: [141, 160] }),
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [142, 67], handB: [135, 48] }),
    pose(stand, { elbowA: [105, 34], handA: [110, 12], elbowB: [135, 34], handB: [130, 12] })
  ], 3.0);

  add("frontRackLunge", "Keep the dumbbells at the shoulders while stepping back into the lunge", "Side view", ["dumbbells"], [
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [142, 67], handB: [135, 48] }),
    pose(stand, { head: [124, 39], shoulder: [122, 64], hip: [116, 108], elbowA: [100, 75], handA: [106, 56], elbowB: [143, 75], handB: [136, 56], kneeA: [151, 130], ankleA: [166, 160], kneeB: [86, 139], ankleB: [61, 158] })
  ], 3.8);

  add("bridgePress", "Hold the hips high while pressing the dumbbells over the chest", "Side view", ["mat", "dumbbells"], [
    pose(supine, { hip: [122, 102], elbowA: [160, 145], handA: [160, 108], elbowB: [147, 146], handB: [147, 109] }),
    pose(supine, { hip: [122, 102], elbowA: [164, 107], handA: [164, 70], elbowB: [151, 108], handB: [151, 71] })
  ], 3.4);

  add("plankDrag", "Drag the dumbbell across while the hips stay square to the floor", "Side view", ["mat", "one-dumbbell"], [
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] }),
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [150, 135], handA: [130, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] })
  ], 3.6);

  add("offsetSquat", "Resist leaning as one dumbbell stays racked at the shoulder", "Front view", ["one-dumbbell"], [
    pose(stand, { elbowA: [98, 67], handA: [105, 48] }),
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [96, 78], handA: [106, 61], kneeA: [91, 135], ankleA: [99, 160], kneeB: [149, 135], ankleB: [141, 160] })
  ], 3.7);

  add("jumpSquat", "Jump from the squat and return through a soft, controlled landing", "Front view", [], [
    pose(stand, { head: [120, 49], shoulder: [120, 73], hip: [120, 117], elbowA: [95, 82], handA: [111, 95], elbowB: [145, 82], handB: [129, 95], kneeA: [91, 135], ankleA: [99, 160], kneeB: [149, 135], ankleB: [141, 160] }),
    stand,
    pose(stand, { head: [120, 10], shoulder: [120, 36], hip: [120, 80], elbowA: [103, 24], handA: [112, 3], elbowB: [137, 24], handB: [128, 3], kneeA: [105, 111], ankleA: [101, 144], kneeB: [135, 111], ankleB: [139, 144] })
  ], 2.7);

  add("burpee", "Move from a jump through a compact squat into a strong plank", "Side view", ["mat"], [
    pose(stand, { head: [120, 10], shoulder: [120, 36], hip: [120, 80], elbowA: [103, 24], handA: [112, 3], elbowB: [137, 24], handB: [128, 3], kneeA: [105, 111], ankleA: [101, 144], kneeB: [135, 111], ankleB: [139, 144] }),
    pose(stand, { head: [168, 93], shoulder: [148, 108], hip: [112, 126], elbowA: [161, 129], handA: [174, 158], elbowB: [150, 133], handB: [162, 159], kneeA: [91, 139], ankleA: [82, 160], kneeB: [125, 139], ankleB: [139, 160] }),
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] })
  ], 2.8);

  add("plankJack", "Hop the feet wide and together while the upper body stays steady", "Side view", ["mat"], [
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [82, 136], ankleA: [44, 153], kneeB: [85, 142], ankleB: [47, 159] }),
    pose(prone, { head: [191, 103], shoulder: [164, 114], hip: [116, 126], elbowA: [171, 135], handA: [176, 158], elbowB: [159, 137], handB: [163, 159], kneeA: [84, 128], ankleA: [48, 129], kneeB: [84, 151], ankleB: [48, 165] })
  ], 1.8);

  add("splitJump", "Switch the split stance in the air and land through both soft knees", "Side view", [], [
    pose(stand, { head: [124, 39], shoulder: [122, 64], hip: [116, 108], elbowA: [103, 80], handA: [108, 105], elbowB: [141, 80], handB: [136, 105], kneeA: [151, 130], ankleA: [166, 160], kneeB: [86, 139], ankleB: [61, 158] }),
    pose(stand, { head: [116, 39], shoulder: [118, 64], hip: [124, 108], elbowA: [99, 80], handA: [104, 105], elbowB: [137, 80], handB: [132, 105], kneeA: [89, 139], ankleA: [64, 158], kneeB: [153, 130], ankleB: [178, 160] })
  ], 2.0);

  add("stairPowerMarch", "Drive the opposite arm and knee as if climbing a steady flight of stairs", "Front view", [], [
    pose(stand, { elbowA: [99, 76], handA: [109, 99], elbowB: [140, 60], handB: [129, 41], kneeA: [106, 96], ankleA: [106, 124] }),
    stand,
    pose(stand, { elbowA: [100, 60], handA: [111, 41], elbowB: [141, 76], handB: [131, 99], kneeB: [134, 96], ankleB: [134, 124] })
  ], 2.4);

  add("wallDrive", "Hold a strong wall lean while alternating powerful knee drives", "Side view", ["wall"], [
    pose(stand, { head: [164, 49], shoulder: [148, 67], hip: [113, 100], elbowA: [176, 75], handA: [205, 78], elbowB: [172, 84], handB: [205, 87], kneeA: [91, 129], ankleA: [78, 160], kneeB: [119, 130], ankleB: [108, 160] }),
    pose(stand, { head: [164, 49], shoulder: [148, 67], hip: [113, 100], elbowA: [176, 75], handA: [205, 78], elbowB: [172, 84], handB: [205, 87], kneeA: [139, 102], ankleA: [119, 128], kneeB: [104, 133], ankleB: [83, 160] }),
    pose(stand, { head: [164, 49], shoulder: [148, 67], hip: [113, 100], elbowA: [176, 75], handA: [205, 78], elbowB: [172, 84], handB: [205, 87], kneeA: [101, 132], ankleA: [79, 160], kneeB: [139, 103], ankleB: [118, 129] })
  ], 2.0);

  add("bearCrawl", "Move the opposite hand and foot together while the knees stay low", "Side view", ["mat"], [
    pose(quadruped, { head: [181, 91], shoulder: [156, 98], hip: [111, 104], elbowA: [160, 122], handA: [160, 157], elbowB: [147, 123], handB: [145, 157], kneeA: [111, 132], ankleA: [94, 153], kneeB: [96, 132], ankleB: [79, 153] }),
    pose(quadruped, { head: [188, 89], shoulder: [163, 97], hip: [118, 103], elbowA: [174, 120], handA: [180, 155], elbowB: [151, 121], handB: [151, 156], kneeA: [117, 132], ankleA: [101, 153], kneeB: [104, 127], ankleB: [91, 149] }),
    pose(quadruped, { head: [174, 93], shoulder: [149, 100], hip: [104, 106], elbowA: [154, 121], handA: [151, 156], elbowB: [137, 125], handB: [131, 158], kneeA: [103, 127], ankleA: [91, 149], kneeB: [90, 134], ankleB: [72, 155] })
  ], 3.0);

  add("kneelStand", "Step from tall kneeling through a stable half-kneel into standing", "Side view", ["mat"], [
    pose(stand, { head: [121, 68], shoulder: [121, 94], hip: [121, 132], elbowA: [101, 108], handA: [108, 131], elbowB: [141, 108], handB: [134, 131], kneeA: [104, 150], ankleA: [82, 159], kneeB: [138, 150], ankleB: [158, 159] }),
    pose(stand, { head: [126, 46], shoulder: [125, 72], hip: [120, 115], elbowA: [104, 88], handA: [110, 112], elbowB: [145, 88], handB: [139, 112], kneeA: [147, 130], ankleA: [160, 160], kneeB: [99, 148], ankleB: [76, 158] }),
    stand
  ], 4.0);

  add("loadedStairMarch", "Keep both dumbbells quiet while alternating strong stair-climb knees", "Front view", ["dumbbells"], [
    pose(stand, { kneeA: [106, 96], ankleA: [106, 124] }),
    stand,
    pose(stand, { kneeB: [134, 96], ankleB: [134, 124] })
  ], 2.5);

  add("frontRackStairMarch", "Hold the dumbbells at the shoulders while driving each knee upward", "Front view", ["dumbbells"], [
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [142, 67], handB: [135, 48], kneeA: [106, 96], ankleA: [106, 124] }),
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [142, 67], handB: [135, 48] }),
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [142, 67], handB: [135, 48], kneeB: [134, 96], ankleB: [134, 124] })
  ], 2.5);

  add("offsetCarryMarch", "Resist side-bending with one dumbbell racked and one held at the side", "Front view", ["dumbbells"], [
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [141, 72], handB: [136, 99], kneeA: [106, 96], ankleA: [106, 124] }),
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [141, 72], handB: [136, 99] }),
    pose(stand, { elbowA: [98, 67], handA: [105, 48], elbowB: [141, 72], handB: [136, 99], kneeB: [134, 96], ankleB: [134, 124] })
  ], 2.6);

  const mapping = {
    "easy-march": "march", "shoulder-rolls": "shoulderRoll", "practice-hinges": "hinge", "side-reaches": "sideBend", "heel-digs": "heelDig", "arm-circles": "armCircle", "ankle-rocks": "ankleRock",
    "chair-squat": "chairSquat", "wall-pushup": "wallPush", "glute-bridge": "bridge", "bird-dog": "birdDog", "counter-plank": "counterPlank", "calf-raise": "calfRaise", "step-back-tap": "lunge", "dead-bug": "deadBug", "wall-slide": "wallSlide", "supported-lunge": "lunge", "side-leg-raise": "sideLegRaise", "heel-slide": "heelSlide", "cross-crunch": "crossCrunch", "side-wall-plank": "sideWallPlank", "seated-knee-lift": "seatedKnee", "good-morning": "hinge", "clamshell": "clamshell", "prone-w-raise": "proneW", "counter-shoulder-tap": "counterTap", "seated-leg-extension": "seatedLegExtension",
    "goblet-squat": "gobletSquat", "supported-row": "row", "floor-press": "floorPress", "dumbbell-hinge": "weightedHinge", "suitcase-march": "suitcaseMarch", "hammer-curl": "curl", "seated-press": "overheadPress", "sumo-squat": "sumoSquat", "weighted-calf-raise": "weightedCalfRaise", "triceps-kickback": "triceps", "reverse-fly": "reverseFly", "farmer-march": "loadedMarch", "one-arm-floor-press": "oneArmFloorPress", "lateral-raise": "lateralRaise", "front-rack-march": "frontRackMarch", "weighted-bridge": "weightedBridge",
    "bodyweight-squat": "squat", "counter-pushup": "inclinePush", "reverse-lunge": "lunge", "forearm-plank": "floorPlank", "single-leg-bridge": "singleLegBridge", "kneeling-pushup": "kneelingPush", "lateral-lunge": "lateralLunge", "plank-shoulder-tap": "floorTap",
    "dumbbell-rdl": "weightedHinge", "double-dumbbell-row": "doubleRow", "standing-dumbbell-press": "standingPress", "dumbbell-reverse-lunge": "weightedLunge", "dumbbell-front-squat": "frontRackSquat", "dumbbell-split-squat": "weightedLunge", "dumbbell-pullover": "pullover", "suitcase-deadlift": "weightedHinge",
    "full-pushup": "floorPush", "pike-pushup": "pikePush", "single-leg-chair-squat": "singleLegChair", "side-forearm-plank": "sidePlank", "bear-shoulder-tap": "bearTap", "tempo-split-squat": "tempoLunge", "plank-knee-drive": "floorClimber", "squat-thrust": "squatThrust",
    "dumbbell-thruster": "thruster", "single-leg-dumbbell-rdl": "singleLegRdl", "renegade-row": "plankRow", "dumbbell-push-press": "pushPress", "front-rack-reverse-lunge": "frontRackLunge", "bridge-floor-press": "bridgePress", "plank-dumbbell-drag": "plankDrag", "offset-goblet-squat": "offsetSquat",
    "squat-knee-drive": "squatKnee", "lateral-shuffle-step": "sideStep", "punch-knee-combo": "punchKnee", "fast-step-back": "tempoLunge", "jog-in-place": "fastFeet", "seal-jacks": "sealJack", "lateral-pogo": "pogo", "quick-feet-forward-back": "fastFeet",
    "power-skater-step": "skater", "speed-squat-reach": "squatReach", "power-march": "march", "floor-mountain-climber": "floorClimber", "jump-squat": "jumpSquat", "burpee": "burpee", "plank-jack": "plankJack", "split-jump": "splitJump",
    "stair-power-march": "stairPowerMarch", "wall-drive-knees": "wallDrive", "bear-crawl-step": "bearCrawl", "kneel-to-stand": "kneelStand", "loaded-stair-march": "loadedStairMarch", "front-rack-stair-march": "frontRackStairMarch", "supported-power-row": "row", "offset-carry-march": "offsetCarryMarch",
    "quick-march": "march", "step-jacks": "stepJack", "shadow-box": "shadowBox", "side-step": "sideStep", "knee-drive": "kneeDrive", "heel-dig-pull": "heelDigPull", "hamstring-curl": "hamCurl", "toe-tap-forward": "toeTap", "low-skater": "skater", "power-walk": "march", "front-kick": "frontKick", "step-knee": "stepKnee",
    "jumping-jacks": "jumpingJack", "high-knees": "kneeDrive", "skater-hops": "skater", "fast-feet": "fastFeet", "squat-reach": "squatReach", "counter-climber": "counterClimber",
    "cat-cow": "catCow", "wall-angels": "wallSlide", "open-book": "openBook", "hip-flexor-rock": "hipFlexor", "chair-hip-opener": "figureFour", "seated-rotation": "seatedRotation", "hamstring-reach": "hamstringReach", "thoracic-reach": "threadNeedle", "standing-side-bend": "sideBend", "shoulder-blade-squeeze": "chestOpen", "ankle-knee-drive": "ankleDrive", "child-pose-reach": "childPose",
    "reset-breath": "breath", "calf-stretch": "hipFlexor", "chest-opener": "chestOpen", "figure-four": "figureFour", "overhead-side-stretch": "sideBend", "back-reset": "counterStretch"
  };

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, function (character) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character];
    });
  }

  function expandedFrames(frames) {
    if (frames.length === 2) {
      return { frames: [frames[0], frames[0], frames[1], frames[1], frames[0]], times: "0;0.12;0.48;0.62;1" };
    }
    return { frames: [frames[0], frames[0], frames[1], frames[2], frames[2], frames[1], frames[0]], times: "0;0.1;0.34;0.5;0.62;0.86;1" };
  }

  function valuesFor(sequence, joint, coordinate, offset) {
    const delta = offset || 0;
    return sequence.map(function (frame) { return String(frame[joint][coordinate] + delta); }).join(";");
  }

  function animate(attribute, values, times, duration, reduced) {
    if (reduced) return "";
    return '<animate attributeName="' + attribute + '" values="' + values + '" keyTimes="' + times + '" dur="' + duration + 's" repeatCount="indefinite" calcMode="linear" />';
  }

  function line(sequence, times, duration, className, fromJoint, toJoint, reduced) {
    const first = sequence[0];
    return '<line class="' + className + '" x1="' + first[fromJoint][0] + '" y1="' + first[fromJoint][1] + '" x2="' + first[toJoint][0] + '" y2="' + first[toJoint][1] + '">' +
      animate("x1", valuesFor(sequence, fromJoint, 0), times, duration, reduced) + animate("y1", valuesFor(sequence, fromJoint, 1), times, duration, reduced) +
      animate("x2", valuesFor(sequence, toJoint, 0), times, duration, reduced) + animate("y2", valuesFor(sequence, toJoint, 1), times, duration, reduced) + '</line>';
  }

  function offsetLine(sequence, times, duration, className, joint, x1, y1, x2, y2, reduced) {
    const first = sequence[0][joint];
    return '<line class="' + className + '" x1="' + (first[0] + x1) + '" y1="' + (first[1] + y1) + '" x2="' + (first[0] + x2) + '" y2="' + (first[1] + y2) + '">' +
      animate("x1", valuesFor(sequence, joint, 0, x1), times, duration, reduced) + animate("y1", valuesFor(sequence, joint, 1, y1), times, duration, reduced) +
      animate("x2", valuesFor(sequence, joint, 0, x2), times, duration, reduced) + animate("y2", valuesFor(sequence, joint, 1, y2), times, duration, reduced) + '</line>';
  }

  function circle(sequence, times, duration, className, joint, radius, reduced, xOffset, yOffset) {
    const dx = xOffset || 0;
    const dy = yOffset || 0;
    const first = sequence[0][joint];
    return '<circle class="' + className + '" cx="' + (first[0] + dx) + '" cy="' + (first[1] + dy) + '" r="' + radius + '">' +
      animate("cx", valuesFor(sequence, joint, 0, dx), times, duration, reduced) + animate("cy", valuesFor(sequence, joint, 1, dy), times, duration, reduced) + '</circle>';
  }

  function propsSvg(props, sequence, times, duration, reduced) {
    let html = '<line class="rig-ground" x1="18" y1="165" x2="222" y2="165" />';
    if (props.indexOf("mat") !== -1) html += '<rect class="rig-mat" x="20" y="157" width="202" height="7" rx="3" />';
    if (props.indexOf("wall") !== -1) html += '<line class="rig-wall" x1="213" y1="18" x2="213" y2="165" /><line class="rig-wall-mark" x1="207" y1="42" x2="213" y2="42" />';
    if (props.indexOf("wall-back") !== -1) html += '<rect class="rig-wall-panel" x="94" y="12" width="52" height="153" rx="4" />';
    if (props.indexOf("counter") !== -1) html += '<path class="rig-counter" d="M188 82 H228 V165 M186 82 V91" />';
    if (props.indexOf("chair") !== -1) html += '<path class="rig-chair" d="M78 110 H162 M82 110 V163 M158 110 V163 M82 110 V69 M82 73 H151" />';
    if (props.indexOf("chair-left") !== -1) html += '<path class="rig-chair" d="M27 105 H83 M31 105 V163 M79 105 V163 M31 105 V68 M31 72 H78" />';
    if (props.indexOf("dumbbells") !== -1) {
      html += offsetLine(sequence, times, duration, "rig-weight", "handA", -7, 0, 7, 0, reduced) + circle(sequence, times, duration, "rig-plate", "handA", 5, reduced, -7, 0) + circle(sequence, times, duration, "rig-plate", "handA", 5, reduced, 7, 0);
      html += offsetLine(sequence, times, duration, "rig-weight", "handB", -7, 0, 7, 0, reduced) + circle(sequence, times, duration, "rig-plate", "handB", 5, reduced, -7, 0) + circle(sequence, times, duration, "rig-plate", "handB", 5, reduced, 7, 0);
    }
    if (props.indexOf("one-dumbbell") !== -1 || props.indexOf("front-dumbbell") !== -1) {
      html += offsetLine(sequence, times, duration, "rig-weight", "handA", -8, 0, 8, 0, reduced) + circle(sequence, times, duration, "rig-plate", "handA", 5, reduced, -8, 0) + circle(sequence, times, duration, "rig-plate", "handA", 5, reduced, 8, 0);
    }
    if (props.indexOf("hip-dumbbell") !== -1) {
      html += offsetLine(sequence, times, duration, "rig-weight", "hip", -11, -3, 11, -3, reduced) + circle(sequence, times, duration, "rig-plate", "hip", 6, reduced, -11, -3) + circle(sequence, times, duration, "rig-plate", "hip", 6, reduced, 11, -3);
    }
    return html;
  }

  function render(item, reducedMotion) {
    const templateName = mapping[item.id];
    const template = templates[templateName] || templates.breath;
    const expanded = expandedFrames(template.frames);
    const sequence = expanded.frames;
    const times = expanded.times;
    const duration = template.duration;
    const reduced = Boolean(reducedMotion);

    const body = propsSvg(template.props, sequence, times, duration, reduced) +
      line(sequence, times, duration, "rig-limb rig-far rig-thigh", "hip", "kneeB", reduced) +
      line(sequence, times, duration, "rig-limb rig-far rig-shin", "kneeB", "ankleB", reduced) +
      line(sequence, times, duration, "rig-limb rig-far rig-sleeve", "shoulder", "elbowB", reduced) +
      line(sequence, times, duration, "rig-limb rig-far rig-forearm", "elbowB", "handB", reduced) +
      line(sequence, times, duration, "rig-neck", "head", "shoulder", reduced) +
      line(sequence, times, duration, "rig-torso", "shoulder", "hip", reduced) +
      line(sequence, times, duration, "rig-torso-highlight", "shoulder", "hip", reduced) +
      line(sequence, times, duration, "rig-limb rig-near rig-thigh", "hip", "kneeA", reduced) +
      line(sequence, times, duration, "rig-limb rig-near rig-shin", "kneeA", "ankleA", reduced) +
      line(sequence, times, duration, "rig-limb rig-near rig-sleeve", "shoulder", "elbowA", reduced) +
      line(sequence, times, duration, "rig-limb rig-near rig-forearm", "elbowA", "handA", reduced) +
      offsetLine(sequence, times, duration, "rig-shoe rig-far", "ankleB", -7, 0, 8, 0, reduced) +
      offsetLine(sequence, times, duration, "rig-shoe rig-near", "ankleA", -7, 0, 8, 0, reduced) +
      circle(sequence, times, duration, "rig-hand rig-far", "handB", 5, reduced) +
      circle(sequence, times, duration, "rig-hand rig-near", "handA", 5, reduced) +
      circle(sequence, times, duration, "rig-head", "head", 13, reduced) +
      circle(sequence, times, duration, "rig-hair", "head", 13, reduced, -2, -4) +
      circle(sequence, times, duration, "rig-face", "head", 10, reduced, 2, 2);

    return '<div class="movement-demo realistic-demo" data-motion-template="' + escapeHtml(template.name) + '"><svg class="motion-svg" viewBox="0 0 240 180" role="img" aria-label="Animated demonstration of ' + escapeHtml(item.name) + '">' +
      '<rect class="rig-backdrop" x="0" y="0" width="240" height="180" rx="18" />' + body + '</svg><div class="demo-caption"><span>ANIMATED FORM DEMO</span><strong>' +
      escapeHtml(item.name) + '</strong><small>' + escapeHtml(template.view) + ' • ' + escapeHtml(template.label) + '</small></div>' +
      '<button type="button" class="demo-control" data-action="toggle-demo"' + (reduced ? ' disabled' : '') + '>' + (reduced ? 'Motion reduced' : 'Pause demo') + '</button></div>';
  }

  function hasAnimation(id) {
    return Boolean(mapping[id] && templates[mapping[id]]);
  }

  global.EverydayStrongMotion = {
    render: render,
    hasAnimation: hasAnimation,
    templateFor: function (id) { return mapping[id] || null; },
    mappedIds: function () { return Object.keys(mapping); }
  };
}(window));
