plugins {
    id("com.android.application")
}

android {
    namespace = "ca.chrispape.everydaystrong"
    compileSdk = 34

    defaultConfig {
        applicationId = "ca.chrispape.everydaystrong"
        minSdk = 26
        targetSdk = 34
        versionCode = 13
        versionName = "1.9.3"
    }
}
